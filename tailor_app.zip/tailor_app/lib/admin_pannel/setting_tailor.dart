import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SettingScreenTailor extends StatefulWidget {
  const SettingScreenTailor({super.key});

  @override
  SettingScreenTailorState createState() => SettingScreenTailorState();
}

class SettingScreenTailorState extends State<SettingScreenTailor> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController currentPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    loadUserData();
  }

  Future<void> loadUserData() async {
    setState(() => isLoading = true);
    try {
      User? user = auth.currentUser;
      if (user != null) {
        DocumentSnapshot userDoc = await firestore.collection('admin').doc(user.uid).get();
        if (userDoc.exists) {
          Map<String, dynamic>? userData = userDoc.data() as Map<String, dynamic>?;
          setState(() {
            nameController.text = userData?['name'] ?? '';
            emailController.text = userData?['email'] ?? '';
            phoneController.text = userData?['phone'] ?? '';
          });
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error loading user data: $e");
      }
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> updateUserData() async {
    setState(() => isLoading = true);
    try {
      User? user = auth.currentUser;
      if (user != null) {
        await firestore.collection('admin').doc(user.uid).update({
          'name': nameController.text,
          'email': emailController.text,
          'phone': phoneController.text,
        });

        if (currentPasswordController.text.isNotEmpty && newPasswordController.text.isNotEmpty) {
          AuthCredential credential = EmailAuthProvider.credential(
            email: user.email!,
            password: currentPasswordController.text.trim(),
          );
          await user.reauthenticateWithCredential(credential);
          await user.updatePassword(newPasswordController.text.trim());
        }
        showSnackBar("Profile updated successfully!");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error updating profile: $e");
      }
      showSnackBar("Failed to update profile.");
    } finally {
      setState(() => isLoading = false);
    }
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        centerTitle: true,
        title: const Text("Settings", style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const CircleAvatar(
              backgroundColor: Colors.lightBlueAccent,
              radius: 50,
            ),
            const SizedBox(height: 20),
            buildTextField(nameController, "Full Name", "Enter your name"),
            buildTextField(emailController, "Email", "Enter your email", keyboardType: TextInputType.emailAddress),
            buildTextField(phoneController, "Phone Number", "Enter your phone", keyboardType: TextInputType.phone),
            const Divider(height: 30),
            buildTextField(currentPasswordController, "Current Password", "Enter current password", obscureText: true),
            buildTextField(newPasswordController, "New Password", "Enter new password", obscureText: true),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlue),
              onPressed: updateUserData,
              child: const Text("Update Profile",style: TextStyle(color: Colors.white),),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(TextEditingController controller, String label, String hintText, {TextInputType keyboardType = TextInputType.text, bool obscureText = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hintText,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
        keyboardType: keyboardType,
        obscureText: obscureText,
        textInputAction: TextInputAction.next,
      ),
    );
  }
}