import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:tailor_app/admin_pannel/registeration_pannel_admin.dart';
import 'package:tailor_app/admin_pannel/tailor_main_page.dart';
import 'package:tailor_app/selection_page.dart';
import '../app_database/Firebase_database.dart';
import '../app_database/auth_service.dart';
import '../firebase_integration/toast_message.dart';

class LoginPageAdmin extends StatefulWidget {
  const LoginPageAdmin({super.key});

  @override
  State<LoginPageAdmin> createState() => LoginPageAdminState();
}

class LoginPageAdminState extends State<LoginPageAdmin> {
  AppAuthService authService = AppAuthService();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool visibilityStatus = true;
  GlobalKey<FormState> form = GlobalKey();
  bool isLoading = false;

  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  void clearController() {
    emailController.clear();
    passwordController.clear();
  }

  void loginAdmin() async {
    if (form.currentState!.validate()) {
      setState(() => isLoading = true); // Start loading

      String email = emailController.text.trim();
      String password = passwordController.text.trim();

      try {
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );

        User? user = userCredential.user;
        if (user != null) {
          DocumentSnapshot? userDoc = await MyFireStoreDB.getAdminFromDB(user.uid);

          if (userDoc != null && userDoc.exists && userDoc['role'] == 'admin') {
            showToast(message: "Admin Login Successful!");
            void saveAdminToken() async {
              String? token = await FirebaseMessaging.instance.getToken();
              if (token != null) {
                await FirebaseFirestore.instance.collection("AdminTokens").doc("admin1").set({
                  "token": token,
                });
              }
            }

            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => const HomeScreenTailor()),
            );
          } else {
            showToast(message: "Admin credentials required");
            FirebaseAuth.instance.signOut();
          }
        } else {
          showToast(message: "Login failed. Try again.");
        }
      } catch (e) {
        showToast(message: "Error: ${e.toString()}");
      } finally {
        setState(() => isLoading = false); // Stop loading
      }
    } else {
      showToast(message: "Login Failed! Check email & password.");
    }
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: IconButton(onPressed: (){Navigator.of(context).pop(MaterialPageRoute(builder: (context) => SelectionPage(),));}, icon: Icon(Icons.arrow_back_outlined)),),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 180, horizontal: 20),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Form(
                key: form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'ADMIN LOGIN',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.lightBlueAccent,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 50),
                    TextFormField(
                      controller: emailController,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Email is required";
                        }
                        return null;
                      },
                      cursorColor: Colors.lightBlueAccent,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.email_outlined),
                        hintText: 'Enter your email',
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: Colors.lightBlueAccent, width: 2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: passwordController,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Password is required";
                        }
                        return null;
                      },
                      cursorColor: Colors.lightBlueAccent,
                      obscureText: visibilityStatus,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                visibilityStatus = !visibilityStatus;
                              });
                            },
                            icon: visibilityStatus
                                ? const Icon(
                              Icons.visibility_off,
                              color: Colors.lightBlueAccent,
                            )
                                : const Icon(
                              Icons.visibility,
                              color: Colors.lightBlueAccent,
                            )),
                        hintText: 'Enter your password',
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: Colors.lightBlueAccent, width: 2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () {},
                          child: const Text(
                            'Forgot password',
                            style: TextStyle(color: Colors.lightBlueAccent),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.lightBlueAccent,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 80, vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        onPressed: loginAdmin,
                        child: const Text(
                          "Login",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        )),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Don't have an account? "),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                  builder: (context) => RegisterPageAdmin(),
                                ));
                          },
                          child: const Text(
                            'Sign Up here',
                            style: TextStyle(
                              color: Colors.lightBlue,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
