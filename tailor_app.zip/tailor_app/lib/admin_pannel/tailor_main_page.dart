import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tailor_app/admin_pannel/measurement_tailor.dart';
import 'package:tailor_app/admin_pannel/notification_tailor.dart';
import 'package:tailor_app/admin_pannel/order_screen.dart';
import 'package:tailor_app/admin_pannel/setting_tailor.dart';
import 'package:tailor_app/admin_pannel/summary_screen.dart';
import 'package:tailor_app/selection_page.dart';

class HomeScreenTailor extends StatelessWidget {
  const HomeScreenTailor({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const SelectionPage(),));
          }, icon: const Icon(Icons.logout))
        ],
        leading: const Icon(Icons.ac_unit),
        centerTitle: true,
        title: const Text("Stitch & Pro",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 32),),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Welcome to StitchPro – Where Precision Meets Perfection in Tailoring!",
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  buildMenuItem(Icons.shopping_cart, "Orders", context,OrderScreenAdmin()),
                  buildMenuItem(Icons.scale, "Measurement", context,MeasurementManagementAdmin()),
                  buildMenuItem(Icons.notifications, "Notifications", context,AdminNotificationScreen()),
                  buildMenuItem(Icons.calendar_month, "Summary", context,AdminSummaryScreen()),
                  buildMenuItem(Icons.settings, "Settings", context,SettingScreenTailor()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMenuItem(IconData icon, String title, BuildContext context, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.lightBlueAccent),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
