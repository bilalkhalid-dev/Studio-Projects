import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../app_database/Firebase_database.dart';
import '../app_database/auth_service.dart';
import '../firebase_integration/toast_message.dart';
import 'login_pannel_admin.dart';

class RegisterPageAdmin extends StatefulWidget {
  const RegisterPageAdmin({super.key});

  @override
  State<RegisterPageAdmin> createState() => _RegisterPageAdminState();
}

class _RegisterPageAdminState extends State<RegisterPageAdmin> {
  final AppAuthService authService = AppAuthService();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool visibilityStatus = true;

  void clearControllers() {
    nameController.clear();
    emailController.clear();
    passwordController.clear();
    phoneController.clear();
  }

  void registerAdmin() async {
    if (formKey.currentState!.validate()) {
      setState(() => isLoading = true); // Loading start
      String email = emailController.text;
      String password = passwordController.text;
      String name = nameController.text;
      String phone = phoneController.text;

      try {
        User? user = await authService.signUpAdminToApp(email, password);
        if (user != null) {
          String adminID = user.uid;
          // Firestore Database mein admin ka role bhi store karain
          await MyFireStoreDB.addAdminToDB(adminID: adminID, userName: name, email: email, phoneNumber: phone, role: "admin");

          showToast(message: "Admin Registered Successfully");

          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const LoginPageAdmin()),
          );
        } else {
          showToast(message: "Admin creation failed.");
        }
      } catch (e) {
        showToast(message: "Error: ${e.toString()}");
      } finally {
        setState(() => isLoading = false); // Stop loading
      }
    } else {
      showToast(message: "Registration Failed! Check all fields.");
      clearControllers();
    }
  }


  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) return "Password is required";
    if (value.length < 8) return "Password must be at least 8 characters";
    if (!RegExp(r"[0-9]").hasMatch(value)) return "Must include at least one digit";
    if (!RegExp(r"[/!@#\$%^&*()+=]").hasMatch(value)) return "Must include a special character";
    if (!RegExp(r"[A-Z]").hasMatch(value)) return "Must include an uppercase letter";
    if (!RegExp(r"[a-z]").hasMatch(value)) return "Must include a lowercase letter";
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 150, horizontal: 20),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Sign-Up Page ADMIN',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.lightBlueAccent,
                      ),
                    ),
                    const SizedBox(height: 50),
                    _buildTextField(nameController, "Enter your Name", Icons.person),
                    const SizedBox(height: 20),
                    _buildTextField(emailController, "Enter your Email", Icons.email_outlined),
                    const SizedBox(height: 20),
                    _buildTextField(phoneController, "Enter your Phone", Icons.phone, isNumber: true),
                    const SizedBox(height: 20),
                    _buildPasswordField(),
                    const SizedBox(height: 50),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlueAccent,
                        padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onPressed: registerAdmin,
                      child: const Text(
                        "Register",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Already have an account? "),
                        GestureDetector(
                          onTap: () => Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (context) => const LoginPageAdmin()),
                          ),
                          child: const Text(
                            'Sign-in',
                            style: TextStyle(
                              color: Colors.lightBlue,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {bool isNumber = false}) {
    return TextFormField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      validator: (value) => value!.isEmpty ? "$hint is required" : null,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: passwordController,
      obscureText: visibilityStatus,
      validator: validatePassword,
      decoration: InputDecoration(
        prefixIcon: const Icon(Icons.lock),
        suffixIcon: IconButton(
          icon: Icon(
            visibilityStatus ? Icons.visibility_off : Icons.visibility,
            color: Colors.lightBlueAccent,
          ),
          onPressed: () => setState(() => visibilityStatus = !visibilityStatus),
        ),
        hintText: 'Enter your password',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }
}
