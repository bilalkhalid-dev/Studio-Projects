import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminNotificationScreen extends StatefulWidget {
  const AdminNotificationScreen({super.key});

  @override
  _AdminNotificationScreenState createState() => _AdminNotificationScreenState();
}

class _AdminNotificationScreenState extends State<AdminNotificationScreen> {
  final CollectionReference notificationsCollection = FirebaseFirestore.instance.collection("notifications");

  Future<List<Map<String, dynamic>>> fetchNotifications() async {
    try {
      QuerySnapshot snapshot = await notificationsCollection.orderBy("timestamp", descending: true).get();
      return snapshot.docs.map((doc) {
        return {
          "id": doc.id,
          "orderID": doc["orderID"],
          "userID": doc["userID"],
          "message": doc["message"],
          "status": doc["status"],
        };
      }).toList();
    } catch (e) {
      debugPrint("Error fetching notifications: $e");
      return [];
    }
  }

  void updateOrderStatus(String orderID, String notificationID, String newStatus) async {
    try {
      await FirebaseFirestore.instance.collection("orders").doc(orderID).update({"status": newStatus});
      await notificationsCollection.doc(notificationID).delete();

      setState(() {}); // Refresh the screen
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Order marked as $newStatus")),
      );
    } catch (e) {
      debugPrint("Error updating order status: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Notifications"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("notifications")
            .orderBy("timestamp", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No new notifications."));
          }

          List<QueryDocumentSnapshot> notifications = snapshot.data!.docs;

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              var notification = notifications[index];
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 4,
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  title: Text(notification['message']),
                  subtitle: Text("Contact No: ${notification['userID']}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check_circle, color: Colors.green),
                        onPressed: () => updateOrderStatus(
                          notification['orderID'],
                          notification.id,
                          "Accepted",
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.cancel, color: Colors.red),
                        onPressed: () => updateOrderStatus(
                          notification['orderID'],
                          notification.id,
                          "Declined",
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
