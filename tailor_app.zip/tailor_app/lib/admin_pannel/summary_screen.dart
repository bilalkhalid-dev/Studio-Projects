import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class AdminSummaryScreen extends StatefulWidget {
  const AdminSummaryScreen({super.key});

  @override
  AdminSummaryScreenState createState() => AdminSummaryScreenState();
}

class AdminSummaryScreenState extends State<AdminSummaryScreen> {
  String selectedStatus = "All";
  DateTime today = DateTime.now();
  DateTime sevenDaysAgo = DateTime.now().subtract(const Duration(days: 7));
  DateTime thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));

  /// 🔹 **Filter Orders Based on Date & Status**
  List<Map<String, dynamic>> filterOrders(
      List<Map<String, dynamic>> orders, String filterType) {
    DateTime startDate;

    if (filterType == "Daily") {
      startDate = DateTime(today.year, today.month, today.day);
    } else if (filterType == "Weekly") {
      startDate = sevenDaysAgo;
    } else {
      startDate = thirtyDaysAgo;
    }

    return orders.where((order) {
      bool dateCondition = order['timestamp'].isAfter(startDate);
      bool statusCondition =
          selectedStatus == "All" || order['status'] == selectedStatus;
      return dateCondition && statusCondition;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Admin Summary"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("orders")
            .orderBy("timestamp", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No orders found."));
          }

          List<Map<String, dynamic>> orders = snapshot.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;

            return {
              "id": doc.id,
              "name": data.containsKey("name") ? data["name"] : "N/A",
              "number": data.containsKey("number") ? data["number"] : "N/A",
              "category": data.containsKey("category") ? data["category"] : "N/A",
              "status": data.containsKey("status") ? data["status"] : "Unknown",
              "timestamp": data.containsKey("timestamp")
                  ? (data["timestamp"] as Timestamp).toDate()
                  : DateTime.now(),
            };
          }).toList();


          List<Map<String, dynamic>> dailyOrders = filterOrders(orders, "Daily");
          List<Map<String, dynamic>> weeklyOrders = filterOrders(orders, "Weekly");
          List<Map<String, dynamic>> monthlyOrders = filterOrders(orders, "Monthly");

          return Column(
            children: [
              /// 🔹 **Summary Cards**
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    summaryCard("Daily Orders", dailyOrders.length, Colors.orange),
                    summaryCard("Weekly Orders", weeklyOrders.length, Colors.blue),
                    summaryCard("Monthly Orders", monthlyOrders.length, Colors.green),
                  ],
                ),
              ),

              /// 🔹 **Status Filter Dropdown**
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                child: DropdownButton<String>(
                  value: selectedStatus,
                  isExpanded: true,
                  items: ["All", "Pending", "Completed", "Rejected"]
                      .map((status) => DropdownMenuItem(
                    value: status,
                    child: Text(status),
                  ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedStatus = value!;
                    });
                  },
                ),
              ),

              /// 🔹 **Orders List**
              Expanded(
                child: ListView.builder(
                  itemCount: filterOrders(orders, "Monthly").length,
                  itemBuilder: (context, index) {
                    var order = filterOrders(orders, "Monthly")[index];
                    return Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 4,
                      margin: const EdgeInsets.all(10),
                      child: ListTile(
                        title: Text("Order ID: ${order['id']}"),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Name: ${order['name']}"),
                            Text("Number: ${order['number']}"),
                            Text("Category: ${order['category']}"),
                            Text("Status: ${order['status']}", style: const TextStyle(fontWeight: FontWeight.bold)),
                            Text("Date: ${DateFormat.yMMMd().format(order['timestamp'])}"),
                          ],
                        ),

                        trailing: Icon(
                          order['status'] == "Completed"
                              ? Icons.check_circle
                              : order['status'] == "Pending"
                              ? Icons.pending
                              : Icons.cancel,
                          color: order['status'] == "Completed"
                              ? Colors.green
                              : order['status'] == "Pending"
                              ? Colors.orange
                              : Colors.red,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  /// 🔹 **Summary Card Widget**
  Widget summaryCard(String title, int count, Color color) {
    return Card(
      color: color,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Text(title,
                style: const TextStyle(
                    color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(count.toString(),
                style: const TextStyle(
                    color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
