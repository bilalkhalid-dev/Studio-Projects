import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';

void showToast({String? message}) {
  if (kDebugMode) {
    print("Toast Message: $message");
  } //  Debugging
  Fluttertoast.showToast(
    msg: message ?? "Something went wrong!",
    toastLength: Toast.LENGTH_SHORT,
    gravity: ToastGravity.BOTTOM, // ✅ Remove setGravity error
  );
}

