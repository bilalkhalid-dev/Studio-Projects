import 'package:flutter/material.dart';

import 'measurement.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  List<Map<String, String>> categories = [
    {
      "image": "https://pluspng.com/img-png/shirt-hd-png-dress-shirt-png-hd-png-image-480.png",
      "title": "Casual-Shirt"
    },
    {
      "image": "https://tse4.mm.bing.net/th?id=OIP.6p7b1txdEJ0mrCmV0wx-jQHaHa&pid=Api&P=0&h=220",
      "title": "Pent"
    },
    {
      "image": "https://pngimg.com/uploads/hoodie/hoodie_PNG22.png",
      "title": "Hoodie"
    },
    {
      "image": "https://tse4.mm.bing.net/th?id=OIP.vFpLGKu54O5UdnLeeBzpZgHaKY&pid=Api&P=0&h=220",
      "title": "Jacket"
    },
    {
      "image": "https://tse4.mm.bing.net/th?id=OIP.vBMsTBEScd91bLn5Dry6IQHaHa&pid=Api&P=0&h=220",
      "title": "Trouser"
    },
    {
      "image": "https://tse2.mm.bing.net/th?id=OIP.A1ej8POvvlIMX1bf7dUiBgHaHO&pid=Api&P=0&h=220",
      "title": "T-Shirt"
    },
    {
      "image": "https://pakistaniladies.com/wp-content/uploads/2016/11/New-Fashion-of-Men-Boys-Gents-Shalwar-Kameez-Designs-2017-2018-PKR-5685.jpg",
      "title": "Shalwar Kameez"
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: const Text(
          "Categories",
          style: TextStyle(
              fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          shrinkWrap: true,
          itemCount: categories.length, // Number of categories
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.7,
          ),
          itemBuilder: (context, index) {
            return buildMenuItem(
                categories[index]["image"]!,
                categories[index]["title"]!,
                context,
                MeasurementScreen(categoryName: categories[index]["title"]!)
            );
          },

        ),
      ),
    );
  }

  Widget buildMenuItem(
      String imagePath, String title, BuildContext context, Widget screen) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              child: Image.network(
                imagePath,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => screen));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent.shade400,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              ),
              child: const Text("Measurement", style: TextStyle(color: Colors.white)),
            ),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}