import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MeasurementManagementUser extends StatefulWidget {
  const MeasurementManagementUser({super.key});

  @override
  MeasurementManagementUserState createState() => MeasurementManagementUserState();
}

class MeasurementManagementUserState extends State<MeasurementManagementUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit Measurements"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("orders") // 🔥 "orders" collection fetch karega
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No measurements found."));
          }

          List<QueryDocumentSnapshot> orders = snapshot.data!.docs;

          return ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              var order = orders[index];
              Map<String, dynamic> measurements = order['measurements'] ?? {};
              String name = order['name'] ?? "Unknown";
              String phone = order['number'] ?? "N/A";
              String orderId = order.id;
              String category = order['category'] ?? "Unknown";

              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 4,
                margin: const EdgeInsets.all(10),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Order ID: $orderId",
                        style: const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      Text(
                        "Customer: $name",
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "Phone: $phone",
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Measurements:",
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      for (var key in measurements.keys) // 🔥 Measurements ko dynamically list karega
                        Text("$key: ${measurements[key]}", style: const TextStyle(fontSize: 16)),

                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ElevatedButton(
                            onPressed: (){ _editMeasurement(orderId, measurements,category);},
                            child: const Text("Edit"),
                          ),
                          ElevatedButton(
                            onPressed: () => _deleteMeasurement(orderId),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                            child: const Text("Delete",style: TextStyle(color: Colors.white),),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // 📌 Edit Measurement Function
  void _editMeasurement(String orderId, Map<String, dynamic> measurements, String category) {
    Map<String, List<String>> categoryMeasurements = {
      'Casual-Shirt': [
        'Chest',
        'Shoulder',
        'Sleeve Length',
        'Neck',
        'Waist',
        'Shirt Length',
        'Cuff Size'
      ],
      'Hoodie': [
        'Chest',
        'Shoulder',
        'Sleeve Length',
        'Neck',
        'Hoodie Length',
        'Waist',
        'Hip',
        'Cuff Size',
        'Armhole',
        'Hood Size'
      ],
      'T-Shirt': [
        'Chest',
        'Shoulder',
        'Sleeve Length',
        'Waist',
        'Shirt Length',
        'Armhole'
      ],
      'Jacket': [
        'Chest',
        'Shoulder',
        'Sleeve Length',
        'Neck',
        'Jacket Length',
        'Waist',
        'Hip',
        'Cuff Size',
        'Armhole'
      ],
      'Pent': [
        'Waist',
        'Hip',
        'Thigh',
        'Knee',
        'Calf',
        'Inseam Length',
        'Outseam Length',
        'Bottom Width'
      ],
      'Trouser': [
        'Waist',
        'Hip',
        'Thigh',
        'Knee',
        'Calf',
        'Inseam Length',
        'Outseam Length',
        'Bottom Width'
      ],
      'Shalwar Kameez': [
        'Chest',
        'Shoulder',
        'Sleeve Length',
        'Kameez Length',
        'Neck',
        'Waist',
        'Armhole',
        'Waist',
        'Hip',
        'Thigh',
        'Shalwar Length',
        'Bottom Width'
      ],
    };

    // 🛑 Agar category match nahi hoti, toh default empty list.
    List<String> fields = categoryMeasurements[category] ?? [];

    // Controllers ka map banayenge jisse dynamically text fields generate hon.
    Map<String, TextEditingController> controllers = {};
    for (var field in fields) {
      controllers[field] = TextEditingController(text: measurements[field]?.toString() ?? '');
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Edit Measurement - $category"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: fields.map((field) {
                return TextField(
                  controller: controllers[field],
                  decoration: InputDecoration(labelText: field),
                  keyboardType: TextInputType.number,
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () async {
                Map<String, dynamic> updatedMeasurements = {};
                for (var field in fields) {
                  updatedMeasurements["measurements.$field"] = int.tryParse(controllers[field]!.text) ?? 0;
                }

                await FirebaseFirestore.instance.collection("orders").doc(orderId).update(updatedMeasurements);
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }


  // 📌 Delete Measurement Function
  void _deleteMeasurement(String orderId) async {
    await FirebaseFirestore.instance.collection("orders").doc(orderId).delete(); // ✅ Pura document delete karega

    setState(() {}); // ✅ UI ko refresh karega
  }

}
