import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tailor_app/user_pannel/main_page_user.dart';
import '../firebase_integration/toast_message.dart';

class MeasurementScreen extends StatelessWidget {


  Future<void> sendPushNotification(String token, String name, String number) async {
    const String serverKey = "YOUR_SERVER_KEY"; // Firebase server key yahan dalain
    const String fcmUrl = "https://fcm.googleapis.com/fcm/send";

    final data = {
      "to": token,
      "notification": {
        "title": "New Measurement Added",
        "body": "Name: $name, Number: $number",
        "sound": "default"
      },
      "data": {
        "click_action": "FLUTTER_NOTIFICATION_CLICK",
        "status": "done"
      }
    };

    try {
      final response = await http.post(
        Uri.parse(fcmUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "key=$serverKey"
        },
        body: jsonEncode(data),
      );

      if (response.statusCode == 200) {
        print("Notification Sent Successfully!");
      } else {
        print("Error Sending Notification: ${response.body}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  final String categoryName;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController numberController = TextEditingController();
  final Map<String, TextEditingController> controllers = {};

  MeasurementScreen({super.key, required this.categoryName});

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final Map<String, List<String>> measurementFields = {
    'Casual-Shirt': [
      'Chest',
      'Shoulder',
      'Sleeve Length',
      'Neck',
      'Waist',
      'Shirt Length',
      'Cuff Size'
    ],
    'Hoodie': [
      'Chest',
      'Shoulder',
      'Sleeve Length',
      'Neck',
      'Hoodie Length',
      'Waist',
      'Hip',
      'Cuff Size',
      'Armhole',
      'Hood Size'
    ],
    'T-Shirt': [
      'Chest',
      'Shoulder',
      'Sleeve Length',
      'Waist',
      'Shirt Length',
      'Armhole'
    ],
    'Jacket': [
      'Chest',
      'Shoulder',
      'Sleeve Length',
      'Neck',
      'Jacket Length',
      'Waist',
      'Hip',
      'Cuff Size',
      'Armhole'
    ],
    'Pent': [
      'Waist',
      'Hip',
      'Thigh',
      'Knee',
      'Calf',
      'Inseam Length',
      'Outseam Length',
      'Bottom Width'
    ],
    'Trouser': [
      'Waist',
      'Hip',
      'Thigh',
      'Knee',
      'Calf',
      'Inseam Length',
      'Outseam Length',
      'Bottom Width'
    ],
    'Shalwar Kameez': [
      'Chest',
      'Shoulder',
      'Sleeve Length',
      'Kameez Length',
      'Neck',
      'Waist',
      'Armhole',
      'Waist',
      'Hip',
      'Thigh',
      'Shalwar Length',
      'Bottom Width'
    ],
  };

  @override
  Widget build(BuildContext context) {
    final fields = measurementFields[categoryName] ?? [];
    controllers.clear();
    for (var field in fields) {
      controllers[field] = TextEditingController();
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(categoryName,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                TextFormField(
                  clipBehavior: Clip.antiAlias,
                  autocorrect: true,
                  controller: nameController,
                  decoration: const InputDecoration(labelText: "Name"),
                  validator: (value) =>
                      value == null || value.isEmpty ? "Required" : null,
                ),
                TextFormField(
                  controller: numberController,
                  decoration: const InputDecoration(labelText: "Number"),
                  keyboardType: TextInputType.phone,
                  validator: (value) =>
                      value == null || value.isEmpty ? "Required" : null,
                ),
                ...fields.map((field) => buildMeasurementRow(field)).toList(),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: (){
                    addMeasurement(context);
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.lightBlueAccent.shade700),
                  child:
                      const Text('Save', style: TextStyle(color: Colors.black)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildMeasurementRow(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(child: buildLabelBox(label)),
          const SizedBox(width: 10),
          SizedBox(
            width: 80,
            child: TextFormField(
              controller: controllers[label],
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.white),
              textAlign: TextAlign.center,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return "Required";
                }
                if (!RegExp(r'^\d+(\.\d+)?$').hasMatch(value)) {
                  return "Invalid";
                }
                return null;
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLabelBox(String text) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
          color: Colors.blueAccent.shade100,
          borderRadius: BorderRadius.circular(8)),
      child: Text(text,
          style: const TextStyle(fontWeight: FontWeight.bold),
          textAlign: TextAlign.center),
    );
  }
  void addMeasurement(BuildContext context) async {
    if (!formKey.currentState!.validate()) return;

    String name = nameController.text.trim();
    String number = numberController.text.trim();

    if (name.isEmpty || number.isEmpty || categoryName.isEmpty) {
      showToast(message: "Fill All Fields");
      return;
    }

    Map<String, double> measurements = {};
    controllers.forEach((key, controller) {
      double? value = double.tryParse(controller.text);
      measurements[key] = value ?? 0.0;
    });

    try {
      // Measurement Firebase Firestore mein store karna
      DocumentReference orderRef = await FirebaseFirestore.instance.collection("orders").add({
        "name": name,
        "number": number,
        "category": categoryName, // ✅ Category ka naam add kiya
        "measurements": measurements,
        "status": "Pending",
        "timestamp": FieldValue.serverTimestamp(),
      });

      // Notification Firebase Firestore mein store karna
      await FirebaseFirestore.instance.collection("notifications").add({
        "orderID": orderRef.id,
        "userID": number, // Assuming user ID is their number
        "message": "New measurement added by $name for $categoryName.", // ✅ Category ko bhi message mein add kiya
        "status": "Pending",
        "timestamp": FieldValue.serverTimestamp(),
      });

      showToast(message: "Data saved successfully");

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const HomeScreenUser()),
      );
    } catch (e) {
      showToast(message: "Error: ${e.toString()}");
    }
  }
}