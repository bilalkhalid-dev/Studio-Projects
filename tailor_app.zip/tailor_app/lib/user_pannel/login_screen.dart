import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tailor_app/user_pannel/main_page_user.dart';
import 'package:tailor_app/user_pannel/registration_screen.dart';
import '../app_database/Firebase_database.dart';
import '../app_database/auth_service.dart';
import '../firebase_integration/toast_message.dart';
import '../selection_page.dart';
class LoginPageUser extends StatefulWidget {
  const LoginPageUser({super.key});

  @override
  State<LoginPageUser> createState() => LoginPageUserState();
}

class LoginPageUserState extends State<LoginPageUser> {
  AppAuthService authService = AppAuthService();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool visibilityStatus = true;
  GlobalKey<FormState> form = GlobalKey();
  bool isLoading = false;

  void clearController() {
    emailController.clear();
    passwordController.clear();
  }

  void loginUser() async {
    if (form.currentState!.validate()) {
      setState(() => isLoading = true); // Start loading

      String email = emailController.text.trim();
      String password = passwordController.text.trim();

      try {
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );

        User? user = userCredential.user;
        if (user != null) {
          DocumentSnapshot? userDoc = await MyFireStoreDB.getUserFromDB(user.uid);

          if (userDoc != null && userDoc.exists && userDoc['role'] == 'user') {
            showToast(message: "User Login Successful!");
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => const HomeScreenUser()),
            );
          } else {
            showToast(message: "User credentials required");
            FirebaseAuth.instance.signOut();
          }
        } else {
          showToast(message: "Login failed. Try again.");
        }
      } catch (e) {
        showToast(message: "Error: ${e.toString()}");
      } finally {
        setState(() => isLoading = false); // Stop loading
      }
    } else {
      showToast(message: "Login Failed! Check email & password.");
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: IconButton(onPressed: (){Navigator.of(context).pop(MaterialPageRoute(builder: (context) => const SelectionPage(),));}, icon: Icon(Icons.arrow_back_outlined)),),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 180, horizontal: 20),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Form(
                key: form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      ' USER LOGIN',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.lightBlueAccent,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 50),
                    TextFormField(
                      controller: emailController,
                      validator: (value) =>
                      value!.isEmpty ? "Email is required" : null,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.email_outlined),
                        hintText: 'Enter your email',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: passwordController,
                      validator: (value) =>
                      value!.isEmpty ? "Password is required" : null,
                      obscureText: visibilityStatus,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              visibilityStatus = !visibilityStatus;
                            });
                          },
                          icon: Icon(
                            visibilityStatus
                                ? Icons.visibility_off
                                : Icons.visibility,
                            color: Colors.lightBlueAccent,
                          ),
                        ),
                        hintText: 'Enter your password',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () {
                            if (emailController.text.isNotEmpty) {
                              FirebaseAuth.instance.sendPasswordResetEmail(
                                  email: emailController.text);
                              showToast(message: "Password reset email sent");
                            } else {
                              showToast(message: "Enter email first");
                            }
                          },
                          child: const Text(
                            'Forgot password?',
                            style: TextStyle(color: Colors.lightBlueAccent),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    isLoading
                        ? const CircularProgressIndicator()
                        : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlueAccent,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 80, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onPressed: loginUser,
                      child: const Text(
                        "Login",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Don't have an account? "),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (context) => RegisterPageUser()));
                          },
                          child: const Text(
                            'Sign Up here',
                            style: TextStyle(
                              color: Colors.lightBlue,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
