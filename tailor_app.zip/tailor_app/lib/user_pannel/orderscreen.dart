import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class OrderScreenUser extends StatefulWidget {
  const OrderScreenUser({super.key});

  @override
  OrderScreenUserState createState() => OrderScreenUserState();
}

class OrderScreenUserState extends State<OrderScreenUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All Orders - User"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("orders")
            .orderBy("timestamp", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No orders found."));
          }

          List<QueryDocumentSnapshot> orders = snapshot.data!.docs;

          // Category-wise orders count karna
          Map<String, int> categoryOrderCount = {};
          for (var order in orders) {
            String category = order["category"] ?? "Unknown";
            categoryOrderCount[category] = (categoryOrderCount[category] ?? 0) + 1;
          }

          return ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              var order = orders[index];
              String category = order['category'] ?? 'Unknown';
              int orderCount = categoryOrderCount[category] ?? 1; // ✅ Category-wise order count

              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 4,
                margin: const EdgeInsets.all(10),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "User ID: ${order.id}",
                        style: const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      Text(
                        "Category: $category",
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Order Quantity: $orderCount",
                        style: const TextStyle(fontSize: 16),
                      ),
                      Text(
                        "Customer Name: ${order['name']}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      Text(
                        "Customer Number: ${order['number']}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Measurements: ${order['measurements'] ?? {}}",
                        style: const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Status: ${order['status'] ?? 'Pending'}",
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.lightBlueAccent,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Icon(Icons.assignment, color: Colors.blue),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
