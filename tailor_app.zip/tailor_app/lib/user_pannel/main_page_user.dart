import 'package:flutter/material.dart';
import 'package:tailor_app/selection_page.dart';
import 'package:tailor_app/user_pannel/Edit_measurement.dart';
import 'package:tailor_app/user_pannel/aboutscreenuser.dart';
import 'package:tailor_app/user_pannel/orderscreen.dart';
import 'package:tailor_app/user_pannel/setting_screen_user.dart';
import 'category.dart';
import 'design.dart';

class HomeScreenUser extends StatelessWidget {
  const HomeScreenUser({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [IconButton(onPressed: (){Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => SelectionPage(),));}, icon: Icon(Icons.power_settings_new_outlined,size: 28,))],
        leading: const Icon(Icons.ac_unit),
        centerTitle: true,
        title: const Text("Stitch & Pro",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 32),),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Welcome to StitchPro – Where Precision Meets Perfection in Tailoring!",
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  buildMenuItem(Icons.category_sharp, "Categories", context,const CategoryScreen()),
                  buildMenuItem(Icons.shopping_cart, "Orders", context, OrderScreenUser()),
                  buildMenuItem(Icons.design_services, "Designs", context,DesignScreen()),
                  buildMenuItem(Icons.scale, "Edit Measurements", context, MeasurementManagementUser()),
                  buildMenuItem(Icons.settings, "Setting", context,SettingScreenUser()),
                  buildMenuItem(Icons.person, "About us", context,AboutUsScreenUser()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMenuItem(IconData icon, String title, BuildContext context, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.lightBlueAccent),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
