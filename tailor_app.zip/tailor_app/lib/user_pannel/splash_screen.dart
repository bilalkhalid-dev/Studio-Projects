import 'dart:async';
import 'package:flutter/material.dart';
import 'package:tailor_app/selection_page.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<double> bounceAnimation;

  @override
  void initState() {
    super.initState();

    // Initialize AnimationController
    animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    // Fade-in animation
    fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(animationController);

    // Bounce-out animation
    bounceAnimation = CurvedAnimation(
      parent: animationController,
      curve: Curves.linear,
    );

    // Navigate to the next screen after 4 seconds
    Timer(const Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => SelectionPage()),
      );
    });

    // Start the animations
    animationController.forward();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.grey.shade300,
        child: Center(
          child: FadeTransition(
            opacity: fadeAnimation,
            child: AnimatedBuilder(
              animation: bounceAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, -50 * (1 - bounceAnimation.value)), // Bounce effect
                  child: child,
                );
              },
              child: Image.asset(
                "asset/images/tailor.png",
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ),
    );
  }
}