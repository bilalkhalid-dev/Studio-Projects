import 'package:flutter/material.dart';

class AboutUsScreenUser extends StatefulWidget {
  const AboutUsScreenUser({super.key});

  @override
  _AboutUsScreenUserState createState() => _AboutUsScreenUserState();
}

class _AboutUsScreenUserState extends State<AboutUsScreenUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("About Us"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Logo
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.lightBlue[100],
              ),
              child: const Icon(Icons.store, size: 50, color: Colors.lightBlueAccent),
            ),
            const SizedBox(height: 16),
            // App Name
            const Text(
              "Stitch Pro",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.lightBlueAccent,
              ),
            ),
            const SizedBox(height: 8),
            // Short Description
            const Text(
              "We provide the best quality garments with premium fabric and custom fitting. Our goal is to bring comfort and style together.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 20),
            // Features
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("High-Quality Garments"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("Custom Fitting Available"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("Fast & Reliable Delivery"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("High-Quality Garments"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("Custom Fitting Available"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("Fast & Reliable Delivery"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("High-Quality Garments"),
            ),
            const ListTile(
              leading: Icon(Icons.check_circle, color: Colors.lightBlueAccent),
              title: Text("Custom Fitting Available"),
            ),
            const Spacer(),
            // Contact Us Section
            const Text(
              "Contact Us",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.lightBlueAccent,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Email: bilalsidhu0077@gmail.com\nPhone: +92 3007077618",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black87),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
