import 'package:flutter/material.dart';
import 'measurement.dart';

class DesignScreen extends StatelessWidget {
  DesignScreen({super.key});

  final List<Map<String, dynamic>> categories = [
    {
      "images": [
        "https://pluspng.com/img-png/shirt-hd-png-dress-shirt-png-hd-png-image-480.png",
        "https://tse3.mm.bing.net/th?id=OIP.AhD6OCBhPIQWy6sJ8ehb4gHaHa&pid=Api&P=0&h=220",
        "https://tse1.mm.bing.net/th?id=OIP.2AgJVwFREk6cPm9noVTZTQHaHa&pid=Api&P=0&h=220"
      ],
      "title": "Casual-Shirt",
      "details": [
        "Fabric: Premium Cotton",
        "Sleeves: Full & Half Sleeves Available",
        "Collar: Standard & Spread Collar Options",
        "Fit: Slim Fit / Regular Fit",
        "Custom Embroidery Option Available"
      ]
    },
    {
      "images": [
        "https://tse4.mm.bing.net/th?id=OIP.6p7b1txdEJ0mrCmV0wx-jQHaHa&pid=Api&P=0&h=220",
        "https://tse1.mm.bing.net/th?id=OIP.XLfmUxwjiKdfKRqJDj8M0gHaPf&pid=Api&P=0&h=220",
        "https://tse2.mm.bing.net/th?id=OIP.pOzEiVgt1SgxQVhmgF8W9gAAAA&pid=Api&P=0&h=220"
      ],
      "title": "Pant",
      "details": [
        "Fabric: Denim / Cotton / Formal Suiting",
        "Fit: Slim, Regular & Loose Fit Available",
        "Waistband: Elastic & Belt Loop Options",
        "Pockets: Side & Back Pockets",
        "Available in Multiple Colors"
      ]
    },
    {
      "images": [
        "https://pngimg.com/uploads/hoodie/hoodie_PNG22.png",
        "https://tse4.mm.bing.net/th?id=OIP.tlTOYGsqFpTnUOAvMpYFOQHaJJ&pid=Api&P=0&h=220",
        "https://tse3.mm.bing.net/th?id=OIP.bX8URAz8QDX2bv3gY4hRigHaJQ&pid=Api&P=0&h=220"
      ],
      "title": "Hoodie",
      "details": [
        "Fabric: Fleece / Wool Blend",
        "Hood Type: Adjustable Drawstring Hood",
        "Pockets: Kangaroo Front Pocket",
        "Warm Inner Lining for Winters",
        "Custom Prints & Logos Available"
      ]
    },
    {
      "images": [
        "https://tse4.mm.bing.net/th?id=OIP.vFpLGKu54O5UdnLeeBzpZgHaKY&pid=Api&P=0&h=220",
        "https://tse4.mm.bing.net/th?id=OIP.swUfmDEDENWkoeTDP_mPbgHaHa&pid=Api&P=0&h=220",
        "https://tse1.mm.bing.net/th?id=OIP.d1q4fm1UeMr8FegKmtj6OQHaIs&pid=Api&P=0&h=220"
      ],
      "title": "Jacket",
      "details": [
        "Fabric: High-Quality Wool",
        "Inner Lining: Soft Polyester",
        "Buttons: Premium Brass",
        "Pockets: 4 Front Pockets",
        "Customizable Fit Available"
      ]
    },
    {
      "images": [
        "https://tse4.mm.bing.net/th?id=OIP.vBMsTBEScd91bLn5Dry6IQHaHa&pid=Api&P=0&h=220",
        "https://tse4.mm.bing.net/th?id=OIP.PPbuuTiSXcoqm9co8GZAiAHaHa&pid=Api&P=0&h=220",
        "https://tse3.mm.bing.net/th?id=OIP.h1rzZ0gFg2UD1l8A6hPDEQHaHa&pid=Api&P=0&h=220"
      ],
      "title": "Trouser",
      "details": [
        "Fabric: Cotton / Stretchable Polyester",
        "Elastic Waistband with Drawstrings",
        "Pockets: Deep Side Pockets",
        "Comfortable for Sports & Casual Wear",
        "Slim & Regular Fit Available"
      ]
    },
    {
      "images": [
        "https://tse2.mm.bing.net/th?id=OIP.A1ej8POvvlIMX1bf7dUiBgHaHO&pid=Api&P=0&h=220",
        "https://tse1.mm.bing.net/th?id=OIP.pXPYcCeogjMq6K_18Z2iSgHaJC&pid=Api&P=0&h=220",
        "https://tse2.mm.bing.net/th?id=OIP.Tl5-LL6Ipm53uPKDCq-BwgHaIz&pid=Api&P=0&h=220"
      ],
      "title": "T-Shirt",
      "details": [
        "Fabric: 100% Cotton / Dry-Fit Polyester",
        "Collar: Round Neck / V-Neck",
        "Fit: Regular / Athletic Fit",
        "Available in Multiple Colors",
        "Custom Printing Available"
      ]
    },
    {
      "images": [
        "https://pakistaniladies.com/wp-content/uploads/2016/11/New-Fashion-of-Men-Boys-Gents-Shalwar-Kameez-Designs-2017-2018-PKR-5685.jpg",
        "https://tse3.mm.bing.net/th?id=OIP.tCfp_CjM6_EICkOoqPLqrgHaLG&pid=Api&P=0&h=220",
        "https://tse1.mm.bing.net/th?id=OIP.k1IIAEpUcpWnW-qrD7tkqAAAAA&pid=Api&P=0&h=220"
      ],
      "title": "Shalwar Kameez",
      "details": [
        "Fabric: Cotton / Wash & Wear / Boski",
        "Shalwar Type: Normal / Straight / Pajama Style",
        "Embroidery & Fancy Button Options Available",
        "Available in Various Colors",
        "Custom Measurements Accepted"
      ]
    }
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: const Text(
          "Designs",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: categories.length,
          itemBuilder: (context, index) {
            return buildCategoryItem(
              categories[index]["images"] as List<String>,
              categories[index]["title"]!,
              categories[index]["details"] as List<String>,
              context,
            );
          },
        ),
      ),
    );
  }

  Widget buildCategoryItem(List<String> imagePaths, String title, List<String> details, BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 200,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: imagePaths.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.network(imagePaths[index], width: 200, height: 200, fit: BoxFit.cover),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...details.map((detail) => Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.lightBlueAccent, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(detail, style: const TextStyle(fontSize: 16))),
              ],
            )),
            const SizedBox(height: 10),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MeasurementScreen(categoryName: title),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.lightBlueAccent,
                  padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                ),
                child: const Text("Stitch", style: TextStyle(fontSize: 18, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
