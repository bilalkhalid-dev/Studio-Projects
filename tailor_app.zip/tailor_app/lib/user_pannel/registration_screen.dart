import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:tailor_app/user_pannel/login_screen.dart';
import '../app_database/Firebase_database.dart';
import '../app_database/auth_service.dart';
import '../firebase_integration/toast_message.dart';

class RegisterPageUser extends StatefulWidget {
  const RegisterPageUser({super.key});

  @override
  State<RegisterPageUser> createState() => RegisterPageUserState();
}

class RegisterPageUserState extends State<RegisterPageUser> {
  final AppAuthService authService = AppAuthService();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final GlobalKey<FormState> form = GlobalKey<FormState>();
  bool visibilityStatus = true;
  bool isLoading = false;

  void clearController() {
    nameController.clear();
    emailController.clear();
    passwordController.clear();
    phoneController.clear();
  }

  Future<void> registerUser() async {
    if (!form.currentState!.validate()) {
      showToast(message: "Please fill in all required fields correctly.");
      return;
    }

    setState(() => isLoading = true);
    try {
      User? user = await authService.signUpUserToApp(
          emailController.text, passwordController.text);
      if (user != null) {
        await MyFireStoreDB.addUserToDB(
            userID: user.uid,
            userName: nameController.text,
            email: emailController.text,
            phoneNumber: phoneController.text, role: 'user',
        );

        showToast(message: "Registration Successful");
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const LoginPageUser()),
        );
      } else {
        showToast(message: "Registration failed. Please try again.");
      }
    } catch (e) {
      showToast(message: "Error: ${e.toString()}");
      if (kDebugMode) print("Registration Error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return "Password is required";
    }
    if (value.length < 8 ||
        !RegExp(r"[0-9]").hasMatch(value) ||
        !RegExp(r"[!@#%^&*()+=]").hasMatch(value) ||
        !RegExp(r"[A-Z]").hasMatch(value) ||
        !RegExp(r"[a-z]").hasMatch(value)) {
      return "Password must be at least 8 characters, include an uppercase, lowercase, number, and special character";
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 200, horizontal: 20),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 5),
                ],
              ),
              child: Form(
                key: form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Sign-Up Page USER', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
                    const SizedBox(height: 50),
                    _buildTextField(nameController, 'Enter your Name', Icons.person, "Name is required"),
                    _buildTextField(emailController, 'Enter your Email', Icons.email_outlined, "Valid email is required", TextInputType.emailAddress),
                    _buildTextField(phoneController, 'Enter your Phone', Icons.phone, "Phone number is required", TextInputType.phone),
                    TextFormField(
                      controller: passwordController,
                      validator: validatePassword,
                      obscureText: visibilityStatus,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock),
                        hintText: 'Enter your password',
                        suffixIcon: IconButton(
                          icon: Icon(visibilityStatus ? Icons.visibility_off : Icons.visibility, color: Colors.lightBlueAccent),
                          onPressed: () => setState(() => visibilityStatus = !visibilityStatus),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlueAccent, padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 15)),
                      onPressed: isLoading ? null : registerUser,
                      child: Text("Register", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Already have an account? "),
                        GestureDetector(
                          onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const LoginPageUser())),
                          child: const Text('Sign-in', style: TextStyle(color: Colors.lightBlue, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText, IconData icon, String validationMsg, [TextInputType keyboardType = TextInputType.text]) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        validator: (value) => value!.isEmpty ? validationMsg : null,
        decoration: InputDecoration(
          prefixIcon: Icon(icon),
          hintText: hintText,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
    );
  }
}
