import 'package:flutter/material.dart';

import 'styles_app.dart';

class CheckingTile extends StatelessWidget {
  const CheckingTile({
    super.key,
    required this.isCheck,
    required this.title,
  });

  final bool isCheck;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const SizedBox(
          width: 20,
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 500),
          height: 20,
          width: 20,
          decoration: BoxDecoration(
              color: isCheck ? Colors.green : Colors.transparent,
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: isCheck ? Colors.transparent : Colors.teal,
              )),
          child: Icon(
            Icons.check,
            size: 15,
            color: isCheck ? Colors.white : Colors.teal.shade400,
          ),
        ),
        const SizedBox(
          width: 10,
        ),
        Text(
          title,
          style: labelTextStyle,
        )
      ],
    );
  }
}
