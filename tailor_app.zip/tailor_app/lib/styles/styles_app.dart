import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

TextStyle get headingTextStyle {
  return GoogleFonts.montserrat(
      textStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.deepOrange,
      )
  );
}

TextStyle get appBarTextStyle {
  return GoogleFonts.montserrat(
      textStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.deepOrange,
      )

  );
}

TextStyle get subHeadingTextStyle {
  return GoogleFonts.montserrat(
      textStyle: const TextStyle(
        height: 1.5,
        fontSize: 14,
        color: Colors.white,
      )
  );
}

TextStyle get labelTextStyle {
  return GoogleFonts.montserrat(
      textStyle: const TextStyle(
        color: Colors.black,
      )
  );
}

TextStyle get hintTextStyle {
  return GoogleFonts.montserrat(
      textStyle: TextStyle(
        color: Colors.deepOrange.shade200,
      )
  );
}