import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:tailor_app/models/measurement_model.dart';
import 'package:tailor_app/user_pannel/main_page_user.dart';
import '../firebase_integration/toast_message.dart';
import '../models/user_model.dart';

class MyFireStoreDB {
  static final FirebaseFirestore fireStore = FirebaseFirestore.instance;
  static final CollectionReference userCollectionReference = fireStore.collection("user");
  static final CollectionReference adminCollectionReference = fireStore.collection("admin");
  static final CollectionReference dataCollectionReference = fireStore.collection("data");

  static BuildContext? get context => null;

  /// Method to add admin to Firestore Database
  static Future<void> addAdminToDB({
    required String adminID,
    required String userName,
    required String email,
    required String phoneNumber,
    required String role,
  }) async {
    try {
      UserModel userModel = UserModel(
        id: adminID,
        userName: userName,
        email: email,
        phoneNumber: phoneNumber,
        role: "admin", // ✅ Admin role add kiya
      );

      await adminCollectionReference.doc(adminID).set(userModel.toJson());

      showToast(message: "Admin added Successfully");

      // Context ka masla avoid karne ke liye Future.microtask use kiya
      Future.microtask(() {
        Navigator.of(context!).pushReplacement(
          MaterialPageRoute(builder: (context) => HomeScreenUser()),
        );
      });
    } catch (error) {
      if (kDebugMode) {
        print("Error adding admin: $error");
      }
      showToast(message: "Failed to add Admin: ${error.toString()}");
    }
  }

  ///  Admin Data Get Karne ka Function


  static Future<DocumentSnapshot?> getAdminFromDB(String adminID) async {
    try {
      DocumentSnapshot adminDoc = await adminCollectionReference.doc(adminID).get();
      if (adminDoc.exists) {
        return adminDoc;
      }
      return null;
    } catch (error) {
      if (kDebugMode) {
        print("Error fetching admin: $error");
      }
      return null;
    }
  }


  ///  User Data Get Karne ka Function


  static Future<DocumentSnapshot?> getUserFromDB(String userID) async {
    try {
      DocumentSnapshot userDoc = await userCollectionReference.doc(userID).get();
      if (userDoc.exists) {
        return userDoc;
      }
      return null;
    } catch (error) {
      if (kDebugMode) {
        print("Error fetching user: $error");
      }
      return null;
    }
  }

  /// User Add karne ka function


  static Future<void> addUserToDB({
    required String userID,
    required String userName,
    required String email,
    required String phoneNumber,
    required String role,
  }) async {
    try {
      UserModel userModel = UserModel(
        id: userID,
        userName: userName,
        email: email,
        phoneNumber: phoneNumber,
        role: 'user',
      );

      await userCollectionReference.doc(userID).set(userModel.toJson());

      showToast(message: "User added Successfully");
      Navigator.of(context!).pushReplacement(
        MaterialPageRoute(builder: (context) => HomeScreenUser()),
      );
    } catch (error) {
      if (kDebugMode) {
        print("Error adding user: $error");
      }
      showToast(message: "Failed to add User: ${error.toString()}");
    }
  }

  /// Get all users from Firestore


  static Stream<List<UserModel>> getAllUsers() {
    return userCollectionReference.snapshots().map((snapShot) {
      return snapShot.docs.map((doc) => UserModel.fromDocumentSnapshot(doc)).toList();
    });
  }

  ///fetch Measurment from database

  static Future<List<Map<String, dynamic>>> fetchMeasurements() async {
    List<Map<String, dynamic>> measurementList = [];

    try {
      QuerySnapshot categorySnapshot =
      await FirebaseFirestore.instance.collection("Measurement").get();

      for (var categoryDoc in categorySnapshot.docs) {
        String categoryName = categoryDoc.id; // Category name as ID

        QuerySnapshot recordsSnapshot = await FirebaseFirestore.instance
            .collection("Measurement")
            .doc(categoryName)
            .collection("Records")
            .get();

        int quantity = recordsSnapshot.docs.length; // Total orders in category

        for (var record in recordsSnapshot.docs) {
          var data = record.data() as Map<String, dynamic>;

          measurementList.add({
            "category": categoryName,
            "name": data["name"],
            "quantity": quantity, // Total records in this category
          });
        }
      }
    } catch (e) {
      print("Error fetching measurements: $e");
    }

    return measurementList;
  }
}