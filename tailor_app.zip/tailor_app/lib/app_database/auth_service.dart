import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../firebase_integration/toast_message.dart';

class AppAuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<User?> signUpUserToApp(String userEmail, String userPassword) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: userEmail, password: userPassword);
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case "email-already-in-use":
          showToast(message: "Email is already in use");
          break;
        case "weak-password":
          showToast(message: "Please use a stronger password");
          break;
        case "invalid-email":
          showToast(message: "Invalid email format");
          break;
        default:
          showToast(message: "Sign up failed: ${e.message}");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Sign up error: $e");
      }
      showToast(message: "An unexpected error occurred");
    }
    return null;
  }

  Future<User?> loginUserToApp(String userEmail, String userPassword) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: userEmail, password: userPassword);
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case "user-not-found":
          showToast(message: "No user found with this email");
          break;
        case "wrong-password":
          showToast(message: "Incorrect password");
          break;
        case "invalid-email":
          showToast(message: "Invalid email format");
          break;
        default:
          showToast(message: "Login failed: ${e.message}");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Login error: $e");
      }
      showToast(message: "An unexpected error occurred");
    }
    return null;
  }

  Future<User?> loginAdminToApp(String userEmail, String userPassword) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: userEmail, password: userPassword);
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case "user-not-found":
          showToast(message: "No user found with this email");
          break;
        case "wrong-password":
          showToast(message: "Incorrect password");
          break;
        case "invalid-email":
          showToast(message: "Invalid email format");
          break;
        default:
          showToast(message: "Login failed: ${e.message}");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Login error: $e");
      }
      showToast(message: "An unexpected error occurred");
    }
    return null;
  }

  Future<User?> signUpAdminToApp(String userEmail, String userPassword) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: userEmail, password: userPassword);
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case "email-already-in-use":
          showToast(message: "Email is already in use");
          break;
        case "weak-password":
          showToast(message: "Please use a stronger password");
          break;
        case "invalid-email":
          showToast(message: "Invalid email format");
          break;
        default:
          showToast(message: "Sign up failed: ${e.message}");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Sign up error: $e");
      }
      showToast(message: "An unexpected error occurred");
    }
    return null;
  }

  Future<void> logout() async {
    try {
      await _auth.signOut();
      showToast(message: "Signed out successfully");
    } catch (e) {
      if (kDebugMode) {
        print("Logout error: $e");
      }
      showToast(message: "Logout failed");
    }
  }
}
