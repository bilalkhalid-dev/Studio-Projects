import 'package:cloud_firestore/cloud_firestore.dart';

class MeasurementModel {
  final String id;
  final String name;
  final String number;
  final Map<String, double> measurements; // All dynamic measurements stored here

  MeasurementModel({
    required this.id,
    required this.name,
    required this.number,
    required this.measurements,
  });

  /// Factory constructor to safely handle Firestore data
  factory MeasurementModel.fromDocumentSnapshot(DocumentSnapshot documentSnapshot) {
    Map<String, dynamic> data = documentSnapshot.data() as Map<String, dynamic>;

    return MeasurementModel(
      id: data["id"] ?? "", // Default empty string if missing
      name: data["name"] ?? "Unknown",
      number: data["number"] ?? "N/A",
      measurements: _parseMeasurements(data),
    );
  }

  /// Convert object to JSON format for Firebase storage
  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "name": name,
      "number": number,
      ...measurements, // Add all measurement fields dynamically
    };
  }

  /// Helper function to parse dynamic measurement fields
  static Map<String, double> _parseMeasurements(Map<String, dynamic> data) {
    Map<String, double> parsedMeasurements = {};

    data.forEach((key, value) {
      if (value is num) {
        parsedMeasurements[key] = value.toDouble();
      }
    });
    return parsedMeasurements;
  }
}
