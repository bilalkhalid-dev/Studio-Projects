import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  late final String id;
  late final String userName;
  late final String phoneNumber;
  late final String email;
  late final String role; // ✅ Admin/User Role Add Kiya

  UserModel({
    required this.id,
    required this.userName,
    required this.email,
    required this.phoneNumber,
    required this.role, // ✅ Role ko required parameter banaya
  });

  UserModel.fromDocumentSnapshot(DocumentSnapshot documentSnapshot) {
    id = documentSnapshot["id"];
    userName = documentSnapshot["userName"];
    phoneNumber = documentSnapshot["phoneNumber"];
    email = documentSnapshot["email"];
    role = documentSnapshot["role"] ?? "user"; // ✅ Default role "user" rakha
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "userName": userName,
      "phoneNumber": phoneNumber,
      "email": email,
      "role": role, // ✅ Firestore mein role save hoga
    };
  }
}
