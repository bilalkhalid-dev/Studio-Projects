package com.pharmax.pharmax

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
