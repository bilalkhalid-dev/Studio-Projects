import 'package:cloud_firestore/cloud_firestore.dart';

class ThisDoctor {
  var DoctorName;

  ThisDoctor({
  this.DoctorName,
  });

  factory ThisDoctor.fromSnapshot(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return ThisDoctor(
      DoctorName: data['DoctorName'],
    );
  }
}
