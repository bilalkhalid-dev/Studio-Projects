import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentUser {
  var id;
  var doctorUID;
  var userUID;
  var patientName;
  var patientQuery;
  var patientPhone;
  var status;
  var appointmentTime;
  var doctorName;
  var doctorAvatarUrl;
  var clinicAddress;
  var userAvatarUrl;
  var doctorPhone;
  var startTime;
  var endTime;
  var weekdays;

  AppointmentUser({
    this.id,
    this.doctorUID,
    this.userUID,
    this.patientName,
    this.patientQuery,
    this.patientPhone,
    this.status,
    this.appointmentTime,
    this.doctorName,
    this.doctorAvatarUrl,
    this.clinicAddress,
    this.userAvatarUrl,
    this.doctorPhone,
    this.startTime,
    this.endTime,
    this.weekdays,
  });

  factory AppointmentUser.fromSnapshot(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;

    return AppointmentUser(
      id: snapshot.id,
      doctorUID: data['doctorUID'],
      doctorName: data['doctorName'],
      userUID: data['UserUID'],
      patientName: data['patientName'],
      patientQuery: data['patientQuery'],
      patientPhone: data['patientPhone'],
      clinicAddress: data['clinicAddress'],
      doctorAvatarUrl: data['DoctorAvatarUrl'],
      userAvatarUrl: data['UserAvatarUrl'],
      doctorPhone: data['doctorPhone'],
      weekdays: data['weekdays'],
      startTime: data['startTime'],
      endTime: data['endTime'],
      status: data['status'],
      appointmentTime: (data['appointmentTime'] as Timestamp).toDate(),
    );
  }

  bool isWithinWorkingHours(DateTime appointmentTime) {
    if (weekdays != null && startTime != null && endTime != null) {
      // Check if the appointment falls on a valid weekday
      final appointmentWeekday = appointmentTime.weekday;
      if (weekdays.contains(appointmentWeekday)) {
        // Check if the appointment time is within the doctor's working hours
        final startWorkingHour = DateTime(
          appointmentTime.year,
          appointmentTime.month,
          appointmentTime.day,
          startTime.hour,
          startTime.minute,
        );
        final endWorkingHour = DateTime(
          appointmentTime.year,
          appointmentTime.month,
          appointmentTime.day,
          endTime.hour,
          endTime.minute,
        );

        return appointmentTime.isAfter(startWorkingHour) &&
            appointmentTime.isBefore(endWorkingHour);
      }
    }

    return false;
  }
}
