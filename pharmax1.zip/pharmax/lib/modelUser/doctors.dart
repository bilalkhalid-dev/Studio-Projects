import 'package:cloud_firestore/cloud_firestore.dart';

class Doctors {
  var DoctorUID;
  var DoctorName;
  var DoctorEmail;
  var doctorPhone;
  var DoctorAvatarUrl;
  var clinicAddress;
  var doctorRegistrationID;
  var doctorSpecialization;
  var doctorInfo;
  var startTime;
  var endTime;
  var weekdays;
  var deviceToken;

  Doctors({
    this.DoctorUID,
    this.DoctorName,
    this.DoctorEmail,
    this.doctorPhone,
    this.DoctorAvatarUrl,
    this.clinicAddress,
    this.doctorRegistrationID,
    this.doctorSpecialization,
    this.doctorInfo,
    this.endTime,
    this.startTime,
    this.weekdays,
    this.deviceToken,
  });

  factory Doctors.fromJson(Map<String, dynamic> json) {
    return Doctors(
      DoctorUID: json["DoctorUID"],
      DoctorName: json["DoctorName"],
      DoctorEmail: json["DoctorEmail"],
      doctorPhone: json["doctorPhone"],
      DoctorAvatarUrl: json["DoctorAvatarUrl"],
      clinicAddress: json["clinicAddress"],
      doctorRegistrationID: json["doctorRegistrationID"],
      doctorSpecialization: json["doctorSpecialization"],
      doctorInfo: json["doctorInfo"],
      endTime: json["endTime"],
      startTime: json["startTime"],
      weekdays: json["weekdays"],
      deviceToken: json["deviceToken"],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data["DoctorUID"] = this.DoctorUID;
    data["DoctorName"] = this.DoctorName;
    data["DoctorEmail"] = this.DoctorEmail;
    data["doctorPhone"] = this.doctorPhone;
    data["DoctorAvatarUrl"] = this.DoctorAvatarUrl;
    data["clinicAddress"] = this.clinicAddress;
    data["doctorRegistrationID"] = this.doctorRegistrationID;
    data["doctorSpecialization"] = this.doctorSpecialization;
    data["doctorInfo"] = this.doctorInfo;
    data["endTime"] = this.endTime;
    data["startTime"] = this.startTime;
    data["weekdays"] = this.weekdays;
    data["deviceToken"] = this.deviceToken;
    return data;
  }

}
