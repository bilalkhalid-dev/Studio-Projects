import 'package:flutter/material.dart';

class AppointmentsProvider with ChangeNotifier {
  List<String> acceptedAppointments = [];

  void acceptAppointment(String appointmentId) {
    acceptedAppointments.add(appointmentId);
    notifyListeners();
  }
}
