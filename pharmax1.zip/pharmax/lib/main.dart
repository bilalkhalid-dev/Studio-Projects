import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:pharmax/admin/ui/bottom_navBar/bottom_av_bar.dart';
import 'package:pharmax/user/ui/bottom_nav_bar/bottom_av_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';
import 'global/global.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sharedPreferences = await SharedPreferences.getInstance();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const DoctorPharmaax());
}

class DoctorPharmaax extends StatefulWidget {
  const DoctorPharmaax({Key? key}) : super(key: key);

  @override
  State<DoctorPharmaax> createState() => _DoctorPharmaaxState();
}

class _DoctorPharmaaxState extends State<DoctorPharmaax> {
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.lightGreen,
        primaryColor: Colors.lightGreen,
      ),
      title: "Doctor Pharmaax",
      home: BottomNavBarUser(),
    );
  }
}