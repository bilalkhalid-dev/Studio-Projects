// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class DoctorsMainInfo extends StatefulWidget {
//   const DoctorsMainInfo({Key? key}) : super(key: key);
//
//   @override
//   State<DoctorsMainInfo> createState() => _DoctorsMainInfoState();
// }
//
// class _DoctorsMainInfoState extends State<DoctorsMainInfo> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//   TextEditingController specializeController = TextEditingController();
//   Map<String, Map<String, String>> selectedWorkingTime = {};
//
//   Future<void> saveDataToFirebaseAndSharedPrefs() async {
//     final User? user = FirebaseAuth.instance.currentUser;
//     if (user == null) {
//       print('User not signed in');
//       return;
//     }
//
//     final String doctorId = user.uid;
//     final CollectionReference doctorsCollection = FirebaseFirestore.instance.collection('Doctors');
//
//     ProgressDialog progressDialog = ProgressDialog(context);
//     progressDialog.style(message: 'Saving Data...');
//     progressDialog.show();
//
//     try {
//       await doctorsCollection.doc(doctorId).update({
//         'specialization': specializeController.text,
//         'workingTime': selectedWorkingTime,
//       });
//
//       print('Doctor information updated successfully!');
//
//       // Save data to shared preferences
//       SharedPreferences prefs = await SharedPreferences.getInstance();
//       await prefs.setString('specialization', specializeController.text);
//       await prefs.setString('workingTime', selectedWorkingTime.toString());
//       print('Doctor information saved to shared preferences!');
//
//       progressDialog.hide();
//
//       // Navigate to home screen
//       Navigator.pushReplacementNamed(context, '/home');
//     } catch (e) {
//       print('Error updating doctor information: $e');
//       progressDialog.hide();
//     }
//   }
//
//   void _selectWorkingTime(String day) async {
//     TimeOfDay? selectedStartTime = await showTimePicker(
//       context: context,
//       initialTime: TimeOfDay.now(),
//     );
//
//     if (selectedStartTime != null) {
//       TimeOfDay? selectedEndTime = await showTimePicker(
//         context: context,
//         initialTime: selectedStartTime,
//       );
//
//       if (selectedEndTime != null) {
//         setState(() {
//           selectedWorkingTime[day] = {
//             'start': selectedStartTime.format(context),
//             'end': selectedEndTime.format(context),
//           };
//         });
//       }
//     }
//   }
//
//   @override
//   void dispose() {
//     specializeController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     var formStyle = const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w500);
//     var size = MediaQuery.of(context).size;
//     var title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(20.0),
//           child: SafeArea(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisSize: MainAxisSize.max,
//               children: [
//                 Text('SIGNUP', style: title),
//                 SizedBox(height: size.height * 0.03),
//                 Form(
//                   key: _formKey,
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text('Specialization', style: formStyle),
//                       SizedBox(height: size.height * 0.01),
//                       TextFormField(
//                         controller: specializeController,
//                         decoration: InputDecoration(
//                           hintText: 'Enter specialization',
//                         ),
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return 'Please enter specialization';
//                           }
//                           return null;
//                         },
//                       ),
//                       SizedBox(height: size.height * 0.02),
//                       Text('Working Days and Time', style: formStyle),
//                       SizedBox(height: size.height * 0.01),
//                       for (String day in selectedWorkingTime.keys)
//                         Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Text(day, style: formStyle),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(
//                                   'Start Time: ${selectedWorkingTime[day]!['start'] ?? 'Not Set'}',
//                                   style: formStyle,
//                                 ),
//                                 ElevatedButton(
//                                   onPressed: () => _selectWorkingTime(day),
//                                   child: Text('Select'),
//                                 ),
//                               ],
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(
//                                   'End Time: ${selectedWorkingTime[day]!['end'] ?? 'Not Set'}',
//                                   style: formStyle,
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: size.height * 0.03),
//                 ElevatedButton(
//                   onPressed: saveDataToFirebaseAndSharedPrefs,
//                   child: Text('Save'),
//                 ),
//                 SizedBox(height: size.height * 0.04),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }