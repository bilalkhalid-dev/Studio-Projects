import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:firebase_storage/firebase_storage.dart' as fStorage;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../global/global.dart';
import '../../../widgets/custom_btn.dart';
import '../../../widgets/custom_textformfield.dart';
import '../../../widgets/error_dialog.dart';
import '../../../widgets/loading_dialog.dart';
import '../bottom_navBar/bottom_av_bar.dart';
import 'login_page.dart';


class SignupPageAdmin extends StatefulWidget {
  const SignupPageAdmin({Key? key}) : super(key: key);

  @override
  State<SignupPageAdmin> createState() => _SignupPageAdminState();
}

class _SignupPageAdminState extends State<SignupPageAdmin> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController confirmPassController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController idController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController specializationController = TextEditingController();
  TextEditingController aboutDoctorController = TextEditingController();
  var obscureText = false;

  XFile? imageXFile;
  final ImagePicker _picker = ImagePicker();

  Position? position;
  List<Placemark>? placeMarks;

  String profileImage = "";
  String doctorCompleteAddress = "";

  TimeOfDay? startTime;
  TimeOfDay? endTime;
  List<bool> weekdays = [false, false, false, false, false, false, false];

  Future<void> _getImage() async {
    imageXFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      imageXFile;
    });
  }

  Future<void> getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message: "Location services are disabled. Please enable them to continue.",
          );
        },
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message:
            "Location permissions are permanently denied. Please allow the app to access your location in the device settings.",
          );
        },
      );
      return;
    }

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        showDialog(
          context: context,
          builder: (c) {
            return CustomErrorDialog(
              message:
              "Location permissions are denied. Please allow the app to access your location.",
            );
          },
        );
        return;
      }
    }

    Position newPosition = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      position = newPosition;
    });

    List<Placemark> placeMarks = await placemarkFromCoordinates(
      position!.latitude,
      position!.longitude,
    );

    Placemark pMark = placeMarks[0];

    setState(() {
      doctorCompleteAddress = '${pMark.subThoroughfare} ${pMark.thoroughfare}, ${pMark.subLocality} ${pMark.locality}, ${pMark.subAdministrativeArea}, ${pMark.administrativeArea} ${pMark.postalCode}, ${pMark.country}';
      locationController.text = doctorCompleteAddress;
    });
  }

  Future<void> formValidation() async {
    if (imageXFile == null) {
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message: "Please select an image.",
          );
        },
      );
    } else {
      if (passController.text == confirmPassController.text) {
        if (confirmPassController.text.isNotEmpty &&
            emailController.text.isNotEmpty &&
            nameController.text.isNotEmpty &&
            phoneController.text.isNotEmpty &&
            idController.text.isNotEmpty &&
            specializationController.text.isNotEmpty &&
            aboutDoctorController.text.isNotEmpty &&
            locationController.text.isNotEmpty) {
          // Start uploading image
          showDialog(
            context: context,
            builder: (c) {
              return LoadingDialog(
                message: "Registering Account",
              );
            },
          );

          String fileName = DateTime.now().millisecondsSinceEpoch.toString();
          fStorage.Reference reference = fStorage.FirebaseStorage.instance
              .ref()
              .child("Doctors")
              .child(fileName);
          fStorage.UploadTask uploadTask =
          reference.putFile(File(imageXFile!.path));
          fStorage.TaskSnapshot taskSnapshot =
          await uploadTask.whenComplete(() {});
          await taskSnapshot.ref.getDownloadURL().then((url) {
            profileImage = url;

            // Save info to Firestore
            authenticateSellerAndSignUp();
          });
        } else {
          showDialog(
            context: context,
            builder: (c) {
              return CustomErrorDialog(
                message: "Please write the complete required info for Registration.",
              );
            },
          );
        }
      } else {
        showDialog(
          context: context,
          builder: (c) {
            return CustomErrorDialog(
              message: "Password do not match.",
            );
          },
        );
      }
    }
  }

  void authenticateSellerAndSignUp() async {
    User? currentUser;

    await firebaseAuth
        .createUserWithEmailAndPassword(
      email: emailController.text.trim(),
      password: passController.text.trim(),
    )
        .then((auth) {
      currentUser = auth.user;
    }).catchError((error) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message: error.message.toString(),
          );
        },
      );
    });

    if (currentUser != null) {
      saveDataToFirestore(currentUser!).then((value) {
        Navigator.pop(context);
        // Send user to homePage
        Route newRoute =
        MaterialPageRoute(builder: (c) =>  BottomNavBarAdmin());
        Navigator.pushReplacement(context, newRoute);
      });
    }
  }

  Future saveDataToFirestore(User currentUser) async {
    FirebaseFirestore.instance.collection("Doctors").doc(currentUser.uid).set({
      "DoctorUID": currentUser.uid,
      "DoctorEmail": currentUser.email,
      "DoctorName": nameController.text.trim(),
      "DoctorAvatarUrl": profileImage,
      "doctorPhone": phoneController.text.trim(),
      "doctorRegistrationID": idController.text.trim(),
      "doctorSpecialization": specializationController.text.trim(),
      "doctorInfo": aboutDoctorController.text.trim(),
      "clinicAddress": doctorCompleteAddress,
      "status": "approved",
      "lat": position!.latitude,
      "lng": position!.longitude,
      "startTime": startTime?.format(context),
      "endTime": endTime?.format(context),
      "weekdays": weekdays,
    });

    // Save data locally
    sharedPreferences = await SharedPreferences.getInstance();
    await sharedPreferences!.setString("uid", currentUser.uid);
    await sharedPreferences!.setString("email", currentUser.email.toString());
    await sharedPreferences!.setString("name", nameController.text.trim());
    await sharedPreferences!.setString("RegistrationID", idController.text.trim());
    await sharedPreferences!.setString("Specialization", specializationController.text.trim());
    await sharedPreferences!.setString("aboutInfo", aboutDoctorController.text.trim());
    await sharedPreferences!.setString("PhoneNo", phoneController.text.trim());
    await sharedPreferences!.setString("Address", doctorCompleteAddress);
    await sharedPreferences!.setString("photoUrl", profileImage);
  }

  @override
  Widget build(BuildContext context) {
    var formStyle = const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text('SIGNUP', style: title,),
                SizedBox(height: size.height * 0.03,),
                InkWell(
                  onTap: () {
                    _getImage();
                  },
                  child: CircleAvatar(
                    radius: MediaQuery.of(context).size.width * 0.13,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: imageXFile == null ? null : FileImage(File(imageXFile!.path)),
                    child: imageXFile == null
                        ? Icon(
                      Icons.add_photo_alternate,
                      size: MediaQuery.of(context).size.width * 0.13,
                      color: Colors.lightGreen,
                    )
                        : null,
                  ),
                ),
                SizedBox(height: size.height * 0.03,),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(' Full Name', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      CustomTextFormField(
                        controller: nameController,
                        obscureText: false,
                        keyboardType: TextInputType.name,
                      ),
                      SizedBox(height: size.height * 0.02,),
                      Text(' Email', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      CustomTextFormField(
                        controller: emailController,
                        obscureText: false,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      SizedBox(height: size.height * 0.02,),
                      Text(' Phone No.', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      CustomTextFormField(
                        controller: phoneController,
                        obscureText: false,
                        keyboardType: TextInputType.phone,
                      ),
                      SizedBox(height: size.height * 0.02,),
                      Text(' Registration ID', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      CustomTextFormField(
                        controller: idController,
                        obscureText: false,
                        keyboardType: TextInputType.number,
                      ),

                      SizedBox(height: size.height * 0.02,),
                      Text(' Specialization', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      CustomTextFormField(
                        controller: specializationController,
                        obscureText: false,
                        keyboardType: TextInputType.text,
                      ),


                      SizedBox(height: size.height * 0.02,),
                      Text(' About You', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        textDirection: TextDirection.ltr,
                        controller: aboutDoctorController,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        cursorColor: Colors.lightGreen,
                        decoration: InputDecoration(
                          hintStyle: const TextStyle(color: Colors.grey),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.grey,
                            ),

                          ),

                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.lightGreen,
                            ),

                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.red,
                            ),

                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.lightGreen,
                            ),

                          ),
                        ),
                        minLines: 1,
                        maxLines: 15,
                        maxLength: 1000,
                        keyboardType: TextInputType.text
                      ),

                      SizedBox(height: size.height * 0.02,),
                      Text(' Password', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      SizedBox(
                        height: size.height*0.05,
                        child: TextFormField(
                          controller: passController,
                          obscureText: obscureText,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  obscureText = !obscureText;
                                });
                              },
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.lightGreen),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.lightGreen),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: size.height * 0.02,),
                      Text(' Confirm Password', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                  SizedBox(
                    height: size.height*0.05,
                    child: TextFormField(
                      controller: confirmPassController,
                      obscureText: obscureText,
                      keyboardType: TextInputType.visiblePassword,
                      decoration: InputDecoration(
                        suffixIcon: IconButton(
                          icon: Icon(
                            obscureText ? Icons.visibility : Icons.visibility_off,
                          ),
                          onPressed: () {
                            setState(() {
                              obscureText = !obscureText;
                            });
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.lightGreen),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.red),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.lightGreen),
                        ),
                      ),
                    ),
                  ),
                      SizedBox(height: size.height * 0.02,),
                      Text(' Clinic Address', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      SizedBox(
                        height: size.height*0.067,
                        child: CustomTextFormField(
                            controller: locationController,
                            obscureText: false,
                            keyboardType: TextInputType.text,
                            suffixIcon: Icons.my_location,
                            onTap: (){
                              getCurrentLocation();
                            }
                        ),
                      ),
                      SizedBox(height: size.height * 0.01,),
                      Text('Clinic Timings', style: formStyle,),
                      SizedBox(height: size.height * 0.01,),
                      buildTimePicker(
                        context,
                        "Select Timing",
                        Icons.access_time,
                            () async {
                          final time = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.now(),
                          );
                          if (time != null) {
                            setState(() {
                              startTime = time;
                            });
                          }
                        },
                        startTime?.format(context) ?? 'From',
                      ),
                      SizedBox(height: size.height * 0.01,),
                      buildTimePicker(
                        context,
                        "Select Timing",
                        Icons.access_time,
                            () async {
                          final time = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.now(),
                          );
                          if (time != null) {
                            setState(() {
                              endTime = time;
                            });
                          }
                        },
                        endTime?.format(context) ?? 'To',
                      ),
                      SizedBox(height: size.height * 0.02,),
                      Text('Working Days', style: formStyle,),
                      SizedBox(height: size.height * 0.02,),
                      buildWeekdaySelection(),
                      SizedBox(height: size.height * 0.04,),
                      SizedBox(
                        width: double.infinity,
                        child: CustomBtn(
                          onPressed: () {
                            formValidation();
                          },
                          text: 'Register',
                        ),
                      ),
                      SizedBox(height: size.height * 0.04,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Already have an account? ',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Colors.black,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Route newRoute = MaterialPageRoute(builder: (c) => const LoginPageAdmin());
                              Navigator.pushReplacement(context, newRoute);
                            },
                            child: const Text(
                              'Login',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: Colors.lightGreen,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: size.height * 0.02,),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTimePicker(BuildContext context, String title, IconData icon, VoidCallback onPressed, String value) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.lightGreen,),
            const SizedBox(width: 10),
            Text(title),
            const Spacer(),
            Text(value, style: const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500),),
          ],
        ),
      ),
    );
  }

  Widget buildWeekdaySelection() {
    final weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return SizedBox(
      height: 45,
      width: double.infinity,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: List.generate(
          7,
              (index) => InkWell(
            onTap: () {
              setState(() {
                weekdays[index] = !weekdays[index];
              });
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: weekdays[index] ? Colors.lightGreen : Colors.grey[300],
              ),
              child: Text(
                weekdayNames[index],
                style: TextStyle(
                  color: weekdays[index] ? Colors.white : Colors.lightGreen,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

