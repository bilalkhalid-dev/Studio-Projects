import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../widgets/custom_btn.dart';
import '../../../widgets/custom_textformfield.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController forgotPassController = TextEditingController();

  Future<void> resetPassword(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      // Password reset email sent successfully.
      // Show a success message or navigate to a confirmation screen.
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Success'),
          content: const Text('Password reset email sent.'),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog.
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } catch (e) {
      // An error occurred while attempting to send the password reset email.
      // Handle the error appropriately, e.g., show an error message.
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: Text('Failed to send password reset email: $e'),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog.
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
      print('Error sending password reset email: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    var formStyle =
    const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text('Forgot Password', style: title),
                SizedBox(height: size.height * 0.04),
                Image.asset('images/forgotPass.png'),
                SizedBox(height: size.height * 0.05),
                Container(
                  height: size.height * 0.08,
                  width: size.width * 0.8,
                  alignment: Alignment.center,
                  child: const Text(
                    'Please enter your email address. You will receive an email.',
                    style: TextStyle(color: Colors.grey, fontSize: 16),
                  ),
                ),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: size.height * 0.03),
                      Text('Email', style: formStyle),
                      SizedBox(height: size.height * 0.01),
                      CustomTextFormField(
                        controller: forgotPassController,
                        obscureText: true,
                        keyboardType: TextInputType.emailAddress,
                        hintText: 'YourEmail@gmail.com',
                      ),
                    ],
                  ),
                ),
                SizedBox(height: size.height * 0.03),
                CustomBtn(
                  text: "Continue",
                  onPressed: () {
                    final String email = forgotPassController.text.trim();
                    if (email.isNotEmpty) {
                      resetPassword(email);
                    } else {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Error'),
                          content: const Text('Please enter your email.'),
                          actions: [
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context); // Close the dialog.
                              },
                              child: const Text('OK'),
                            ),
                          ],
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
