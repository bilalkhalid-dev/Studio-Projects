import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pharmax/admin/ui/auth/signup_page.dart';
import '../../../global/global.dart';
import '../../../widgets/custom_btn.dart';
import '../../../widgets/custom_textformfield.dart';
import '../../../widgets/error_dialog.dart';
import '../../../widgets/loading_dialog.dart';
import '../bottom_navBar/bottom_av_bar.dart';
import 'forgot_password.dart';

class LoginPageAdmin extends StatefulWidget {
  const LoginPageAdmin({Key? key}) : super(key: key);

  @override
  State<LoginPageAdmin> createState() => _LoginPageAdminState();
}

class _LoginPageAdminState extends State<LoginPageAdmin> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  var obscureText = false;

  formValidation()
  {
    if(emailController.text.isNotEmpty && passwordController.text.isNotEmpty)
    {
      //login
      loginNow();
    }
    else
    {
      showDialog(
          context: context,
          builder: (c)
          {
            return CustomErrorDialog(
              message: "Please write email/password.",
            );
          }
      );
    }
  }


  loginNow() async
  {
    showDialog(
        context: context,
        builder: (c)
        {
          return LoadingDialog(
            message: "Checking Credentials",
          );
        }
    );

    User? currentUser;
    await firebaseAuth.signInWithEmailAndPassword(
      email: emailController.text.trim(),
      password: passwordController.text.trim(),
    ).then((auth){
      currentUser = auth.user!;
    }).catchError((error){
      Navigator.pop(context);
      showDialog(
          context: context,
          builder: (c)
          {
            return CustomErrorDialog(
              message: error.message.toString(),
            );
          }
      );
    });
    if(currentUser != null)
    {
      readDataAndSetDataLocally(currentUser!);
    }
  }

  Future readDataAndSetDataLocally(User currentUser) async
  {
    await FirebaseFirestore.instance.collection("Doctors")
        .doc(currentUser.uid)
        .get()
        .then((snapshot) async {
          if (snapshot.exists)
          {
            await sharedPreferences!.setString("uid", currentUser.uid);
            await sharedPreferences!.setString("email", snapshot.data()!["DoctorEmail"]);
            await sharedPreferences!.setString("name", snapshot.data()!["DoctorName"]);
            await sharedPreferences!.setString("photoUrl", snapshot.data()!["DoctorAvatarUrl"]);
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (c)=> BottomNavBarAdmin()));
          }
          else
            {
              firebaseAuth.signOut();
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (c)=> const LoginPageAdmin()));

              showDialog(
                  context: context,
                  builder: (c)
                  {
                    return LoadingDialog(
                      message: "No Record Found",
                    );
                  }
              );
            }

    });
  }
  @override
  Widget build(BuildContext context) {
    var formStyle = const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var  title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text('LOGIN', style: title,),
                SizedBox(height: size.height*0.04,),
                Image.asset('images/login.png',),
                SizedBox(height: size.height*0.05,),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(' Email', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      CustomTextFormField(
                        controller: emailController,
                       obscureText: false,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      SizedBox(height: size.height*0.03,),
                      Text(' Password', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      SizedBox(
                        height: size.height*0.05,
                        child: TextFormField(
                          controller: passwordController,
                          obscureText: obscureText,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  obscureText = !obscureText;
                                });
                              },
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.lightGreen),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.lightGreen),
                            ),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>const ForgotPassword()));
                          }, child: Text('Forgot Password?', style: formStyle,)),
                        ],
                      ),
                    ],
                  ),
                ),




                SizedBox(height: size.height*0.03,),

                CustomBtn(text: "Login", onPressed: (){
                  formValidation();
                },),

                SizedBox(height: size.height*0.02,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Not register yet?'),
                    TextButton(onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (c)=>const SignupPageAdmin()));
                    }, child: const Text('Create account'))
                  ],
                )

              ],
            ),
          ),
        ),
      ),
    );
  }
}
