import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../widgets/custom_btn.dart';
import '../../auth/login_page.dart';

class ProfilePageAdmin extends StatefulWidget {
  const ProfilePageAdmin({super.key});

  @override
  State<ProfilePageAdmin> createState() => _ProfilePageAdminState();
}

class _ProfilePageAdminState extends State<ProfilePageAdmin> {
  SharedPreferences? sharedPreferences;
  String? name;
  String? email;
  String? phone;
  String? registrationID;
  String? specialization;
  String? aboutInfo;
  String? address;
  String? photoUrl;
  List<String>? weekdays;
  String? startTime;
  String? endTime;

  @override
  void initState() {
    super.initState();
    retrieveUserData();
  }

  Future<void> retrieveUserData() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      name = sharedPreferences?.getString("name") ?? '';
      email = sharedPreferences?.getString("email") ?? '';
      phone = sharedPreferences?.getString("PhoneNo") ?? '';
      registrationID = sharedPreferences?.getString("RegistrationID") ?? '';
      specialization = sharedPreferences?.getString("Specialization") ?? '';
      aboutInfo = sharedPreferences?.getString("aboutInfo") ?? '';
      address = sharedPreferences?.getString("Address") ?? '';
      photoUrl = sharedPreferences?.getString("photoUrl");

      FirebaseAuth auth = FirebaseAuth.instance;
      String? userId = auth.currentUser?.uid;

      if (userId != null) {
        FirebaseFirestore.instance
            .collection('Doctors')
            .doc(userId)
            .get()
            .then((documentSnapshot) {
          if (documentSnapshot.exists) {
            var data = documentSnapshot.data();
            if (data != null) {
              setState(() {
                weekdays = [];
                if (data['weekdays'] != null) {
                  for (int i = 0; i < 7; i++) {
                    if (data['weekdays'][i] == true) {
                      weekdays!.add(getWeekdayName(i));
                    }
                  }
                }
                startTime = data['startTime'] as String? ?? 'N/A';
                endTime = data['endTime'] as String? ?? 'N/A';
              });
            }
          }
        }).catchError((error) {
          print('Error retrieving working hours: $error');
        });
      }
    });
  }

  String getWeekdayName(int weekday) {
    switch (weekday) {
      case 0:
        return 'Monday';
      case 1:
        return 'Tuesday';
      case 2:
        return 'Wednesday';
      case 3:
        return 'Thursday';
      case 4:
        return 'Friday';
      case 5:
        return 'Saturday';
      case 6:
        return 'Sunday';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    var _ = const TextStyle(color: Colors.black, fontSize: 16);
    var formStyle = const TextStyle(
        color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(
        color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);

    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'Profile',
                  style: title,
                ),
                SizedBox(height: size.height * 0.04),
                Container(
                  height: size.height * 0.13,
                  width: size.height * 0.14,
                  child: CircleAvatar(
                    backgroundColor: Colors.grey[100],
                    backgroundImage: photoUrl != null && photoUrl!.isNotEmpty
                        ? NetworkImage(photoUrl!)
                        : null,
                    child: photoUrl == null || photoUrl!.isEmpty
                        ? Icon(
                      Icons.person,
                      color: Colors.lightGreen,
                      size: size.width * 0.08,
                    )
                        : null,
                  ),
                ),
                SizedBox(height: size.height * 0.01),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Dr. ', style: TextStyle(color: Colors.black, fontSize: 16),),
                    Text(
                      name ?? '',
                      style: const TextStyle(
                        color: Colors.lightGreen,
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: size.height * 0.003),
                Text(specialization ?? '', style: const TextStyle(color: Colors.grey)),
                SizedBox(height: size.height * 0.02),

                _infoTile("ID:", registrationID),
                _infoTile("Email:", email),
                _infoTile("Phone:", phone),
                _infoTile("Address:", address),
                _infoTile("About:", aboutInfo),

                _infoTile("Working Hours:", "$startTime - $endTime"),

                SizedBox(height: size.height * 0.03),
                CustomBtn(
                  text: 'Sign Out',
                  onPressed: () {
                    _signOut(context);
                  },
                ),
                SizedBox(height: size.height * 0.02),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoTile(String title, String? value) {
    var formStyle = const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500);
    var newstyle = const TextStyle(color: Colors.black, fontSize: 16);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        shadowColor: Colors.lightGreen[100],
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey[100],
        elevation: 10,
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(10),
          width: double.infinity,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
          child: Row(
            children: [
              Text("$title ", style: formStyle),
              Expanded(
                child: Text(value ?? 'N/A', style: newstyle, overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (c) => const LoginPageAdmin()));
    } catch (e) {
      print('Error signing out: $e');
    }
  }
}
