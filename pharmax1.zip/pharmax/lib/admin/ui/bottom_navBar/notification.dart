import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DoctorNotificationScreenAdmin extends StatefulWidget {
  @override
  _DoctorNotificationScreenAdminState createState() =>
      _DoctorNotificationScreenAdminState();
}

class _DoctorNotificationScreenAdminState extends State<DoctorNotificationScreenAdmin> {
  Stream<QuerySnapshot<Map<String, dynamic>>> doctorAppointmentsStream =
  const Stream.empty(); // Default empty stream

  @override
  void initState() {
    super.initState();
    fetchAppointments();
  }

  void fetchAppointments() {
    final currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      print("No user logged in");
      return;
    }

    final doctorUID = currentUser.uid;

    setState(() {
      doctorAppointmentsStream = FirebaseFirestore.instance
          .collection('Appointments')
          .where('doctorUID', isEqualTo: doctorUID)
          .snapshots();
    });
  }

  Future<void> updateAppointmentStatus(
      String appointmentId, String status) async {
    try {
      await FirebaseFirestore.instance
          .collection('Appointments')
          .doc(appointmentId)
          .update({'status': status});
    } catch (error) {
      print("Error updating appointment status: $error");
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notification',
          style: TextStyle(color: Colors.lightGreen),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: doctorAppointmentsStream,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return const Center(child: Text('An error occurred'));
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text('No appointments available'));
            }

            final appointments = snapshot.data!.docs;

            return ListView.builder(
              itemCount: appointments.length,
              itemBuilder: (context, index) {
                final appointment = appointments[index];
                final appointmentData = appointment.data();

                final appointmentId = appointment.id;
                final userAvatarURL = appointmentData['UserAvatarUrl'] ?? '';
                final patientName =
                    appointmentData['patientName'] as String? ?? '';
                final appointmentDetails =
                    appointmentData['patientQuery'] as String? ?? '';
                final appointmentStatus =
                    appointmentData['status'] as String? ?? '';

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Material(
                    shadowColor: Colors.lightGreen,
                    borderRadius: BorderRadius.circular(10),
                    elevation: 10,
                    child: Container(
                      constraints: BoxConstraints(
                        maxHeight: size.height * 0.7,
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(userAvatarURL),
                          ),
                          title: Text(
                            patientName,
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w500),
                          ),
                          subtitle: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(appointmentDetails),
                              SizedBox(
                                height: size.height * 0.02,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  if (appointmentStatus == 'Accepted')
                                    const Text(
                                      'Accepted',
                                      style: TextStyle(
                                          color: Colors.green,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 18,
                                          fontStyle: FontStyle.italic),
                                    )
                                  else if (appointmentStatus == 'Rejected')
                                    const Text(
                                      'Rejected',
                                      style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 18,
                                          fontStyle: FontStyle.italic),
                                    )
                                  else
                                    Row(
                                      children: [
                                        InkWell(
                                          onTap: () => updateAppointmentStatus(
                                              appointmentId, 'Accepted'),
                                          child: Container(
                                            alignment: Alignment.center,
                                            height: size.height * 0.045,
                                            width: size.width * 0.25,
                                            decoration: BoxDecoration(
                                              color: Colors.lightGreen[100],
                                              borderRadius:
                                              BorderRadius.circular(20),
                                            ),
                                            child: const Text(
                                              'Accept',
                                              style: TextStyle(
                                                  color: Colors.green,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 18),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        InkWell(
                                          onTap: () => updateAppointmentStatus(
                                              appointmentId, 'Rejected'),
                                          child: Container(
                                            alignment: Alignment.center,
                                            height: size.height * 0.045,
                                            width: size.width * 0.25,
                                            decoration: BoxDecoration(
                                              color: Colors.red[100],
                                              borderRadius:
                                              BorderRadius.circular(20),
                                            ),
                                            child: const Text(
                                              'Reject',
                                              style: TextStyle(
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 18),
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}










// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// class DoctorNotificationScreen extends StatefulWidget {
//   @override
//   _DoctorNotificationScreenState createState() =>
//       _DoctorNotificationScreenState();
// }
//
// class _DoctorNotificationScreenState extends State<DoctorNotificationScreen> {
//   late Stream<QuerySnapshot<Map<String, dynamic>>> doctorAppointmentsStream;
//
//   @override
//   void initState() {
//     super.initState();
//
//     final currentUser = FirebaseAuth.instance.currentUser;
//     if (currentUser != null) {
//       final doctorUID = currentUser.uid;
//
//       doctorAppointmentsStream = FirebaseFirestore.instance
//           .collection('Appointments')
//           .where('doctorUID', isEqualTo: doctorUID)
//           .snapshots();
//     }
//   }
//
//   Future<void> acceptAppointment(String appointmentId) async {
//     try {
//       await FirebaseFirestore.instance
//           .collection('Appointments')
//           .doc(appointmentId)
//           .update({
//         'status': 'Accepted',
//       });
//     } catch (error) {
//       // Show an error message or handle the error
//     }
//   }
//
//   Future<void> rejectAppointment(String appointmentId) async {
//     try {
//       await FirebaseFirestore.instance
//           .collection('Appointments')
//           .doc(appointmentId)
//           .update({
//         'status': 'Rejected',
//       });
//     } catch (error) {
//       // Show an error message or handle the error
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     var size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Notification', style: TextStyle(color: Colors.lightGreen),),
//         centerTitle: true,
//         automaticallyImplyLeading: false,
//         elevation: 0,
//         backgroundColor: Colors.white,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
//           stream: doctorAppointmentsStream,
//           builder: (context, snapshot) {
//             if (snapshot.hasData) {
//               final appointments = snapshot.data!.docs;
//
//               if (appointments.isEmpty) {
//                 return const Center(
//                   child: Text('No appointments available'),
//                 );
//               }
//
//               return ListView.builder(
//                 itemCount: appointments.length,
//                 itemBuilder: (context, index) {
//                   final appointment = appointments[index];
//                   final appointmentData = appointment.data();
//
//                   final appointmentId = appointment.id;
//                   final userAvatarURL = appointmentData['UserAvatarUrl'] ?? '';
//                   final patientName =
//                       appointmentData['patientName'] as String? ?? '';
//                   final appointmentDetails =
//                       appointmentData['patientQuery'] as String? ?? '';
//                   final appointmentStatus =
//                       appointmentData['status'] as String? ?? '';
//
//
//
//                   return Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 10),
//                     child: Material(
//                       shadowColor: Colors.lightGreen,
//                       borderRadius: BorderRadius.circular(10),
//                       elevation: 10,
//                       child: Container(
//                         constraints: BoxConstraints(
//                           maxHeight: size.height*0.7,
//                         ),
//                         decoration: BoxDecoration(
//                           borderRadius: BorderRadius.circular(10)
//                         ),
//                         child: Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: ListTile(
//                             leading: CircleAvatar(
//                               backgroundImage: NetworkImage(userAvatarURL),
//                             ),
//                             title: Text(patientName, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),),
//                             subtitle: Column(
//                               mainAxisSize: MainAxisSize.min,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(appointmentDetails),
//                                 SizedBox(height: size.height*0.02,),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//
//                                     appointmentStatus == 'Accepted' ?
//                                     const Text('Accepted', style: TextStyle(color: Colors.green, fontWeight: FontWeight.w500, fontSize: 18, fontStyle: FontStyle.italic),) : appointmentStatus == 'Rejected' ?
//                                     const Text('Rejected', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500, fontSize: 18, fontStyle: FontStyle.italic),) : Row(
//                                       children: [
//                                         InkWell(
//                                           onTap: () =>
//                                   acceptAppointment(appointmentId),
//                                           child: Container(
//                                             alignment: Alignment.center,
//                                             height: size.height*0.045,
//                                             width: size.width*0.25,
//                                             decoration: BoxDecoration(
//                                               color: Colors.lightGreen[100],
//                                               borderRadius: BorderRadius.circular(20),
//
//                                             ),
//
//                                             child: const Text('Accept', style: TextStyle(color: Colors.green, fontWeight: FontWeight.w500, fontSize: 18),),
//                                           ),
//                                         ),
//                                         InkWell(
//                                           onTap: ()=>rejectAppointment(appointmentId),
//                                           child: Container(
//                                             alignment: Alignment.center,
//                                             height: size.height*0.045,
//                                             width: size.width*0.25,
//                                             decoration: BoxDecoration(
//                                               color: Colors.red[100],
//                                               borderRadius: BorderRadius.circular(20),
//
//                                             ),
//
//                                             child: const Text('Reject', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500, fontSize: 18),),
//                                           ),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 )
//                               ],
//                             ),
//
//                             // trailing: appointmentStatus == 'Accepted'
//                             //     ? const Icon(Icons.check_circle, color: Colors.green)
//                             //     : appointmentStatus == 'Rejected'
//                             //     ? const Icon(Icons.cancel, color: Colors.red)
//                             //     : Row(
//                             //   mainAxisSize: MainAxisSize.min,
//                             //   children: [
//                             //     IconButton(
//                             //       icon: const Icon(Icons.check),
//                             //       onPressed: () =>
//                             //           acceptAppointment(appointmentId),
//                             //     ),
//                             //     IconButton(
//                             //       icon: const Icon(Icons.cancel_outlined),
//                             //       onPressed: () =>
//                             //           rejectAppointment(appointmentId),
//                             //     ),
//                             //   ],
//                             // ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//               );
//             }
//
//             if (snapshot.hasError) {
//               return const Center(
//                 child: Text('An error occurred'),
//               );
//             }
//
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
