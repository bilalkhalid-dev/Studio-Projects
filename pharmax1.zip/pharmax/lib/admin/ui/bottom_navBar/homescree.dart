import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../modelAdmin/appointments.dart';

class DoctorHomeScreenAdmin extends StatefulWidget {
  @override
  _DoctorHomeScreenAdminState createState() => _DoctorHomeScreenAdminState();
}

class _DoctorHomeScreenAdminState extends State<DoctorHomeScreenAdmin> {
  User? currentUser = FirebaseAuth.instance.currentUser;
  Stream<List<Appointment>>? appointmentsStream;

  SharedPreferences? sharedPreferences;
  String? name, email, phone, registrationID, specialization, aboutInfo, address, photoUrl;
  List<String>? weekdays;
  String? startTime, endTime;

  @override
  void initState() {
    super.initState();
    retrieveUserData();
    if (currentUser != null) {
      appointmentsStream = FirebaseFirestore.instance
          .collection('Appointments')
          .where('status', isEqualTo: 'Accepted')
          .snapshots()
          .map((snapshot) => snapshot.docs.map((doc) => Appointment.fromSnapshot(doc)).toList());
    }
  }

  Future<void> retrieveUserData() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      name = sharedPreferences!.getString("name");
      email = sharedPreferences!.getString("email");
      phone = sharedPreferences!.getString("PhoneNo");
      registrationID = sharedPreferences!.getString("RegistrationID");
      specialization = sharedPreferences!.getString("Specialization");
      aboutInfo = sharedPreferences!.getString("aboutInfo");
      address = sharedPreferences!.getString("Address");
      photoUrl = sharedPreferences!.getString("photoUrl");
    });

    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance.collection('Doctors').doc(userId).get().then((documentSnapshot) {
        if (documentSnapshot.exists) {
          var data = documentSnapshot.data();
          if (data != null) {
            setState(() {
              weekdays = (data['weekdays'] as List?)?.asMap().entries
                  .where((entry) => entry.value == true)
                  .map((entry) => getWeekdayName(entry.key))
                  .toList();
              startTime = data['startTime'] as String?;
              endTime = data['endTime'] as String?;
            });
          }
        }
      }).catchError((error) {
        print('Error retrieving working hours: $error');
      });
    }
  }

  String getWeekdayName(int weekday) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return days[weekday];
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.grey[100],
                    backgroundImage: photoUrl != null ? NetworkImage(photoUrl!) : null,
                    child: photoUrl == null ? Icon(Icons.person, color: Colors.lightGreen, size: size.width * 0.08) : null,
                  ),
                  title: Text(
                    name ?? '',
                    style: const TextStyle(color: Colors.lightGreen, fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  subtitle: const Text('How are you doing?'),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Upcoming Appointments',
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 18),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: size.height * 0.7,
                  width: double.infinity,
                  child: StreamBuilder<List<Appointment>>(
                    stream: appointmentsStream ?? Stream.value([]),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return const Center(child: Text('Error fetching appointments.'));
                      }
                      final appointments = snapshot.data ?? [];
                      if (appointments.isEmpty) {
                        return const Center(child: Text("You don't have any appointments"));
                      }
                      return ListView.builder(
                        itemCount: appointments.length,
                        itemBuilder: (context, index) {
                          final appointment = appointments[index];
                          if (appointment.doctorId == currentUser?.uid) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Material(
                                shadowColor: Colors.lightGreen[100],
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.grey[100],
                                elevation: 10,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(20.0),
                                    child: ListTile(
                                      leading: CircleAvatar(
                                        backgroundImage: appointment.UserAvatarUrl != null
                                            ? NetworkImage(appointment.UserAvatarUrl!)
                                            : null,
                                      ),
                                      title: Text(
                                        appointment.patientName ?? '',
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      subtitle: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            appointment.appointmentTime?.toString() ?? '',
                                            style: const TextStyle(color: Colors.lightGreen, fontSize: 14),
                                          ),
                                          const SizedBox(height: 10),
                                          Text(
                                            appointment.patientQuery ?? '',
                                            style: const TextStyle(color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}