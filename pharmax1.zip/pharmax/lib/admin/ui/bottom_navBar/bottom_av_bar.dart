import 'package:flutter/material.dart';
import 'package:pharmax/admin/ui/bottom_navBar/profile/profile_page.dart';
import 'package:provider/provider.dart';
import '../../../provider/appointments_provider.dart';
import 'homescree.dart';
import 'notification.dart';


class BottomNavBarAdmin extends StatefulWidget {
  @override
  _BottomNavBarAdminState createState() => _BottomNavBarAdminState();
}

class _BottomNavBarAdminState extends State<BottomNavBarAdmin> {
  int selectedIndex = 0;

  final List<Widget> widgetOptions = <Widget>[
    DoctorHomeScreenAdmin(),
    DoctorNotificationScreenAdmin(),
    ProfilePageAdmin(),
  ];

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppointmentsProvider(),
      child: Scaffold(
        body: Center(
          child: widgetOptions.elementAt(selectedIndex),
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          elevation: 2,
          selectedFontSize: 14,
          unselectedFontSize: 12,
          selectedItemColor: Colors.lightGreen,
          unselectedItemColor: Colors.grey,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications_none_outlined),
              label: 'Notification',
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
          currentIndex: selectedIndex,
          onTap: (index) {
            setState(() {
              selectedIndex = index;
            });
          },
        ),
      ),
    );
  }
}
