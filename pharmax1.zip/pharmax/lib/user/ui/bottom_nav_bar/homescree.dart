import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:pharmax/modelUser/appointments.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:text_scroll/text_scroll.dart';
import 'package:url_launcher/url_launcher.dart';

class UserHomeScreen extends StatefulWidget {
  @override
  _UserHomeScreenState createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  User? currentUser;
  late Stream<List<AppointmentUser>> appointmentsStream;

  String email = "";
  String name = "";
  String phone = "";
  String photoUrl = "";

  @override
  void initState() {
    super.initState();
    fetchDataFromSharedPreferences();

    currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      appointmentsStream = FirebaseFirestore.instance
          .collection('Appointments')
          .where('status', isEqualTo: 'Accepted')
          .snapshots()
          .map((snapshot) =>
          snapshot.docs.map((doc) => AppointmentUser.fromSnapshot(doc)).toList());
    } else {
      // Initialize with an empty stream
      appointmentsStream = const Stream<List<AppointmentUser>>.empty();
    }
  }

  Future<void> fetchDataFromSharedPreferences() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    setState(() {
      email = sharedPreferences.getString("email") ?? "";
      name = sharedPreferences.getString("name") ?? "";
      phone = sharedPreferences.getString("phone") ?? "";
      photoUrl = sharedPreferences.getString("photoUrl") ?? "";
    });
  }






  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.grey[100],
                    backgroundImage:
                    photoUrl != null ? NetworkImage(photoUrl) : null,
                    child: photoUrl == null
                        ? Icon(
                      Icons.person,
                      color: Colors.lightGreen,
                      size: size.width * 0.08,
                    )
                        : null,
                  ),
                  title: Text(
                    name ?? '',
                    style: const TextStyle(
                        color: Colors.lightGreen,
                        fontSize: 20,
                        fontWeight: FontWeight.w500),
                  ),
                  subtitle: const Text('How are you doing?'),
                ),

                SizedBox(height: size.height*0.01),

                Container(
                  alignment: Alignment.center,
                  height: size.height*0.045,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: Colors.lightGreen[200],
                    borderRadius: BorderRadius.circular(5)
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: TextScroll(
                      'Hurray!🥳     Enjoy Fixed Consultation Fee Rs.2000 For All Doctors                              ',
                      mode: TextScrollMode.endless,
                      velocity: Velocity(pixelsPerSecond: Offset(50, 0)),
                      delayBefore: Duration(milliseconds: 500),
                      numberOfReps: 10,
                      pauseBetween: Duration(milliseconds: 00),
                      style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w500, fontStyle: FontStyle.italic),
                      textAlign: TextAlign.left,
                      selectable: true,

                    ),
                  ),
                ),

                SizedBox(height: size.height*0.03,),
                const Text(
                  'Upcoming Appointments',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: 18),
                ),




                SizedBox(height: size.height * 0.02),
                SizedBox(
                  height: size.height * 0.715,
                  width: double.infinity,
                  child: StreamBuilder<List<AppointmentUser>>(
                    stream: appointmentsStream,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        final appointments = snapshot.data!;
                        final filteredAppointments = appointments
                            .where((appointment) =>
                        appointment.userUID == currentUser?.uid)
                            .toList();

                        if (filteredAppointments.isEmpty) {
                          return const Text('No appointments found.');
                        }

                        return ListView.builder(
                          itemCount: filteredAppointments.length,
                          itemBuilder: (context, index) {
                            final appointment = filteredAppointments[index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Material(
                                shadowColor: Colors.lightGreen[100],
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.grey[100],
                                elevation: 10,
                                child: Container(
                                  constraints: BoxConstraints(
                                    maxHeight: size.height * 0.7,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                    child: ListTile(
                                      leading: CircleAvatar(
                                        backgroundImage: NetworkImage(
                                            appointment.doctorAvatarUrl),
                                      ),
                                      title: Text(
                                        'Dr. ' + appointment.doctorName,
                                        style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      subtitle: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            appointment.appointmentTime
                                                ?.toString() ??
                                                '',
                                            style: const TextStyle(
                                                color: Colors.lightGreen, fontSize: 12),
                                          ),
                                          SizedBox(height: size.height * 0.02),
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  MapsLauncher.launchQuery(
                                                      appointment.clinicAddress);
                                                },
                                                child: const Row(
                                                  children: [
                                                    Icon(Icons.directions,
                                                        color: Colors.lightGreen),
                                                    Text(
                                                      'Direction',
                                                      style: TextStyle(
                                                          color: Colors.lightGreen,
                                                          fontSize: 16,
                                                          fontWeight:
                                                          FontWeight.w500),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              GestureDetector(
                                                onTap: () async {
                                                  String phoneNumber = appointment.doctorPhone;
                                                  Uri callUri = Uri.parse("tel:$phoneNumber");

                                                  if (await canLaunchUrl(callUri)) {
                                                    await launchUrl(callUri);
                                                  } else {
                                                    print('Could not launch call');
                                                  }
                                                },
                                                child: const Row(
                                                  children: [
                                                    Icon(Icons.call, color: Colors.lightGreen),
                                                    Text(
                                                      'Call',
                                                      style: TextStyle(
                                                        color: Colors.lightGreen,
                                                        fontSize: 16,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),

                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      } else if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else {
                        return const CircularProgressIndicator();
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
