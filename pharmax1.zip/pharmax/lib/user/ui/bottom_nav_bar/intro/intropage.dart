import 'package:flutter/material.dart';
import 'package:pharmax/user/assetsUser.dart';
import '../../../../widgets/custom_btn.dart';
import '../bottom_av_bar.dart';

class IntroDoctorUserPannel extends StatefulWidget {
  const IntroDoctorUserPannel({super.key});

  @override
  State<IntroDoctorUserPannel> createState() => _IntroDoctorUserPannelState();
}

class _IntroDoctorUserPannelState extends State<IntroDoctorUserPannel> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Container(
                height: size.height*0.5,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.lightGreen,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Stack(
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(top: size.height*0.04),
                      child: Image.asset(AssetsUser.imagesIntroDoctor),
                    ),
                  ],
                ),
              ),

            SizedBox(height: size.height*0.03,),
              
            RichText(
              textAlign: TextAlign.center,
                text: const TextSpan(

              text: 'Welcome to our',
              style: TextStyle(
               color: Colors.black, fontWeight: FontWeight.w500, fontSize: 34,
              ),
              children: <TextSpan> [
                TextSpan(text: ' Doctor consulting App', style: TextStyle(color: Colors.lightGreen, fontSize: 34))
              ]
            ),),

              SizedBox(height: size.height*0.03,),
              const Text('Schedule quick doctor visits  withoutwaiting in line, and buy medications with confidence.', textAlign: TextAlign.start,  style: TextStyle(color: Colors.black, fontSize: 17),),


              SizedBox(height: size.height*0.05,),
              CustomBtn(
                text: 'Get started',
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (c)=>BottomNavBarUser()));
                },
              ),
              SizedBox(height: size.height*0.03,),
            ],
          ),
        ),
      ),
    );
  }
}
