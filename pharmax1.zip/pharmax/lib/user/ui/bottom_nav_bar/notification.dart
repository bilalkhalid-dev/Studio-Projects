import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../modelUser/appointments.dart';

class UserNotificationScreen extends StatefulWidget {
  @override
  _UserNotificationScreenState createState() => _UserNotificationScreenState();
}

class _UserNotificationScreenState extends State<UserNotificationScreen> {
  User? currentUser = FirebaseAuth.instance.currentUser;
  late Stream<List<AppointmentUser>> appointmentsStream;

  @override
  void initState() {
    super.initState();

    if (currentUser != null) {
      appointmentsStream = FirebaseFirestore.instance
          .collection('Appointments')
          .where('UserUID', isEqualTo: currentUser!.uid) // Filter appointments by the current user's UID (doctor's UID)
          .snapshots()
          .map((snapshot) => snapshot.docs
          .map((doc) => AppointmentUser.fromSnapshot(doc))
          .toList());
    } else {
      // Initialize appointmentsStream with an empty stream
      appointmentsStream = Stream<List<AppointmentUser>>.empty();
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notifications',
          style: TextStyle(color: Colors.lightGreen),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: StreamBuilder<List<AppointmentUser>>(
          stream: appointmentsStream,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final appointments = snapshot.data!;

              if (appointments.isEmpty) {
                return const Center(
                  child: Text('No appointments available'),
                );
              }

              return ListView.builder(
                itemCount: appointments.length,
                itemBuilder: (context, index) {
                  final appointment = appointments[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Material(
                      elevation: 5,
                      shadowColor: Colors.lightGreen,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        constraints: BoxConstraints(
                          maxHeight: size.height * 0.7,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundImage:
                              NetworkImage(appointment.doctorAvatarUrl),
                            ),
                            title: Text('Dr. ' + (appointment?.doctorName ?? ''), style: TextStyle(fontWeight: FontWeight.w500),),
                            subtitle: appointment?.status == 'Accepted'
                                ? const Text('Accepted your Appointment',
                                style: TextStyle(color: Colors.lightGreen, fontSize: 11), )
                                : appointment?.status == 'Rejected'
                                ? const Text('Rejected your Appointment',
                                style: TextStyle(color: Colors.red))
                                : const SizedBox(),
                            trailing: appointment?.status == 'Accepted'
                                ? Text(appointment.appointmentTime.toString(), style: TextStyle(fontSize: 10),)
                                : appointment?.status == 'Rejected'
                                ? const Icon(Icons.cancel, color: Colors.red)
                                : const SizedBox(),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }

            if (snapshot.hasError) {
              return const Center(
                child: Text('An error occurred'),
              );
            }

            return const Center(
              child: CircularProgressIndicator(),
            );
          },
        ),
      ),
    );
  }
}
