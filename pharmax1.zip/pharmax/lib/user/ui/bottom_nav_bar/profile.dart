import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../widgets/custom_btn.dart';
import '../auth/login_page.dart';

class ProfileScreenUser extends StatefulWidget {
  @override
  _ProfileScreenUserState createState() => _ProfileScreenUserState();
}

class _ProfileScreenUserState extends State<ProfileScreenUser> {
  String email = "";
  String name = "";
  String phone = "";
  String photoUrl = "";

  @override
  void initState() {
    super.initState();
    fetchDataFromSharedPreferences();
  }

  Future<void> fetchDataFromSharedPreferences() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    setState(() {
      email = sharedPreferences.getString("email") ?? "";
      name = sharedPreferences.getString("name") ?? "";
      phone = sharedPreferences.getString("phone") ?? "";
      photoUrl = sharedPreferences.getString("photoUrl") ?? "";
    });
  }

  @override
  Widget build(BuildContext context) {

    var newstyle = const TextStyle(color: Colors.black, fontSize: 16);
    var formStyle = const TextStyle(
        color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(
        color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);


    return  Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'Profile',
                  style: title,
                ),
                SizedBox(height: size.height * 0.04),
                Container(
                  height: size.height * 0.13,
                  width: size.height * 0.14,
                  child: CircleAvatar(
                    backgroundColor: Colors.grey[100],
                    backgroundImage: photoUrl != null
                        ? NetworkImage(photoUrl!)
                        : null,
                    child:photoUrl == null
                        ? Icon(
                      Icons.person,
                      color: Colors.lightGreen,
                      size: size.width * 0.08,
                    )
                        : null,
                  ),
                ),
                SizedBox(height: size.height * 0.01),
                Text(
                  name ?? '',
                  style: const TextStyle(
                    color: Colors.lightGreen,
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Column(
                  children: [
                    SizedBox(height: size.height * 0.04),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 5,
                      child: Container(
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Email:         ',
                                style: formStyle,
                              ),
                              Text(
                                email ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        alignment: Alignment.center,
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Phone:       ',
                                style: formStyle,
                              ),
                              Text(
                                phone ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: size.height * 0.07),
                  ],
                ),


                CustomBtn(
                  text: 'Sign Out',
                  onPressed: (){
                    _signOut(context);
                  },
                ),
                SizedBox(height: size.height * 0.02),

              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.of(context).pop();
      Navigator.push(context, MaterialPageRoute(builder: (c)=>const LoginPageUser()));
    } catch (e) {
      print('Error signing out: $e');
      // Show an error message or handle the error accordingly
    }
  }
}
