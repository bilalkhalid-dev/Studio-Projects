import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../modelUser/doctors.dart';
import '../../../../modelUser/user.dart';
import '../../../../widgets/custom_textformfield.dart';
import '../../../../widgets/error_dialog.dart';
import '../../../../widgets/loading_dialog.dart';
import '../bottom_av_bar.dart';

class BookAppointmentUser extends StatefulWidget {
  final Doctors? model;
  final Patients? pModel;

  const BookAppointmentUser({Key? key, this.model, this.pModel}) : super(key: key);

  @override
  State<BookAppointmentUser> createState() => _BookAppointmentUserState();
}

class _BookAppointmentUserState extends State<BookAppointmentUser> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController patientNameController = TextEditingController();
  final TextEditingController patientPhoneController = TextEditingController();
  final TextEditingController queryController = TextEditingController();

  String email = '';
  String name = '';
  String phone = '';
  String photoUrl = '';

  @override
  void initState() {
    super.initState();
    fetchDataFromSharedPreferences();
  }

  Future<void> fetchDataFromSharedPreferences() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    setState(() {
      email = sharedPreferences.getString('email') ?? '';
      name = sharedPreferences.getString('name') ?? '';
      phone = sharedPreferences.getString('phone') ?? '';
      photoUrl = sharedPreferences.getString('photoUrl') ?? '';
    });
  }

  String patientName = '';
  String patientPhone = '';
  String patientQuery = '';
  DateTime? appointmentTime;

  bool isWithinWorkingHours() {
    if (widget.model != null && appointmentTime != null) {
      final startTime = widget.model!.startTime;
      final endTime = widget.model!.endTime;

      return appointmentTime!.isAfter(startTime) && appointmentTime!.isBefore(endTime);
    }
    return false;
  }

  Future<void> formValidation(BuildContext context) async {
    if (_formKey.currentState!.validate()) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (c) {
          return LoadingDialog(
            message: 'Please wait...',
          );
        },
      );

      if (patientPhone.isNotEmpty &&
          patientName.isNotEmpty &&
          patientQuery.isNotEmpty &&
          appointmentTime != null) {
        try {
          // Clear the form fields
          patientNameController.clear();
          patientPhoneController.clear();
          queryController.clear();

          // Save data to Firestore
          await saveDataToFirestore();

          // Close the loading dialog
          Navigator.of(context).pop();

          // Show success message or perform any other action
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('Appointment Confirmed'),
                content: const Text('Your appointment has been confirmed.'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (c) => BottomNavBarUser()));
                    },
                    child: const Text('OK'),
                  ),
                ],
              );
            },
          );
        } catch (e) {
          // Close the loading dialog
          Navigator.of(context).pop();

          showDialog(
            context: context,
            builder: (c) {
              return CustomErrorDialog(
                message: 'An error occurred while processing your appointment. Please try again.',
              );
            },
          );
        }
      } else {
        // Close the loading dialog
        Navigator.of(context).pop();

        showDialog(
          context: context,
          builder: (c) {
            return CustomErrorDialog(
              message: 'All fields must be filled.',
            );
          },
        );
      }
    }
  }

  Future<void> saveDataToFirestore() async {
    try {
      final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
      final User? firebaseUser = firebaseAuth.currentUser;
      if (firebaseUser != null) {
        final uid = firebaseUser.uid;
        final docRef = FirebaseFirestore.instance.collection('appointments').doc(uid);
        docRef.set({
          'patientName': patientName,
          'patientPhone': patientPhone,
          'patientQuery': patientQuery,
          'appointmentTime': appointmentTime,
          'doctorId': widget.model!.DoctorUID,
          'doctorName': widget.model!.DoctorName,
          'doctorSpecialty': widget.model!.doctorSpecialization,
          'doctorPhotoUrl': widget.model!.DoctorAvatarUrl,
          'status': 'Pending',
          'patientEmail': email,
          'patientProfilePhoto': photoUrl,
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      rethrow; // Re-throw the exception to be caught by the formValidation method
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Appointment'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                CustomTextFormField(
                  controller: patientNameController,
                  hintText: 'Enter your name',
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      patientName = value;
                    });
                  },
                ),
                const SizedBox(height: 16.0),
                CustomTextFormField(
                  controller: patientPhoneController,
                  hintText: 'Enter your phone number',
                  keyboardType: TextInputType.phone,
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your phone number';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      patientPhone = value;
                    });
                  },
                ),
                const SizedBox(height: 16.0),
                CustomTextFormField(
                  controller: queryController,
                  hintText: 'Enter your query',
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your query';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    setState(() {
                      patientQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 16.0),
                ListTile(
                  title: const Text('Appointment Time'),
                  subtitle: appointmentTime == null
                      ? const Text('Select appointment time')
                      : Text('Selected Time: ${appointmentTime!.toString()}'),
                  trailing: const Icon(Icons.keyboard_arrow_down),
                  onTap: () {
                    showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 7)),
                    ).then((selectedDate) {
                      if (selectedDate != null) {
                        showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.now(),
                        ).then((selectedTime) {
                          if (selectedTime != null) {
                            setState(() {
                              appointmentTime = DateTime(
                                selectedDate.year,
                                selectedDate.month,
                                selectedDate.day,
                                selectedTime.hour,
                                selectedTime.minute,
                              );
                            });
                          }
                        });
                      }
                    });
                  },
                ),
                const SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () => formValidation(context),
                  child: const Text('Book Appointment'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
