
import 'package:flutter/material.dart';
import '../../../../../modelUser/doctors.dart';
import '../../../../../widgets/custom_btn.dart';
import '../book_appointment.dart';


class DoctorsInfoBookUser extends StatelessWidget {
  final Doctors? doctorModel;

  DoctorsInfoBookUser({
    this.doctorModel, required Doctors model, required BuildContext context,

  });


  @override
  Widget build(BuildContext context) {
    var newstyle = const TextStyle(color: Colors.black, fontSize: 16);
    var formStyle = const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);

    // List of weekdays names
    List<String> weekdays = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];

    // Get the working days
    List<String> workingDays = weekdays
        .asMap()
        .entries
        .where((entry) => doctorModel!.weekdays![entry.key])
        .map((entry) => entry.value)
        .toList();

    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'Profile',
                  style: title,
                ),
                SizedBox(height: size.height * 0.04),
                SizedBox(
                  height: size.height * 0.13,
                  width: size.height * 0.14,
                  child: CircleAvatar(
                    backgroundColor: Colors.grey[100],
                    backgroundImage: doctorModel!.DoctorAvatarUrl != null
                        ? NetworkImage(doctorModel!.DoctorAvatarUrl!)
                        : null,
                    child: doctorModel!.DoctorAvatarUrl == null
                        ? Icon(
                      Icons.person,
                      color: Colors.lightGreen,
                      size: size.width * 0.08,
                    )
                        : null,
                  ),
                ),
                SizedBox(height: size.height * 0.01),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Dr. ', style: TextStyle(color: Colors.black, fontSize: 16),),
                    Text(
                      doctorModel!.DoctorName ?? '',
                      style: const TextStyle(
                        color: Colors.lightGreen,
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: size.height*0.003,),
                Text(doctorModel!.doctorSpecialization, style: const TextStyle(color: Colors.grey),),
                Column(
                  children: [
                    SizedBox(height: size.height * 0.04),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        alignment: Alignment.center,
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'ID:               ',
                                style: formStyle,
                              ),
                              Text(
                                doctorModel!.doctorRegistrationID ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 5,
                      child: Container(
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Email:         ',
                                style: formStyle,
                              ),
                              Text(
                                doctorModel!.DoctorEmail ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        alignment: Alignment.center,
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Phone:       ',
                                style: formStyle,
                              ),
                              Text(
                                doctorModel!.doctorPhone ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        alignment: Alignment.center,
                        height: size.height*0.07,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Specialization:     ',
                                style: formStyle,
                              ),
                              Text(
                                doctorModel!.doctorSpecialization ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        alignment: Alignment.center,
                        height: size.height*0.09,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Address:    ',
                                style: formStyle,
                              ),
                              SizedBox(
                                width: size.width * 0.6,
                                child: Text(
                                  doctorModel!.clinicAddress ?? '',
                                  textAlign: TextAlign.start,
                                  style: newstyle,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[100],
                      elevation: 10,
                      child: Container(
                        constraints: BoxConstraints(
                          maxHeight: size.height*0.65,
                        ),
                        alignment: Alignment.center,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'About Doctor:     ',
                                style: formStyle,
                              ),
                              SizedBox(height: size.height*0.01,),
                              SingleChildScrollView(
                                child: Text(
                                  doctorModel!.doctorInfo ?? '',
                                  style: newstyle,
                                  textAlign: TextAlign.start,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Material(
                      elevation: 10,
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        height: size.height*0.33,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Container(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Working Days:  ',
                                  style: formStyle,
                                ),
                                SizedBox(height: size.height*0.01,),
                                if (workingDays.isNotEmpty)
                                  ...workingDays
                                      .map((day) => Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Text(
                                      day,
                                      style: newstyle,
                                    ),
                                  ))
                                      .toList(),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),
                    Material(
                      elevation: 10,
                      shadowColor: Colors.lightGreen[100],
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: double.infinity,
                        height: size.height*0.07,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Text(
                                'Working Hours: ',
                                style: formStyle,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                doctorModel!.startTime ?? '',
                                style: newstyle,
                              ),
                              Text(
                                ' - ',
                                style: newstyle,
                              ),
                              Text(
                                doctorModel!.endTime ?? '',
                                style: newstyle,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.07),
                    CustomBtn(
                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (c)=>BookAppointmentUser(model: doctorModel,)));
                      },
                      text: "Book Appointment",
                    ),
                    SizedBox(height: size.height * 0.07),

                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

