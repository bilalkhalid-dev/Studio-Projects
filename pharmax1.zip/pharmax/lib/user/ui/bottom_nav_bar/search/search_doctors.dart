import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pharmax/user/ui/bottom_nav_bar/search/doctors_info/doctors_info.dart';

import '../../../../modelUser/doctors.dart';



class SearchDoctorsUser extends StatefulWidget {
  Doctors? model;

  SearchDoctorsUser({
    this.model
  });
  @override
  State<SearchDoctorsUser> createState() => _SearchDoctorsUserState();
}

class _SearchDoctorsUserState extends State<SearchDoctorsUser> {


  String searchQuery = '';
  @override
  Widget build(BuildContext context) {
    var color = const Color.fromRGBO(238, 238, 238, 1);
    var size = MediaQuery.of(context).size;
    var title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Text('Search Doctor', style: title,),

              SizedBox(height: size.height * 0.04,),
              SizedBox(
                height: size.height*0.055,
                child: TextFormField(
                  decoration:  InputDecoration(
                      filled: true,
                      fillColor: Colors.grey[200],
                      labelText: 'Search by name or specialty',
                      prefixIcon: const Icon(Icons.search),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            color: color
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(
                            color: Colors.lightGreen,
                            style: BorderStyle.solid,
                            width: 2

                        ),
                      )
                  ),
                  onChanged: (value) {
                    setState(() {
                      searchQuery = value;
                    });
                  },
                ),
              ),
              SizedBox(height: size.height * 0.03,),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection("Doctors")
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return const Center(child: Text('No doctors found.'));
                    }
                    final doctorDocs = snapshot.data!.docs;
                    List filteredDoctors = doctorDocs
                        .map((doc) => Doctors.fromJson(doc.data()! as Map<String, dynamic>))
                        .toList();

                    if (searchQuery.isNotEmpty) {
                      filteredDoctors = filteredDoctors.where((doctor) =>
                      doctor.DoctorName?.toLowerCase().contains(searchQuery.toLowerCase()) == true ||
                          doctor.doctorSpecialization?.toLowerCase().contains(searchQuery.toLowerCase()) == true
                      ).toList();
                    }




                    // if (searchQuery.isNotEmpty) {
                    //   filteredDoctors = filteredDoctors.where((doctor) =>
                    //   doctor.doctorName.toLowerCase().contains(searchQuery.toLowerCase()) ||
                    //       doctor.specialty.toLowerCase().contains(searchQuery.toLowerCase())
                    //   ).toList();
                    // }

                    return GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 10.0,
                        crossAxisSpacing: 10.0,
                        childAspectRatio: 0.75,
                      ),
                      itemCount: filteredDoctors.length,
                      itemBuilder: (context, index) {
                        Doctors dModel = filteredDoctors[index];
                        return DoctorsInfoBookUser(
                          model: dModel,
                          context: context,
                        );
                      },
                    );
                  },

                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// (context, snapshot) {
// if (snapshot.connectionState == ConnectionState.waiting) {
// return Center(child: circularProgressBar());
// }
// if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
// return const Center(child: Text('No doctors found.'));
// }
// final doctorDocs = snapshot.data!.docs;
// return GridView.builder(
// gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
// crossAxisCount: 2,
// mainAxisSpacing: 10.0,
// crossAxisSpacing: 10.0,
// childAspectRatio: 0.75,
// ),
// itemCount: doctorDocs.length,
// itemBuilder: (context, index) {
// Doctors dModel = Doctors.fromjson(
// doctorDocs[index].data()! as Map<String, dynamic>,
// );
// return DoctorsInfo(
// model: dModel,
// context: context,
// );
// },
// );
// },