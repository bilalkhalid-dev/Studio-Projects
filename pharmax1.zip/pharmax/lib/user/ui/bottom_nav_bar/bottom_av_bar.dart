import 'package:flutter/material.dart';
import 'package:pharmax/user/ui/bottom_nav_bar/profile.dart';
import 'package:pharmax/user/ui/bottom_nav_bar/search/chatboot.dart';
import 'package:pharmax/user/ui/bottom_nav_bar/search/search_doctors.dart';

import 'homescree.dart';
import 'notification.dart';
class BottomNavBarUser extends StatefulWidget {

  @override
  _BottomNavBarUserState createState() => _BottomNavBarUserState();
}

class _BottomNavBarUserState extends State<BottomNavBarUser> {
  int _selectedIndex = 0;

   final List<Widget> _widgetOptions = <Widget>[
    UserHomeScreen(),
     SearchDoctorsUser(),
     UserNotificationScreen(),
     ChatScreen(),
     ProfileScreenUser(),
   ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        unselectedLabelStyle: const TextStyle(fontSize: 10),
        elevation: 2,
        selectedFontSize: 14,
        unselectedFontSize: 12,
        selectedItemColor: Colors.lightGreen,
        unselectedItemColor: Colors.grey,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month_rounded),
            label: 'Appointment',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_none_outlined),
            label: 'Notification',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'ChatBoot',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_2_outlined),
            label: 'Account',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}