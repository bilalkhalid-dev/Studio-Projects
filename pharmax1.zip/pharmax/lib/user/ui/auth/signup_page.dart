import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as fStorage;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../global/global.dart';
import '../../../widgets/custom_btn.dart';
import '../../../widgets/custom_textformfield.dart';
import '../../../widgets/error_dialog.dart';
import '../../../widgets/loading_dialog.dart';
import '../bottom_nav_bar/intro/intropage.dart';
import 'login_page.dart';

class SignupPageUser extends StatefulWidget {
  const SignupPageUser({Key? key}) : super(key: key);

  @override
  State<SignupPageUser> createState() => _SignupPageUserState();
}

class _SignupPageUserState extends State<SignupPageUser> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController  emailController = TextEditingController();
  TextEditingController  phoneController = TextEditingController();
  TextEditingController  passController = TextEditingController();
  TextEditingController  confirmPassController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  var obscureText = false;

  XFile? imageXFile;
  final ImagePicker _picker = ImagePicker();

  Position? position;
  List<Placemark>? placeMarks;

  String profileImage = "";
  String completeAddress = "";


  Future<void> requestPermissions() async {
    final permissions = [
      Permission.location,
      Permission.camera,
      Permission.storage,
    ];

    Map<Permission, PermissionStatus> status = await permissions.request();

    // Handle the permission statuses
    status.forEach((permission, permissionStatus) {
      if (permissionStatus.isGranted) {
        // Permission granted
        print('${permission.toString()} granted.');
      } else if (permissionStatus.isDenied) {
        // Permission denied
        print('${permission.toString()} denied.');
      } else if (permissionStatus.isPermanentlyDenied) {
        // Permission permanently denied
        print('${permission.toString()} permanently denied.');
      }
    });
  }






  Future<void> _getImage() async
  {
    imageXFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      imageXFile;
    });
  }




  Future<void> getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message: "Location services are disabled. Please enable them to continue.",
          );
        },
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      showDialog(
        context: context,
        builder: (c) {
          return CustomErrorDialog(
            message:
            "Location permissions are permanently denied. Please allow the app to access your location in the device settings.",
          );
        },
      );
      return;
    }

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        showDialog(
          context: context,
          builder: (c) {
            return CustomErrorDialog(
              message:
              "Location permissions are denied. Please allow the app to access your location.",
            );
          },
        );
        return;
      }
    }

    Position newPosition = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      position = newPosition;
    });

    List<Placemark> placeMarks = await placemarkFromCoordinates(
      position!.latitude,
      position!.longitude,
    );

    Placemark pMark = placeMarks[0];

    setState(() {
      completeAddress = '${pMark.subThoroughfare} ${pMark.thoroughfare}, ${pMark.subLocality} ${pMark.locality}, ${pMark.subAdministrativeArea}, ${pMark.administrativeArea} ${pMark.postalCode}, ${pMark.country}';
      locationController.text = completeAddress;
    });
  }
  Future<void> formValidation() async
  {
    if(imageXFile == null)
    {
      showDialog(
          context: context,
          builder: (c)
          {
            return CustomErrorDialog(
              message: "Please select an image.",
            );
          }
      );
    }
    else
    {
      if(passController.text == confirmPassController.text)
      {
        if(confirmPassController.text.isNotEmpty && emailController.text.isNotEmpty && nameController.text.isNotEmpty && phoneController.text.isNotEmpty && locationController.text.isNotEmpty)
        {
          //start uploading image
          showDialog(
              context: context,
              builder: (c)
              {
                return LoadingDialog(
                  message: "Registering Account",
                );
              }
          );

          String fileName = DateTime.now().millisecondsSinceEpoch.toString();
          fStorage.Reference reference = fStorage.FirebaseStorage.instance.ref().child("Users").child(fileName);
          fStorage.UploadTask uploadTask = reference.putFile(File(imageXFile!.path));
          fStorage.TaskSnapshot taskSnapshot = await uploadTask.whenComplete(() {});
          await taskSnapshot.ref.getDownloadURL().then((url) {
            profileImage = url;

            //save info to firestore
            authenticateSellerAndSignUp();
          });
        }
        else
        {
          showDialog(
              context: context,
              builder: (c)
              {
                return CustomErrorDialog(
                  message: "Please write the complete required info for Registration.",
                );
              }
          );
        }
      }
      else
      {
        showDialog(
            context: context,
            builder: (c)
            {
              return CustomErrorDialog(
                message: "Password do not match.",
              );
            }
        );
      }
    }
  }

  void authenticateSellerAndSignUp() async
  {
    User? currentUser;

    await firebaseAuth.createUserWithEmailAndPassword(
      email: emailController.text.trim(),
      password: passController.text.trim(),
    ).then((auth) {
      currentUser = auth.user;
    }).catchError((error){
      Navigator.pop(context);
      showDialog(
          context: context,
          builder: (c)
          {
            return CustomErrorDialog(
              message: error.message.toString(),
            );
          }
      );
    });

    if(currentUser != null)
    {
      saveDataToFirestore(currentUser!).then((value) {
        Navigator.pop(context);
        //send user to homePage
        Route newRoute = MaterialPageRoute(builder: (c) => const IntroDoctorUserPannel());
        Navigator.pushReplacement(context, newRoute);
      });
    }
  }

  Future saveDataToFirestore(User currentUser) async
  {
    FirebaseFirestore.instance.collection("Users").doc(currentUser.uid).set({
      "UserUID": currentUser.uid,
      "UserEmail": currentUser.email,
      "UserName": nameController.text.trim(),
      "UserAvatarUrl": profileImage,
      "UserPhone": phoneController.text.trim(),
      "status": "approved",
      "earnings": 0.0,
      "lat": position!.latitude,
      "lng": position!.longitude,
      "UserAddress": completeAddress,

    });

    //save data locally
    sharedPreferences = await SharedPreferences.getInstance();
    await sharedPreferences!.setString("uid", currentUser.uid);
    await sharedPreferences!.setString("email", currentUser.email.toString());
    await sharedPreferences!.setString("name", nameController.text.trim());
    await sharedPreferences!.setString("phone", phoneController.text.trim());
    await sharedPreferences!.setString("photoUrl", profileImage);
  }

  @override
  void initState() {
    // TODO: implement initState
    getCurrentLocation();
    requestPermissions();
  }

  @override
  Widget build(BuildContext context) {
    var formStyle = const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w500);
    var size = MediaQuery.of(context).size;
    var  title = const TextStyle(color: Colors.lightGreen, fontSize: 24, fontWeight: FontWeight.w500);
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text('SIGNUP', style: title,),
                SizedBox(height: size.height*0.03,),
                InkWell(
                  onTap: ()
                  {
                    _getImage();
                  },
                  child: CircleAvatar(
                    radius: MediaQuery.of(context).size.width * 0.15,
                    backgroundColor: Colors.white,
                    backgroundImage: imageXFile==null ? null : FileImage(File(imageXFile!.path)),
                    child: imageXFile == null
                        ?
                    Icon(
                      Icons.add_photo_alternate,
                      size: MediaQuery.of(context).size.width * 0.15,
                      color: Colors.lightGreen,
                    ) : null,
                  ),






                ),
                SizedBox(height: size.height*0.03,),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(' Name', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      CustomTextFormField(
                        controller: nameController,
                        obscureText: false,
                        keyboardType: TextInputType.name,
                      ),
                      SizedBox(height: size.height*0.02,),
                      Text(' Email', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      CustomTextFormField(
                        controller: emailController,
                        obscureText: false,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      SizedBox(height: size.height*0.02,),
                      Text(' Phone No.', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      CustomTextFormField(
                        controller: phoneController,
                        obscureText: false,
                        keyboardType: TextInputType.phone,
                      ),
                      SizedBox(height: size.height*0.02,),
                      Text(' Password', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      SizedBox(
                        height: size.height*0.05,
                        child: TextFormField(
                          controller: passController,
                          obscureText: obscureText,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  obscureText = !obscureText;
                                });
                              },
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.grey),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.lightGreen),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.red),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.lightGreen),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: size.height*0.02,),
                      Text(' Confirm Password', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      SizedBox(
                        height: size.height*0.05,
                        child: TextFormField(
                          controller: confirmPassController,
                          obscureText: obscureText,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  obscureText = !obscureText;
                                });
                              },
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.grey),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.lightGreen),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.red),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: Colors.lightGreen),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: size.height*0.02,),
                      Text(' My Location', style: formStyle,),
                      SizedBox(height: size.height*0.01,),
                      SizedBox(
                        height: size.height*0.067,
                        child: CustomTextFormField(
                          controller: locationController,
                          obscureText: false,
                          keyboardType: TextInputType.text,
                          suffixIcon: Icons.my_location,
                          onTap: (){
                            getCurrentLocation();
                          }
                        ),
                      ),

                    ],
                  ),
                ),




                SizedBox(height: size.height*0.03,),

                CustomBtn(text: "Signup", onPressed: (){
                  formValidation();
                },),
                SizedBox(height: size.height*0.04,),
                SizedBox(height: size.height*0.01,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Already have an account?'),
                    TextButton(onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>const LoginPageUser()));
                    }, child: const Text('Login'))
                  ],
                ),
                SizedBox(height: size.height*0.02,),

              ],
            ),
          ),
        ),
      ),
    );
  }
}