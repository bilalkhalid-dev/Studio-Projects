import 'package:flutter/material.dart';

class CustomBtn extends StatelessWidget {

  String? text;
  var onPressed;

  CustomBtn({
    this.text,
    this.onPressed,
});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return InkWell(
      onTap: onPressed,
      child: Container(
        alignment: Alignment.center,
        height: size.height*0.05,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.lightGreen,
          borderRadius: BorderRadius.circular(10),

        ),
        child: Text(text!, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w500),),
      ),
    );
  }
}
