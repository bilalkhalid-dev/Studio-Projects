import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {

  bool? obscureText = false;
  var controller;
  var suffixIcon;
  var keyboardType;
  var hintText;
  var onTap;
  var onChanged;
  var validator;

  CustomTextFormField({Key? key,
    this.keyboardType,
    this.hintText,
    this.suffixIcon,
    this.controller,
    this.obscureText,
    this.onTap,
    this.onChanged,
    this.validator,
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SizedBox(
      height: size.height*0.05,
      child: TextFormField(
        onChanged: onChanged,
        textAlignVertical: TextAlignVertical.center,
        textDirection: TextDirection.ltr,
        controller: controller,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 14,
        ),
        cursorColor: Colors.lightGreen,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: const TextStyle(color: Colors.grey),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Colors.grey,
            ),

          ),

          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Colors.lightGreen,
            ),

          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Colors.red,
            ),

          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Colors.lightGreen,
            ),

          ),
          suffixIcon: IconButton(onPressed: onTap, icon: Icon(suffixIcon)),
          suffixIconColor: Colors.lightGreen,
        ),
        keyboardType: keyboardType,
        validator: validator,
      ),
    );
  }


}
