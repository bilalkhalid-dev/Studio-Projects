import 'package:flutter/material.dart';

class CustomErrorDialog extends StatelessWidget {

  var message;

  CustomErrorDialog({
    this.message,
});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      key: key,
      content: Text(message!),
      
      actions: [
        ElevatedButton(
          
          onPressed: (){
            Navigator.pop(context);
          },
          
          child: const Center(child: Text('OK', style: TextStyle(color: Colors.white),)),

          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.lightGreen,
          ),
          
        ),
      ],
    );
  }
}
