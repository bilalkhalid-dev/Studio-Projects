import 'package:flutter/material.dart';
import 'package:pharmax/widgets/progress_bar.dart';


class LoadingDialog extends StatelessWidget {

  final String? message;

  LoadingDialog({super.key,
    this.message,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      key: key,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
           circularProgressBar(),
          const SizedBox(height: 10,),
          Text('${message!} Please Wait...'),
        ],
      ),
    );
  }
}
