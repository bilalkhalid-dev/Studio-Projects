import 'package:cloud_firestore/cloud_firestore.dart';

class Appointment {
  String? doctorId;
  String? patientName;
  String? patientQuery;
  String? UserAvatarUrl;
  Timestamp? appointmentTime;

  Appointment({
    this.doctorId,
    this.patientName,
    this.patientQuery,
    this.UserAvatarUrl,
    this.appointmentTime,
  });

  factory Appointment.fromSnapshot(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Appointment(
      doctorId: data['doctorId'] ?? '',
      patientName: data['patientName'] ?? '',
      patientQuery: data['patientQuery'] ?? '',
      UserAvatarUrl: data['UserAvatarUrl'] ?? '',
      appointmentTime: data['appointmentTime'],
    );
  }
}







// import 'package:cloud_firestore/cloud_firestore.dart';
//
// class Appointment {
//   final String id;
//   final String doctorId; // Add the doctorId field
//   final String patientName;
//   final String patientPhone;
//   final String patientQuery;
//   final String status;
//   final DateTime appointmentTime;
//   var UserAvatarUrl;
//
//   Appointment({
//     required this.id,
//     required this.doctorId, // Add the doctorId parameter
//     required this.patientName,
//     required this.patientPhone,
//     required this.patientQuery,
//     required this.status,
//     required this.appointmentTime,
//     this.UserAvatarUrl,
//
//   });
//
//   factory Appointment.fromSnapshot(DocumentSnapshot doc) {
//     final data = doc.data() as Map<String, dynamic>;
//
//     return Appointment(
//        id: doc.id,
//       doctorId: data['doctorUID'], // Assign the doctorUID to doctorId
//       patientName: data['patientName'],
//       patientPhone: data['patientPhone'],
//       patientQuery: data['patientQuery'],
//       UserAvatarUrl: data['UserAvatarUrl'],
//       status: data['status'],
//       appointmentTime: data['appointmentTime'].toDate(),
//     );
//   }
// }
