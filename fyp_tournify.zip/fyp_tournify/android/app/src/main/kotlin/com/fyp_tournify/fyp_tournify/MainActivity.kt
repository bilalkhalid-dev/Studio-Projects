package com.fyp_tournify.fyp_tournify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
