class Product {
  String productName;
  String productDescription;
  double productPrice;
  String? productImage;

  Product({
    required this.productName,
    required this.productDescription,
    required this.productPrice,
    this.productImage,
  });

  @override
  String toString() {
    return 'Product{name: $productName, description: $productDescription, price: $productPrice, image: $productImage}';
  }
}
