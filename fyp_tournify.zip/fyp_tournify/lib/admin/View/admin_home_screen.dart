import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import 'admin_all_orders.dart';
import 'ground_booking_requests.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({Key? key}) : super(key: key);

  @override
  _AdminHomeScreenState createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: AppText(
          text: 'Admin Dashboard',
          textColor: Colors.white,
          fontSize: 20,
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomBotton(
                onTap: (){
                  Get.to(()=>AdminGroundBookingScreen());
                },
                label: 'All Ground Requests',
              ),
              SizedBox(height: 20,),
              CustomBotton(
                onTap: (){
                  Get.to(()=>AdminAllOrders());
                },
                label: 'All Orders',
              )
            ],
          ),
        ),
      )
    );
  }
}
