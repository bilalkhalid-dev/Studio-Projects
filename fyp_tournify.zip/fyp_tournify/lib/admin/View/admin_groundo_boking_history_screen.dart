import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../User/Model/ground_booking_model.dart';

class AdminGroundBookingHistoryScreen extends StatelessWidget {
  const AdminGroundBookingHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text('Booking History',
            style: TextStyle(color: Colors.white)),
      ),
      backgroundColor: Colors.black,
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('groundbooking')
            .where('status', whereIn: ['Approved', 'Rejected']).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
                child: Text('No booking history found',
                    style: TextStyle(color: Colors.white)));
          }

          final bookingRequests = snapshot.data!.docs.map((doc) {
            return GroundBookingModel.fromJson(
                doc.data() as Map<String, dynamic>);
          }).toList();

          return ListView.builder(
            itemCount: bookingRequests.length,
            itemBuilder: (context, index) {
              final booking = bookingRequests[index];
              return Card(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Name: ${booking.groundName}', style: TextStyle(color: Colors.black)),

                      Text('Email: ${booking.groundTiming}', style: TextStyle(color: Colors.black)),
                      Text('Name: ${booking.firstName}', style: TextStyle(color: Colors.black)),

                      Text('Email: ${booking.email}',
                          style: TextStyle(color: Colors.black)),
                      Text('Phone: ${booking.phoneNumber}',
                          style: TextStyle(color: Colors.black)),
                      Text('Date: ${booking.date}',
                          style: TextStyle(color: Colors.black)),
                      Text('Reason: ${booking.reason}',
                          style: TextStyle(color: Colors.black)),
                      SizedBox(height: 5,),
                      Row(
                        children: [
                          Text('Status: '),
                          Container(
                            padding: EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: booking.status == 'Approved'
                                  ? Colors.green
                                  : booking.status == 'Rejected'
                                      ? Colors.red
                                      : Colors.black,
                              borderRadius: BorderRadius.circular(5)
                            ),
                            child: Text(
                              booking.status == 'Approved'
                                  ? 'Approved'
                                  : booking.status == 'Rejected'
                                      ? 'Rejected'
                                      : 'Pending',
                              style: TextStyle(color: Colors.white,fontSize: 10),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
