import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../Res/Widgets/custom_botton.dart';
import '../../User/Model/ground_booking_model.dart';
import 'admin_groundo_boking_history_screen.dart';

class AdminGroundBookingScreen extends StatelessWidget {
  const AdminGroundBookingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text('Ground Booking Requests', style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminGroundBookingHistoryScreen()),
              );
            },
          ),
        ],
      ),
      backgroundColor: Colors.black,
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('groundbooking')
            .where('status', isEqualTo: 'pending')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No booking requests found', style: TextStyle(color: Colors.white)));
          }

          final bookingRequests = snapshot.data!.docs.map((doc) {
            return GroundBookingModel.fromJson(doc.data() as Map<String, dynamic>);
          }).toList();

          return ListView.builder(
            itemCount: bookingRequests.length,
            itemBuilder: (context, index) {
              final booking = bookingRequests[index];
              return Card(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Ground Name: ${booking.groundName}', style: TextStyle(color: Colors.black)),
                         Spacer(),
                          Container(
                            padding: EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: _getStatusColor(booking.status),
                            ),
                            child: Text(
                              '${booking.status}',
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 10, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      Text('Ground Timing: ${booking.groundTiming}', style: TextStyle(color: Colors.black)),
                      Text('Name: ${booking.firstName}', style: TextStyle(color: Colors.black)),
                      Text('Email: ${booking.email}', style: TextStyle(color: Colors.black)),
                      Text('Phone: ${booking.phoneNumber}', style: TextStyle(color: Colors.black)),
                      Text('Date: ${booking.date}', style: TextStyle(color: Colors.black)),
                      Text('Reason: ${booking.reason}', style: TextStyle(color: Colors.black)),
                      Text(
                        'Status: ${booking.status}',
                        style: TextStyle(color: Colors.black),
                      ),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [

                          CustomBotton(
                            fontSize: 10,
                            borderRadius: 5,
                            height: 30,
                            width: 60,
                            label: 'Approved',
                            onTap: () {
                              _updateBookingStatus(booking.requestId, 'Approved');
                            },
                          ),
                          SizedBox(width: 10),
                          CustomBotton(
                            backgroundColor: Colors.red,
                            fontSize: 10,
                            borderRadius: 5,
                            height: 30,
                            width: 60,
                            label: 'Rejected',
                            onTap: () {
                              _updateBookingStatus(booking.requestId, 'Rejected');
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'Approved':
        return Colors.teal;
      case 'Rejected':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
  void _updateBookingStatus(String requestId, String status) {
    FirebaseFirestore.instance.collection('groundbooking').doc(requestId).update({'status': status});
  }
}
