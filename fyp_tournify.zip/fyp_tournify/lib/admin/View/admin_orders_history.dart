import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_svg/svg.dart';
import '../../Res/Widgets/app_text.dart';
import '../../User/Model/order_model.dart'; // Adjust the path as per your project structure

class AdminOrderHistory extends StatefulWidget {
  const AdminOrderHistory({Key? key}) : super(key: key);

  @override
  State<AdminOrderHistory> createState() => _AdminOrderHistoryState();
}

class _AdminOrderHistoryState extends State<AdminOrderHistory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: Text(
          'Admin Order History',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('orders').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                'No orders found.',
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          List<UserOrder> orders = snapshot.data!.docs
              .map((doc) => UserOrder.fromMap(doc.data() as Map<String, dynamic>))
              .toList();

          // Filter orders to show only delivered or cancelled orders
          List<UserOrder> deliveredOrCancelledOrders = orders
              .where((order) =>
          order.status.toLowerCase() == 'delivered' ||
              order.status.toLowerCase() == 'cancelled')
              .toList();

          // Sort the filtered orders by date
          deliveredOrCancelledOrders.sort(
                  (a, b) => b.currentTime.compareTo(a.currentTime)); // Sort by descending date

          return ListView.builder(
            itemCount: deliveredOrCancelledOrders.length,
            itemBuilder: (context, index) {
              UserOrder order = deliveredOrCancelledOrders[index];

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade700),
                  color: Colors.grey.shade900,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Order No: ',
                          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
                        ),
                        Container(
                          padding: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.cyanAccent.shade700,
                          ),
                          child: AppText(
                            text: '${order.orderNo}',
                            fontWeight: FontWeight.w600,
                            fontSize: 10,
                            textColor: Colors.white,
                          ),
                        ),

                        Spacer(),
                        Container(
                          padding: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: _getStatusColor(order.status),
                          ),
                          child: Text(
                            '${order.status}',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 10, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Name:     ${order.firstName}',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Delivery Address:     ${order.address}',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
                    ),
                    const SizedBox(height: 10),

                    const SizedBox(height: 10),
                    Row(
                      children: [
                        AppText(
                          text: 'Payment Method: ',
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          textColor: Colors.white,
                        ),
                        Spacer(),
                        SvgPicture.asset(
                          _getPaymentMethodIcon(order.paymentMethod),
                          width: 20,
                          height: 20,
                          color: Colors.teal,
                        ),
                        const SizedBox(width: 8),
                        AppText(
                          text: order.paymentMethod,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          textColor: Colors.white,
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    AppText(
                      text: 'Ordered Items:',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      textColor: Colors.white,
                    ),
                    const SizedBox(height: 5),
                    ...order.products.map((product) => Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          if (product.productImage.isNotEmpty)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                product.productImage,
                                width: 60,
                                height: 60,
                                fit: BoxFit.cover,
                              ),
                            ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    AppText(
                                      text: '${product.productName} x ${product.productQuantity}',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400,
                                      textColor: Colors.white,
                                    ),
                                    AppText(
                                      text:
                                      '\$${(product.productPrice * product.productQuantity).toStringAsFixed(2)}',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400,
                                      textColor: Colors.white,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    )),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        AppText(
                          text: 'Shipping Amount:',
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          textColor: Colors.white,
                        ),
                        AppText(
                          text: '\$${order.shipping.toStringAsFixed(2)}',
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          textColor: Colors.white,
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Divider(color: Colors.white),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total Amount:',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
                        ),
                        Text(
                          '\$${order.totalAmount.toStringAsFixed(2)}',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'delivered':
        return Colors.teal;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
  String _getPaymentMethodIcon(String paymentMethod) {
    switch (paymentMethod.toLowerCase()) {
      case 'card':
        return 'assets/icons/card.svg';
      case 'cash':
        return 'assets/icons/cash.svg';
      case 'pay':
        return 'assets/icons/apple.svg';
      default:
        return '';
    }
  }
}
