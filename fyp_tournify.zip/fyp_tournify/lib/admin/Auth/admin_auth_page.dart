import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../welcome_screen.dart';
import '../View/admin_bottom_navigation.dart';


class AdminAuthPage extends StatelessWidget {
  AdminAuthPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Text('Loading...'),
            );
          }
          if (snapshot.hasData) {
            return AdminBottomNevigationBar();
          } else {
            return WelcomeScreen();
          }
        },
      ),
    );
  }
}
