import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'Res/Widgets/app_text.dart';
import 'Res/Widgets/custom_botton.dart';
import 'User/View/login_screen.dart';
import 'admin/View/admin_login_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}




class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const AppText(text: 'Welcome Screen ',fontWeight: FontWeight.w600,fontSize: 30,textColor: Colors.white,),
              SizedBox(height: 20,),
              CustomBotton(
                onTap: () {
                  Get.to(
                        ()=>AdminLoginScreen(),
                  );
                },
                label: 'Admin Login',
                backgroundColor: Colors.teal,
              ),
              SizedBox(height: 20,),
              CustomBotton(
                onTap: () {
                  Get.to(
                        ()=>LoginScreen(),
                  );
                },
                label: 'User Login',
                backgroundColor: Colors.teal,
              ),
            ],
          ),
        ),
      ),
    );
  }
}


