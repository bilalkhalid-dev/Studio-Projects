import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fyp_tournify/welcome_screen.dart';
import 'package:get/get.dart';
import 'User/Auth/authPage.dart'; // User Auth Screen
import 'admin/Auth/admin_auth_page.dart'; // Admin Auth Screen
import 'firebase_options.dart'; // Firebase initialization
import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
options: DefaultFirebaseOptions.currentPlatform,
);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cricket Live Score',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AuthDecisionScreen(), // Start by checking user role
    );
  }
}

class AuthDecisionScreen extends StatefulWidget {
  const AuthDecisionScreen({Key? key});

  @override
  _AuthDecisionScreenState createState() => _AuthDecisionScreenState();
}

class _AuthDecisionScreenState extends State<AuthDecisionScreen> {
  // Function to get the user role from Firestore
  Future<String?> _getUserRole() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        // Get the user document from Firestore
        DocumentSnapshot<Map<String, dynamic>> snapshot =
        await FirebaseFirestore.instance.collection('users').doc(user.uid).get();

        if (snapshot.exists) {
          final String? role = snapshot.data()?['role'];  // Fetch the role field
          return role?.toLowerCase();  // Return 'admin' or 'user'
        }
      } catch (e) {
        print('Error determining user role: $e');
      }
    }
    return null;  // Return null if no user or role found
  }

  @override
  Widget build(BuildContext context) {
    // Use FutureBuilder to wait for the role check to complete
    return FutureBuilder<String?>(
      future: _getUserRole(),  // Fetch the user role
      builder: (BuildContext context, AsyncSnapshot<String?> snapshot) {
        // While waiting for the role data
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator(color: Colors.teal));
        }

        // If there's an error or no data
        if (snapshot.hasError || !snapshot.hasData) {
          return WelcomeScreen();  // Show the welcome screen (for unauthenticated users)
        }

        String? role = snapshot.data;
        if (role == 'admin') {
          return AdminAuthPage();  // Navigate to the Admin Home Screen
        } else if (role == 'user') {
          return AuthPage();  // Navigate to the User Home Screen
        } else {
          return WelcomeScreen();  // For invalid or missing roles, show the welcome screen
        }
      },
    );
  }
}