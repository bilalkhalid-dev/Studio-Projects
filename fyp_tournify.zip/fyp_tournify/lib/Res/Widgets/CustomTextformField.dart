import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CustomTextFormField extends StatelessWidget {
  final String hintText;
  final double? height,width;
  final IconData? prefixIcon;
  final IconData? suffixIcon;
  final TextEditingController? controller;
  final Color? bgColor,suffixIconColor,borderColor;
  final void Function()? onTapSuffixIcon;
  final EdgeInsetsGeometry? contentPadding;
  final String? Function(String?)? validator;
  final int? maxLines;
  final bool? obscureText,readOnly;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  void Function(String)? onChanged;

 final  void Function(String)? onFieldSubmitted;
  CustomTextFormField(
      {super.key,
      this.prefixIcon,
      required this.hintText,
      this.controller,
      this.bgColor,
        this.onChanged,
      this.suffixIcon,
        this.onTapSuffixIcon,
        this.suffixIconColor,
        this.contentPadding, this.borderColor, this.onFieldSubmitted, this.maxLines, this.height, this.validator, this.obscureText, this.keyboardType, this.width, this.inputFormatters, this.readOnly,
      });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: TextFormField(
        readOnly: readOnly ?? false,
        inputFormatters:inputFormatters,
        style: TextStyle(color: Colors.white),
        onChanged:onChanged,
        keyboardType: keyboardType,
        obscureText: obscureText ?? false,
        validator: validator,
        maxLines: maxLines ?? 1,
        onFieldSubmitted: onFieldSubmitted,
        controller: controller,
        cursorColor: Colors.teal,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.white70,fontSize: 14,fontWeight: FontWeight.w400),
          prefixIcon: prefixIcon != null ? Icon(prefixIcon,color: Colors.white,) : null,
          suffixIcon: suffixIcon != null
              ? GestureDetector(
                  onTap: onTapSuffixIcon,
                  child: Icon(
                    suffixIcon,
                    color: suffixIconColor ?? Colors.white,
                    size: 22,
                  ),
                )
              : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: borderColor??Colors.teal),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(width: 1.5, color: Colors.teal),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.red),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.red),
          ),
          contentPadding:contentPadding,
        ),
      ),
    );
  }
}
