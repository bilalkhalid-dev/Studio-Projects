import 'package:flutter/material.dart';
import '../../Res/Widgets/app_text.dart';
import '../servises/api_services.dart';



class RecentMatchsScreen extends StatefulWidget {
  @override
  _RecentMatchsScreenState createState() => _RecentMatchsScreenState();
}

class _RecentMatchsScreenState extends State<RecentMatchsScreen> {
  Future<List<dynamic>>? _matchesFuture;

  @override
  void initState() {
    super.initState();
    _matchesFuture = ApiService.fetchRecentMatches();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title:AppText(text:'Recent Matches',textColor: Colors.white,fontSize: 20,),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _matchesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child:  CircularProgressIndicator(color: Colors.teal,));
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}',style: TextStyle(color: Colors.white),));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No matches found',style: TextStyle(color: Colors.white),));
          }

          final matches = snapshot.data!;
          return Padding(
            padding: EdgeInsets.symmetric(horizontal:20),
            child: ListView.builder(
              itemCount: matches.length,
              itemBuilder: (context, index) {
                final matchType = matches[index];
                final matchTypeLabel = matchType['matchType'] ?? 'Unknown';
                final seriesMatches = matchType['seriesMatches'] ?? [];

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      matchTypeLabel,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white),
                    ),
                    ...seriesMatches.map<Widget>((series) {
                      final seriesAdWrapper = series['seriesAdWrapper'];
                      final matches = seriesAdWrapper != null ? seriesAdWrapper['matches'] : [];

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: matches.map<Widget>((match) {
                          final matchInfo = match['matchInfo'];
                          if (matchInfo == null) return Container();

                          final teams = matchInfo['team1'] != null && matchInfo['team2'] != null
                              ? [matchInfo['team1'], matchInfo['team2']]
                              : [];
                          final team1Name = teams.isNotEmpty && teams[0] != null ? teams[0]['teamName'] ?? 'Team 1' : 'Team 1';
                          final team2Name = teams.length > 1 && teams[1] != null ? teams[1]['teamName'] ?? 'Team 2' : 'Team 2';
                          final team1Flag = teams.isNotEmpty && teams[0] != null ? teams[0]['image'] ?? '' : '';
                          final team2Flag = teams.length > 1 && teams[1] != null ? teams[1]['image'] ?? '' : '';
                          final description = matchInfo['matchDesc'] ?? 'No description';
                          final status = matchInfo['status'] ?? 'No status';

                          return Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                            child: Card(

                              child: Container(
                                width: double.infinity,
                          decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          color: Colors.grey.shade900,
                          borderRadius: BorderRadius.circular(10)
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(description,style: TextStyle(color: Colors.grey,fontSize: 10),),
                                  Text('$team1Name VS $team2Name ',style: TextStyle(color: Colors.white), ),
                                      Text('Status: $status',style: TextStyle(color: Colors.white)),

                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    }).toList(),
                  ],
                );
              },
            ),
          );
        },
      ),
    );
  }
}
