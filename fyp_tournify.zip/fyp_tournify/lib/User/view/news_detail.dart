import 'package:flutter/material.dart';
import '../Model/news_detail.dart';
import '../servises/api_services.dart';


class NewsDetailPage extends StatelessWidget {
  final int newsId;

  NewsDetailPage({required this.newsId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('News Detail'),
      ),
      body: FutureBuilder<NewsDetail>(
        future: ApiService.fetchNewsDetail(newsId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return Center(child: Text('No data found'));
          } else {
            NewsDetail newsDetail = snapshot.data!;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.network(
                    newsDetail.imageUrl,
                    errorBuilder: (context, error, stackTrace) {
                      return Icon(Icons.error, size: 100,); // Show an error icon if the image fails to load
                    },
                  ),
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(newsDetail.headline, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                        SizedBox(height: 8),
                        Text('Published on: ${DateTime.fromMillisecondsSinceEpoch(int.parse(newsDetail.publishTime)).toLocal()}'),
                        SizedBox(height: 8),
                        Text(newsDetail.intro),
                        SizedBox(height: 16),
                        ...newsDetail.content.map((content) => Padding(
                          padding: EdgeInsets.only(bottom: 8.0),
                          child: Text(content.contentValue),
                        )).toList(),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
