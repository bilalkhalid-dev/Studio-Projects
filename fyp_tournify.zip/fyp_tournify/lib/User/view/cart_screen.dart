import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Import Firebase Auth
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import 'checkout_screen.dart';

class CartScreen extends StatefulWidget {
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late String userId; // Declare userId as late

  double subtotal = 0.0;
  double shippingFee = 80.0;
  double total = 0.0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _calculateSubtotal();
    getUserData(); // Initialize userId asynchronously
  }

  void getUserData() async {
    FirebaseAuth auth = FirebaseAuth.instance;
    User? user = auth.currentUser;

    if (user != null) {
      setState(() {
        userId = user.uid; // Initialize userId
      });
      setState(() {
         _calculateSubtotal();
      });
     // Calculate subtotal after getting user ID
    } else {
      // Handle case where user is not logged in
      print('User is not logged in');
    }
  }

  Future<void> _calculateSubtotal() async {
    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('addtocart')
          .where('userId', isEqualTo: userId) // Filter by userId
          .get();

      double tempSubtotal = 0.0;
      querySnapshot.docs.forEach((doc) {
        double price = doc['productPrice'].toDouble();
        int quantity = doc['quantity'];
        tempSubtotal += price * quantity;
      });

      setState(() {
        subtotal = tempSubtotal;
        isLoading = false;
      });
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      // Handle error appropriately
      print("Error calculating subtotal: $error");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'Cart Screen',
          style: TextStyle(color: Colors.white),
        ),
        // actions: const [
        //   Padding(
        //     padding: EdgeInsets.symmetric(horizontal: 8.0),
        //     child: Icon(Icons.notifications_outlined),
        //   ),
        // ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Expanded(
              child: _buildCartItemsList(context),
            ),
            const SizedBox(height: 20),
            _buildTotalSection(),
            const SizedBox(height: 30),
            CustomBotton( // Adjusted to CustomButton as per your import
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CheckoutScreen(
                      subtotal: subtotal,
                      shippingFee: shippingFee,
                      total: subtotal + shippingFee,
                      userId: userId, // Pass userId to CheckoutScreen
                    ),
                  ),
                );
              },
              label: 'Go to checkout',
              backgroundColor: Colors.teal,
              textColor: Colors.white,
              fontSize: 18,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartItemsList(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('addtocart')
          .where('userId', isEqualTo: userId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/images/nodata.webp', height: 150, width: 150,),
                SizedBox(height: 10,),
                Text('No items in the cart.', style: TextStyle(color: Colors.white),),
              ],
            ),
          );
        }

        // Calculate subtotal dynamically
        subtotal = 0.0;
        List<CartItem> cartItems = snapshot.data!.docs.map((doc) {
          double price = doc['productPrice'].toDouble();
          int quantity = doc['quantity'];
          subtotal += price * quantity; // Update subtotal calculation
          return CartItem(
            productName: doc['productName'],
            productImage: doc['productImage'],
            productPrice: price,
            productDescription: doc['productDescription'],
            quantity: quantity, // Add quantity from Firestore
            docId: doc.id, // Add document ID for updating quantity
          );
        }).toList();

        return ListView.builder(
          itemCount: cartItems.length,
          itemBuilder: (context, index) {
            var product = cartItems[index];
            return _buildCartItem(product);
          },
        );
      },
    );
  }


  Widget _buildCartItem(CartItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade700),
        color: Colors.grey.shade900,
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.network(
              item.productImage,
              width: 90,
              height: 90,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      text: item.productName,
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      textColor: Colors.white,
                    ),
                    IconButton(
                      onPressed: () {
                        FirebaseFirestore.instance
                            .collection('addtocart')
                            .doc(item.docId)
                            .delete()
                            .then((_) {
                          // Call _calculateSubtotal after deletion
                          _calculateSubtotal();
                        });
                      },
                      icon: Icon(Icons.delete, color: Colors.red),
                    ),
                  ],
                ),
                AppText(
                  text: item.productDescription,
                  textColor: Colors.grey,
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      text: '\$ ${item.productPrice.toStringAsFixed(2)}',
                      fontWeight: FontWeight.w600,
                      textColor: Colors.white,
                    ),
                    _buildQuantityControls(item),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuantityControls(CartItem item) {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            if (item.quantity > 1) {
              FirebaseFirestore.instance.collection('addtocart').doc(item.docId).update({
                'quantity': item.quantity - 1,
              }).then((_) => setState(() {}));
            }
          },
          child: Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: Colors.grey),
              color: Colors.grey,
            ),
            child: Icon(
              Icons.remove,
              color: Colors.white,
              size: 15,
            ),
          ),
        ),
        SizedBox(width: 7),
        Text(
          item.quantity.toString(),
          style: TextStyle(color: Colors.white),
        ),
        SizedBox(width: 7),
        GestureDetector(
          onTap: () {
            FirebaseFirestore.instance.collection('addtocart').doc(item.docId).update({
              'quantity': item.quantity + 1,
            }).then((_) => setState(() {}));
          },
          child: Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: Colors.grey),
              color: Colors.grey,
            ),
            child: Icon(
              Icons.add,
              size: 15,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTotalSection() {
    double shippingFee = 80.0;
    double total = subtotal + shippingFee;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _buildTotalRow('Sub-total', subtotal),
        _buildTotalRow('Vat(%)', 0.0), // Placeholder for VAT
        _buildTotalRow('Shipping fee', shippingFee),
        Divider(color: Colors.grey.shade200, height: 1),
        _buildTotalRow('Total', total),
      ],
    );
  }

  Widget _buildTotalRow(String label, double amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          AppText(
            text: label,
            fontSize: 16,
            fontWeight: FontWeight.w400,
            textColor: Colors.grey,
          ),
          AppText(
            text: '\$ ${amount.toStringAsFixed(2)}',
            fontWeight: FontWeight.w500,
            fontSize: 16,
            textColor: Colors.white,
          ),
        ],
      ),
    );
  }
}

class CartItem {
  final String productName;
  final String productImage;
  final double productPrice;
  final String productDescription;
  int quantity; // Quantity of the product
  final String docId; // Firestore document ID

  CartItem({
    required this.productName,
    required this.productImage,
    required this.productPrice,
    required this.productDescription,
    required this.quantity,
    required this.docId,
  });
}

