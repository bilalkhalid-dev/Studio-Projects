import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../Res/Widgets/CustomTextformField.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';

class NewAddressScreen extends StatefulWidget {
  const NewAddressScreen({Key? key}) : super(key: key);

  @override
  State<NewAddressScreen> createState() => _NewAddressScreenState();
}

class _NewAddressScreenState extends State<NewAddressScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool checkValue = false;
  int _selectedItem = 0;
  TextEditingController _addressController = TextEditingController();

  @override
  void dispose() {
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'New Address',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.height ,
        child: Stack(
          children: [
            Image.asset('assets/images/map.png'),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.only(left: 5),
                height: 412,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50),
                  ),
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            height: 7,
                            width: 70,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            AppText(
                              text: 'Address',
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              textColor: Colors.white,
                            ),
                            IconButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              icon: Icon(
                                Icons.close,
                                size: 25,
                                color: Colors.white,
                              ),
                            )
                          ],
                        ),

                        Divider(
                          color: Colors.grey.shade300,
                          thickness: 2,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        const AppText(
                          text: 'Select City',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          textColor: Colors.white,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        SizedBox(
                          height: 60,
                          child: DropdownButtonFormField<int>(
                            dropdownColor: Colors.grey.shade800,
                            value: _selectedItem,
                            onChanged: (int? newValue) {
                              setState(() {
                                _selectedItem = newValue!;
                              });
                            },
                            items: const [
                              DropdownMenuItem<int>(
                                value: 0,
                                child: Text(
                                  "Choose one",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                              DropdownMenuItem<int>(
                                value: 1,
                                child: Text(
                                  "Lahore",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                              DropdownMenuItem<int>(
                                value: 2,
                                child: Text(
                                  "Karachi",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                              DropdownMenuItem<int>(
                                value: 3,
                                child: Text(
                                  "Islamabad",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                            ],
                            decoration: InputDecoration(
                              hintText: 'Select Option',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                const BorderSide(color: Colors.grey,width: 1.5),
                                // Change border color to grey
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                const BorderSide(color: Colors.grey,width: 1.5),
                                // Change border color to grey
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                const BorderSide(color: Colors.teal,width: 1.5),
                                // Change border color to grey
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        const AppText(
                          text: 'Full Address',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          textColor: Colors.white,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        CustomTextFormField(
                          controller: _addressController,
                          hintText: 'Enter your Full Address',
                          borderColor: Colors.grey.shade300,
                          bgColor: Colors.white,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Checkbox(
                              activeColor: Colors.teal,
                              value: checkValue,
                              onChanged: (value) {
                                setState(() {
                                  checkValue = value!;
                                });
                              },
                            ),
                            const AppText(
                              text: 'Make this as a default address',
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              textColor: Colors.white,
                            ),
                          ],
                        ),
                        const Spacer(),
                        CustomBotton(
                          onTap: () {
                            _saveAddress(); // Save address method
                          },
                          label: 'Add',
                          backgroundColor: Colors.teal,
                          textColor: Colors.white,
                          fontSize: 18,
                        ),
                        SizedBox(height: 10,)
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveAddress() async {
    try {
      final User? user = _auth.currentUser;
      if (user != null) {
        // Create a map with the fields to save
        Map<String, dynamic> dataToSave = {
          'uid': user.uid,
          'address': _addressController.text.trim(),
          'city': _selectedItem == 0
              ? ''
              : _selectedItem == 1
              ? 'Lahore'
              : _selectedItem == 2
              ? 'Karachi'
              : 'Islamabad',
        };

        // Save the new address data to Firestore
        await _firestore.collection('addressdetails').add(dataToSave);

        // Show success dialog
        _showSuccessDialog(context);
      } else {
        print('User is not logged in');
        // Handle case where user is not logged in
      }
    } catch (e) {
      print('Error saving address: $e');
      // Handle error saving address
    }
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey.shade800,
          title: SvgPicture.asset('assets/icons/done.svg'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppText(
                text: 'Congratulations!',
                fontWeight: FontWeight.w500,
                fontSize: 20,
                textColor: Colors.white,
              ),
              const SizedBox(height: 10),
              AppText(
                text: 'Your new Address has been added',
                fontWeight: FontWeight.w400,
                fontSize: 14,
                textColor: Colors.grey,
              ),
            ],
          ),
          actions: [
            CustomBotton(
              onTap: () {
                Navigator.of(context).pop(); // Close the dialog
                Navigator.of(context).pop(); // Close the NewAddressScreen
              },
              label: 'Thanks',
              textColor: Colors.white,
              backgroundColor: Colors.teal,
            ),
          ],
        );
      },
    );
  }
}
