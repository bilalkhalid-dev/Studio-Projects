import 'package:flutter/material.dart';
import 'package:fyp_tournify/User/view/profile_screen.dart';
import 'package:fyp_tournify/User/view/upcoming_matches.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';

import 'cart_screen.dart';
import 'order_status_screen.dart';

class BottomNevigationBar extends StatefulWidget {
  const BottomNevigationBar({super.key});

  @override
  _BottomNevigationBarState createState() => _BottomNevigationBarState();
}

class _BottomNevigationBarState extends State<BottomNevigationBar> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    UpcomingMatchesScreen(),
    CartScreen(),
    OrderStatusScreen(),
    ProfileScreen(),
  ];

  // Method to handle back press
  Future<bool> _onWillPop() async {
    if (_currentIndex != 0) {
      setState(() {
        _currentIndex = 0; // Navigate to the home screen
      });
      return false; // Prevent default back action
    }
    return true; // Allow back action to close the app if already on home
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: _screens[_currentIndex],
        bottomNavigationBar: SalomonBottomBar(
          backgroundColor: Colors.black,
          margin: const EdgeInsets.symmetric(vertical: 8),
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          items: [
            SalomonBottomBarItem(
                icon: const Icon(Icons.home),
                title: const Text("Home"),
                selectedColor: Colors.teal,
                unselectedColor: Colors.white),
            SalomonBottomBarItem(
                icon: const Icon(Icons.shopping_cart),
                title: const Text("Cart Screen"),
                selectedColor: Colors.teal,
                unselectedColor: Colors.white),
            SalomonBottomBarItem(
                icon: const Icon(Icons.local_shipping),
                title: const Text("Order Status"),
                selectedColor: Colors.teal,
                unselectedColor: Colors.white),
            SalomonBottomBarItem(
                icon: const Icon(Icons.person),
                title: const Text("Profile"),
                selectedColor: Colors.teal,
                unselectedColor: Colors.white),
          ],
        ),
      ),
    );
  }
}
