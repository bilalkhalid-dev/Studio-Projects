import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fyp_tournify/User/view/product_detail_screen.dart';
import 'package:fyp_tournify/User/view/rank_screen.dart';
import 'package:get/get.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../servises/api_services.dart';
import 'ground_booking_screen.dart';
import 'match_list.dart';
import 'news.dart';

class UpcomingMatchesScreen extends StatefulWidget {
  const UpcomingMatchesScreen({super.key});

  @override
  _UpcomingMatchesScreenState createState() => _UpcomingMatchesScreenState();
}

class _UpcomingMatchesScreenState extends State<UpcomingMatchesScreen> {

  Future<List<dynamic>>? _matchesFuture;
  List<int> favoritesIndices = [];
  bool startsValue = false;
  final ScrollController _scrollsController = ScrollController();
  int _currentIndex = 0;
  final CarouselSliderController _controller = CarouselSliderController();
  List<String> productIcons = [
    "assets/icons/bat.png",
    "assets/icons/batting_pads.png",
    "assets/icons/cricket_ball.png",
    "assets/icons/cricket_helmet.png",
    "assets/icons/elbow_pads.png",
    "assets/icons/keeping-gloves.png",
    "assets/icons/shoes.png",
    "assets/icons/wicket.png",
  ];
  List<String> productNames = [
    'Bat',
    'cricket_pads',
    'Ball',
    'Helmet',
    'elbow_pads',
    'Gloves',
    'Shoes',
    'Wickets',
  ];

  @override
  void initState() {
    super.initState();
    _matchesFuture = ApiService.fetchUpcomingMatches();
  }
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: AppText(
          text: 'Home Screen',
          textColor: Colors.white,
          fontSize: 20,
        ),
        actions: [
          PopupMenuButton<int>(
            icon: Icon(Icons.more_vert),
            onSelected: (value) {
              switch (value) {
                case 0:
                  Get.to(()=>RecentMatchsScreen());
                  break;
                case 1:
                  Get.to(()=>RankScreen());
                  break;
                case 2:
                  Get.to(()=>NewsListScreen());
                  break;
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<int>>[
              const PopupMenuItem<int>(
                value: 0,
                child: Text('Recent Matches'),
              ),
              const PopupMenuItem<int>(
                value: 1,
                child: Text('Icc Mens Ranking'),
              ),
              const PopupMenuItem<int>(
                value: 2,
                child: Text('Latest Cricket News'),
              ),
            ],
          )

        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              SizedBox(height: 10,),
              FutureBuilder<List<dynamic>>(
                future: _matchesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                        child: CircularProgressIndicator(color: Colors.teal));
                  } else if (snapshot.hasError) {
                    return Center(
                        child: Text(
                          'Error: ${snapshot.error}',
                          style: TextStyle(color: Colors.white),
                        ));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Center(
                        child: Text(
                          'No matches found',
                          style: TextStyle(color: Colors.white),
                        ));
                  }

                  final matches = snapshot.data!;
                  final List<Widget> matchWidgets = [];

                  for (var matchType in matches) {
                    final matchTypeLabel = matchType['matchType'] ?? 'Unknown';
                    final seriesMatches = matchType['seriesMatches'] ?? [];

                    for (var series in seriesMatches) {
                      final seriesAdWrapper = series['seriesAdWrapper'];
                      final seriesMatches =
                      seriesAdWrapper != null ? seriesAdWrapper['matches'] : [];

                      for (var match in seriesMatches) {
                        final matchInfo = match['matchInfo'];
                        if (matchInfo == null) continue;

                        final teams = matchInfo['team1'] != null &&
                            matchInfo['team2'] != null
                            ? [matchInfo['team1'], matchInfo['team2']]
                            : [];
                        final team1Name =
                        teams.isNotEmpty && teams[0] != null
                            ? teams[0]['teamName'] ?? 'Team 1'
                            : 'Team 1';
                        final team2Name =
                        teams.length > 1 && teams[1] != null
                            ? teams[1]['teamName'] ?? 'Team 2'
                            : 'Team 2';
                        final description = matchInfo['matchDesc'] ??
                            'No description';
                        final status = matchInfo['status'] ?? 'No status';

                        matchWidgets.add(
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            child: Card(
                              child: Container(
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey.shade800),
                                    color: Colors.grey.shade900,
                                    borderRadius: BorderRadius.circular(10)
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Text(
                                        description,
                                        style: TextStyle(
                                            color: Colors.grey, fontSize: 10),
                                      ),
                                      Spacer(),
                                      Text('$team1Name VS $team2Name',
                                        style: TextStyle(color: Colors.white),),
                                      SizedBox(height: 10,),
                                      Text('Status: $status',
                                        style: TextStyle(color: Colors.white),),
                                      SizedBox(height: 20,),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }
                    }
                  }

                  return Column(
                    children: [
                      CarouselSlider(
                        carouselController: _controller,
                        options: CarouselOptions(
                          height: 160.0,
                          autoPlay: true,
                          autoPlayCurve: Curves.fastOutSlowIn,
                          enableInfiniteScroll: true,
                          autoPlayAnimationDuration: Duration(
                              milliseconds: 800),
                          viewportFraction: 1,
                          onPageChanged: (index, reason) {
                            setState(() {
                              _currentIndex = index;
                            });
                          },
                        ),
                        items: matchWidgets.take(7)
                            .toList(), // Take only the first 7 matches
                      ),
                      SizedBox(height: 10),
                      AnimatedSmoothIndicator(
                        activeIndex: _currentIndex,
                        count: 7,
                        effect: ExpandingDotsEffect(
                          radius: 10,
                          dotHeight: 8,
                          dotWidth: 14,
                          activeDotColor: Colors.teal,
                          dotColor: Colors.white,
                        ),
                        onDotClicked: (index) {
                          _controller.jumpToPage(index);
                        },
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    text: 'Ground Bookings',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    textColor: Colors.white,
                  ),
                  GestureDetector(
                      onTap: () {
                        Get.off(ProductDetailScreen());
                        // Get.toNamed(RouteName.productScreen);
                      },
                      child: AppText(
                        text: 'See All',
                        fontWeight: FontWeight.bold,
                        textColor: Colors.white,
                      )),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              SingleChildScrollView(
                child: Container(
                  height: 240,
                  child: StreamBuilder<QuerySnapshot>(
                    stream: _firestore.collection('createPosts').snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }

                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                'assets/images/ground.png',
                                height: 200,
                                width: 200,
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                'No Data Found',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        );
                      }

                      List<QueryDocumentSnapshot> documents = snapshot.data!.docs;

                      return ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: documents.length,
                        itemBuilder: (context, index) {
                          var data = documents[index].data() as Map<String, dynamic>;
                          var postName = data['postName'] ?? 'Unknown';
                          var postDescription = data['postDescription'] ?? 'No description';
                          var postImage = data['postImage'] ?? '';
                          return Card(
                            elevation: 1,
                            child: Container(
                              width: 325,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (postImage.isNotEmpty)
                                    ClipRRect(
                                      borderRadius:BorderRadius.only(topRight: Radius.circular(10),
                                          topLeft: Radius.circular(10)),
                                      child: Image.network(
                                        postImage,
                                        height: 150,
                                        width: double.infinity,
                                        fit: BoxFit.cover,
                                      ),
                                    )
                                  else
                                    Placeholder(
                                      fallbackHeight: 150,
                                      color: Colors.grey,
                                    ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 13, vertical: 10),
                                    child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            AppText(
                                              text:  postName,
                                              fontWeight: FontWeight.w500,
                                              fontSize: 20,

                                            ),
                                            AppText(
                                              text: postDescription,
                                              fontSize: 16,
                                            ),
                                          ],
                                        ),
                                        CustomBotton(
                                          onTap: () {
                                            Get.to(() => GroundBooking(
                                              postName: postName,
                                              postDescription: postDescription,
                                            ));
                                          },
                                          label: 'Book Now',
                                          width: 60,
                                          height: 30,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                          backgroundColor: Colors.teal,
                                          textColor: Colors.white,
                                          borderRadius: 5,
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    text: 'Categories',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    textColor: Colors.white,

                  ),
                  GestureDetector(
                      onTap: () {
                        Get.off(ProductDetailScreen());
                        //Get.toNamed(RouteName.productScreen);
                      },
                      child: AppText(
                        text: 'See All',
                        fontWeight: FontWeight.bold,
                        textColor: Colors.white,
                      )),
                ],
              ),
              SizedBox(height: 20,),
              SizedBox(
                height: 170,
                child: GridView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  itemCount: productIcons.length,
                  gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10),
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white),
                          ),
                          child: Image.asset(
                            productIcons[index],
                            fit: BoxFit.fill,
                          ),
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        AppText(
                          text: productNames[index],
                          textColor: Colors.white,
                          fontSize: 10,
                        )
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    text: 'Most Popular',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    textColor: Colors.white,
                  ),
                  //


                ],
              ),
              SizedBox(
                height: 20,
              ),
              Card(
                elevation: 1,
                child: Container(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  // height: 200,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            topLeft: Radius.circular(10),),
                          child: Image.asset('assets/images/img.png')),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 13, vertical: 10),
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                AppText(
                                  text: 'New Arrivals ',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 20,

                                ),
                                AppText(
                                  text: 'Summer’s 25 Collections ',
                                  fontSize: 16,
                                ),
                              ],
                            ),
                            CustomBotton(
                              label: 'View all',
                              width: 78,
                              height: 30,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              backgroundColor: Colors.teal,
                              textColor: Colors.white,
                              borderRadius: 5,
                              onTap: (){
                                //
                              },
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    text: 'Trending Products',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    textColor: Colors.white,
                  ),
                  AppText(
                    text: 'See All',
                    fontWeight: FontWeight.bold,
                    textColor: Colors.white,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              SingleChildScrollView(
                child: Container(
                  height: 255,
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance.collection('addproducts').snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return Center(
                          child: Text(
                            'No products found.',
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }

                      // Extract product list once to avoid rebuilding excessively
                      final products = snapshot.data!.docs.map((doc) {
                        return {
                          'productName': doc['productName'],
                          'productDescription': doc['productDescription'],
                          'productPrice': doc['productPrice'],
                          'productImage': doc['productImage'],
                        };
                      }).toList();

                      return ListView.builder(
                        key: UniqueKey(), // Ensure the ListView has a unique key
                        controller: _scrollsController,
                        scrollDirection: Axis.horizontal,
                        itemCount: products.length,
                        itemBuilder: (context, index) {
                          final product = products[index];
                          return _buildTrendingProductsContainer(
                            product['productImage'],
                            product['productName'],
                            product['productPrice'],
                            product['productDescription'],
                            index,
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTrendingProductsContainer(String imageUrl,
      String productName,
      double productPrice,
      String productDescription,
      int index,) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(
              image: imageUrl,
              name: productName,
              price: productPrice,
              description: productDescription,
            ),
          ),
        );
      },
      child: Container(
        width: 160,
        margin: EdgeInsets.only(right: 15),
        decoration: BoxDecoration(
          color: Colors.grey.shade900,
          borderRadius: BorderRadius.circular(15),

        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
              child: Image.network(
                imageUrl,
                height: 125,
                fit: BoxFit.cover,
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 8),
                    Text(
                      productName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 6),
                    Text(
                      productDescription,
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 6),
                    Text(
                      '\$$productPrice',
                      style: TextStyle(
                        color: Colors.tealAccent,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}