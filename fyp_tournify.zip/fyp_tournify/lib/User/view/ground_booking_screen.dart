import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../Res/Widgets/CustomTextformField.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../Model/ground_booking_model.dart';
import 'booking_history.dart';


class GroundBooking extends StatefulWidget {
  final String postName;
  final String postDescription;

  const GroundBooking({
    Key? key,
    required this.postName,
    required this.postDescription,
  }) : super(key: key);

  @override
  State<GroundBooking> createState() => _GroundBookingState();
}

class _GroundBookingState extends State<GroundBooking> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _groundTimingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
        if (userDoc.exists) {
          Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;
          setState(() {
            _firstNameController.text = userData['firstName'] ?? '';
            _lastNameController.text = userData['lastName'] ?? '';
            _emailController.text = userData['email'] ?? '';
            _phoneNumberController.text = userData['phoneNumber'] ?? '';
          });
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error fetching user data: $e')));
    }
  }

  DateTime _selectedDate = DateTime.now(); // Start from tomorrow

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(), // Allow current date onwards
      lastDate: DateTime(2100),  // Upper limit
      selectableDayPredicate: (DateTime date) {
        return !date.isAtSameMomentAs(DateTime.now()); // Allow current and future dates
      },
    );

    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;

        // Format the selected date and update the controller
        String formattedDate = DateFormat('dd-MM-yyyy').format(pickedDate);
        _dateController.text = formattedDate;
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text('Booking For Ground', style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(onPressed: (){
            Get.to(()=>BookingHistory());
          }, icon: Icon(Icons.history)),
        ],
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppText(text: 'Ground Name', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: TextEditingController(text: widget.postName),
                      readOnly: true,
                      hintText: 'Ground Name',
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Ground timing', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _groundTimingController,
                      hintText: 'Enter the ground timing',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your last name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'First Name', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _firstNameController,
                      hintText: 'Enter your First Name',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your first name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Last Name', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _lastNameController,
                      hintText: 'Enter your Last Name',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your last name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Email', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _emailController,
                      hintText: 'Enter your Email',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your email';
                        }
                        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                          return 'Please enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Phone Number', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _phoneNumberController,
                      keyboardType: TextInputType.number,
                      hintText: 'Enter your Phone Number',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your phone number';
                        }
                        if (!RegExp(r'^\d{11}$').hasMatch(value)) {
                          return 'Please enter a valid phone number';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Date', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      readOnly: true,
                      keyboardType: TextInputType.number,
                      controller: _dateController,
                      inputFormatters: [
                        DateTextInputFormatter(),
                      ],
                      hintText: 'Pick the Date',
                      suffixIcon:Icons.calendar_today,
                      onTapSuffixIcon: () => _selectDate(context),

                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the date';
                        }
                        if (!RegExp(r'^\d{2}-\d{2}-\d{4}$').hasMatch(value)) {
                          return 'Please enter a valid date in dd-MM-yyyy format';
                        }
                        return null;
                      },
                    ),

                    SizedBox(height: 10),
                    AppText(text: 'Reason', fontSize: 16, textColor: Colors.white),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      controller: _reasonController,
                      hintText: 'Enter the Reason',
                      maxLines: 4,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the reason';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 40),
                    CustomBotton(
                      label: 'Book Now',
                      onTap: () async {
                        if (_formKey.currentState!.validate()) {
                          User? user = FirebaseAuth.instance.currentUser;
                          if (user != null) {
                            final booking = GroundBookingModel(
                              uid: user.uid,
                              firstName: _firstNameController.text,
                              lastName: _lastNameController.text,
                              email: _emailController.text,
                              phoneNumber: _phoneNumberController.text,
                              date: _dateController.text,
                              reason: _reasonController.text,
                              groundName: widget.postName,
                              groundTiming:_groundTimingController.text,
                              status: 'pending',
                                requestId: '',
                            );

                            if (booking.validate()) {
                              DocumentReference docRef=await FirebaseFirestore.instance.collection('groundbooking').add(booking.toJson());
                              await docRef.update({'requestId': docRef.id});
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking request send successfully!')));
                              _dateController.text = ''; // Clear the date field
                              _reasonController.text = '';
                              _groundTimingController.text ='';// Clear the date field
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid data!')));
                            }
                          }
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

}
class DateTextInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue,
      TextEditingValue newValue,
      ) {
    String newText = newValue.text;

    // Insert a '-' after the 2nd and 5th characters
    if (newText.length == 2 || newText.length == 5) {
      if (!newText.endsWith('-')) {
        newText += '-';
      }
    }

    // Check if the length of the date is already 10, if yes, do not allow further input
    if (newText.length > 10) {
      return oldValue; // Return the old value to prevent further input
    }
    if (newValue.text.isEmpty) {
      return TextEditingValue.empty; // Return an empty value to clear the field
    }

    // Check if the user has deleted the entire date
    if (oldValue.text.length > newValue.text.length) {
      return TextEditingValue.empty; // Return an empty value to clear the field
    }

    return TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
  }
}