import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../../Res/Widgets/CustomTextformField.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../Model/address_details_model.dart';
import '../Model/order_model.dart';
import '../controller/checkout_screen_controller.dart';
import 'address_screen.dart';
import 'checkout_payment_tabs/cash_payment.dart';
import 'order_status_screen.dart';

class CheckoutScreen extends StatefulWidget {
  final double subtotal;
  final double shippingFee;
  final double total;
  final String userId;

  CheckoutScreen({
    Key? key,
    required this.subtotal,
    required this.shippingFee,
    required this.total,
    required this.userId,
  }) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final CheckoutController controller = Get.put(CheckoutController());
  TextEditingController promoController = TextEditingController();
  Map<String, dynamic>? selectedAddress;

  @override
  void initState() {
    super.initState();
    if (Get.arguments != null) {
      selectedAddress = Get.arguments['addresses'][0];
    }
  }

  String generateOrderNumber() {
    Random random = Random();
    int randomNumber = random.nextInt(900000) + 100000;
    return 'ORD-$randomNumber';
  }

  void _placeOrder() async {
    try {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .get();

      if (!userDoc.exists) {
        print('User data not found');
        return;
      }

      String firstName = userDoc.get('firstName') ?? 'Unknown';
      String phoneNumber = userDoc.get('phoneNumber') ?? 'Unknown';

      QuerySnapshot cartSnapshot = await FirebaseFirestore.instance
          .collection('addtocart')
          .where('userId', isEqualTo: widget.userId)
          .get();

      if (cartSnapshot.docs.isNotEmpty) {
        List<ProductDetails> products = [];

        for (var doc in cartSnapshot.docs) {
          String productName = doc.get('productName');
          double productPrice = doc.get('productPrice').toDouble();
          int productQuantity = doc.get('quantity') ?? 1;
          String productImage = doc.get('productImage');

          ProductDetails product = ProductDetails(
            productName: productName,
            productPrice: productPrice,
            productQuantity: productQuantity,
            productImage: productImage,
          );

          products.add(product);
        }

        UserOrder order = UserOrder(
          uid: widget.userId,
          orderNo: generateOrderNumber(),
          address: selectedAddress != null
              ? selectedAddress!['address'] + ' ' + selectedAddress!['city']
              : 'Select Address',
          paymentMethod: 'Cash', // Only cash payment method
          totalAmount: widget.total,
          shipping: widget.shippingFee,
          promoCode: promoController.text,
          cardNo: '', // Leave card number empty
          firstName: firstName,
          phoneNumber: phoneNumber,
          products: products,
          status: 'Pending',
          currentTime: DateTime.now(),
        );

        // Save order to Firestore
        await FirebaseFirestore.instance.collection('orders').add(order.toMap());

        // Clear cart data for the current user
        await FirebaseFirestore.instance
            .collection('addtocart')
            .where('userId', isEqualTo: widget.userId)
            .get()
            .then((querySnapshot) {
          querySnapshot.docs.forEach((doc) {
            doc.reference.delete();
          });
        });

        // Show success dialog and navigate to order status screen
        _showSuccessDialog(context);
      } else {
        print('No product found in the cart');
      }
    } catch (e) {
      print('Error placing order: $e');
    }
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey.shade800,
          title: SvgPicture.asset('assets/icons/done.svg'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppText(
                text: 'Congratulations!',
                fontWeight: FontWeight.w500,
                fontSize: 20,
                textColor: Colors.white,
              ),
              AppText(
                text: 'Your order has been placed.',
                fontWeight: FontWeight.w400,
                fontSize: 14,
                textColor: Colors.grey,
              ),
            ],
          ),
          actions: [
            CustomBotton(
              onTap: () {
                Navigator.of(context).pop(); // Close the dialog
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (_) => OrderStatusScreen()));
              },
              label: 'Track Your Order',
              textColor: Colors.white,
              backgroundColor: Colors.teal,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'Checkout Screen',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const AppText(
                      text: 'Delivery Address',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      textColor: Colors.white,
                    ),
                    GestureDetector(
                      onTap: () async {
                        Map<String, dynamic>? result =
                        await Get.to(() => AddressScreen());

                        if (result != null) {
                          setState(() {
                            selectedAddress = result;
                          });
                        }
                      },
                      child: const AppText(
                        text: 'Change',
                        fontSize: 14,
                        decoration: TextDecoration.underline,
                        textColor: Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.location_on_outlined, color: Colors.white),
                    SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AppText(
                          text: 'Home',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          textColor: Colors.white,
                        ),
                        AppText(
                          text: selectedAddress != null
                              ? selectedAddress!['address'] +
                              ' ' +
                              selectedAddress!['city']
                              : 'Select Address',
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          textColor: Colors.grey,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Divider(color: Colors.grey.shade200),
                const SizedBox(height: 10),
                const AppText(
                  text: 'Payment Method',
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  textColor: Colors.white,
                ),
                const SizedBox(height: 10),
                // Only showing CashPayment widget
                SizedBox(
                  height: 150,
                  child: const CashPayment(),
                ),
                const AppText(
                  text: 'Order Summary',
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  textColor: Colors.white,
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      text: 'Sub-total',
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      textColor: Colors.grey,
                    ),
                    AppText(
                      text: '\$${widget.subtotal.toStringAsFixed(2)}',
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      textColor: Colors.white,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      text: 'Shipping fee',
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      textColor: Colors.grey,
                    ),
                    AppText(
                      text: '\$ ${widget.shippingFee.toStringAsFixed(2)}',
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      textColor: Colors.white,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const Divider(color: Colors.grey),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      text: 'Total',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      textColor: Colors.white,
                    ),
                    AppText(
                      text: '\$${widget.total.toStringAsFixed(2)}',
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      textColor: Colors.white,
                    ),
                  ],
                ),
                const SizedBox(height: 150),
                CustomBotton(
                  onTap: _placeOrder,
                  label: 'Place Order',
                  textColor: Colors.white,
                  backgroundColor: Colors.teal,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
