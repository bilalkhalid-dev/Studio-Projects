import 'package:flutter/material.dart';
import '../../Res/Widgets/app_text.dart';
import '../Model/news_modle.dart';
import '../servises/api_services.dart';
import 'news_detail.dart';


class NewsListScreen extends StatefulWidget {
  @override
  _NewsListScreenState createState() => _NewsListScreenState();
}

class _NewsListScreenState extends State<NewsListScreen> {
  late Future<List<News>> futureNews;

  @override
  void initState() {
    super.initState();
    futureNews = ApiService.fetchNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        title:AppText(text:'Latest News',textColor: Colors.white,fontSize: 20,),
      ),
      body: FutureBuilder<List<News>>(
        future: futureNews,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child:  CircularProgressIndicator(color: Colors.teal,));
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}',style: TextStyle(color: Colors.white),));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No data found',style: TextStyle(color: Colors.white),));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                News news = snapshot.data![index];
                return GestureDetector(
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) => NewsDetailPage(newsId: news.id),
                    //   ),
                    // );
                  },
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                    child: Card(
                      elevation: 10,
                      child:
                       Container(
                         decoration: BoxDecoration(
                             border: Border.all(color: Colors.grey),
                             color: Colors.grey.shade900,
                           borderRadius: BorderRadius.circular(10),
                         ),
                         child: Padding(
                           padding: const EdgeInsets.all(20.0),
                           child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(news.headline,style: TextStyle(color:Colors.white,fontSize: 16,fontWeight: FontWeight.w600,height: 1.1),),
                               SizedBox(height: 10,),
                                RichText(text: TextSpan(
                                  style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white),
                                  children: [
                                    TextSpan(
                                      text: 'Intro: '
                                    ),
                                    TextSpan(
                                        text: ' ${news.intro}',
                                        style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color:Colors.white,),
                                    ),
                                  ]
                                )),
                                SizedBox(height: 5,),
                                RichText(text: TextSpan(
                                    style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white),
                                    children: [
                                      TextSpan(
                                          text: 'Published on:'
                                      ),
                                      TextSpan(
                                        text: ' ${DateTime.fromMillisecondsSinceEpoch(int.parse(news.pubTime)).toLocal()}',
                                        style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color:Colors.white,),
                                      ),
                                    ]
                                )),
                                SizedBox(height: 5,),
                                RichText(text: TextSpan(
                                    style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white),
                                    children: [
                                      TextSpan(
                                          text: 'Source:'
                                      ),
                                      TextSpan(
                                        text: ' ${news.source}',
                                        style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400),
                                      ),
                                    ]
                                )),
                                SizedBox(height: 5,),
                                RichText(text: TextSpan(
                                    style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white),
                                    children: [
                                      TextSpan(
                                          text: 'Type:'
                                      ),
                                      TextSpan(
                                        text: ' ${news.storyType}',
                                        style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400),
                                      ),
                                    ]
                                )),
                              ],
                            ),
                         ),
                       ),
                      ),
                  ),
                    );
              },
            );
          }
        },
      ),
    );
  }
}