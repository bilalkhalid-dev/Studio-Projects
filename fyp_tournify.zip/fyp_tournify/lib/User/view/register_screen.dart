import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Res/Widgets/CustomTextformField.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../controller/register_controller.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  RegisterController controller = Get.put(RegisterController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: SingleChildScrollView(
              child: Form(
                key: controller.registerFormKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: AppText(
                        text: 'Register your account',
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        textColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 20),
                    AppText(text: 'First Name', fontSize: 16, textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      hintText: 'Enter your First Name',
                      controller: controller.firstNameController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your first name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Last Name', fontSize: 16, textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      hintText: 'Enter your Last Name',
                      controller: controller.lastNameController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your last name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Email', fontSize: 16, textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      hintText: 'Enter your Email',
                      controller: controller.emailController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your email';
                        }
                        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                          return 'Please enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Password', fontSize: 16, textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      hintText: 'Enter your Password',
                      controller: controller.passwordController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your password';
                        }
                        if (value.length < 6) {
                          return 'Password must be at least 6 characters long';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Phone Number', fontSize: 16, textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      keyboardType: TextInputType.number,
                      hintText: 'Enter your Phone Number',
                      controller: controller.phoneNumberController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your phone number';
                        }
                        if (!RegExp(r'^\d{11}$').hasMatch(value)) {
                          return 'Please enter a valid phone number';
                        }
                        return null;
                      },
                    ),

                    SizedBox(height: 20),
                    Obx(() {
                      return CustomBotton(
                        onTap: controller.isLoading.value ? null : controller.register,
                        label: controller.isLoading.value ? 'Loading...' : 'Register',
                        backgroundColor: controller.isLoading.value ? Colors.grey : Colors.teal,
                        textColor: Colors.white,
                      );
                    }),
                    SizedBox(height: 10),
                    Obx(() {
                      if (controller.errorMessage.isNotEmpty) {
                        return Center(
                          child: Text(
                            controller.errorMessage.value,
                            style: TextStyle(color: Colors.red),
                          ),
                        );
                      } else {
                        return SizedBox.shrink(); // Hide the error message if it's empty
                      }
                    }),


                    SizedBox(height: 10),
                    Center(
                      child: RichText(
                        text: TextSpan(
                          style: TextStyle(
                            fontSize: 15.0,
                            color: Colors.white,
                          ),
                          children: [
                            TextSpan(
                              text: "Already have an account?",

                            ),
                            TextSpan(
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  Get.to(() => LoginScreen());
                                },
                              text: ' Login',
                              style: TextStyle(color: Colors.teal),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
