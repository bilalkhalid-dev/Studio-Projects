import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../Res/Widgets/app_text.dart';

class ScoreCardScreen extends StatefulWidget {
  @override
  _ScoreCardScreenState createState() => _ScoreCardScreenState();
}

class _ScoreCardScreenState extends State<ScoreCardScreen> {
  final int matchId = 40381; // Using a constant for matchId
  final String host = 'cricbuzz-cricket.p.rapidapi.com';
  final String apiKey = 'e1d387bb66msh082c193bb84ce8ap14695bjsnde2383c36c3b';
  late final String apiUrl; // Using late keyword to initialize it later

  Map<String, dynamic>? _scoreCardData;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    apiUrl = 'https://cricbuzz-cricket.p.rapidapi.com/mcenter/v1/$matchId/scard';
    _fetchScoreCard();
  }

  Future<void> _fetchScoreCard() async {
    try {
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'x-rapidapi-host': host,
          'x-rapidapi-key': apiKey,
        },
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          _scoreCardData = data['scoreCard:0'];
          _isLoading = false;
        });
      } else {
        throw Exception('Failed to load scorecard');
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Error fetching scorecard: $error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.teal,
        title: AppText(text:'Scorecard',textColor: Colors.white,fontSize: 20,),
      ),
      body: _isLoading
          ? Center(child:  CircularProgressIndicator(color: Colors.teal,))
          : _errorMessage != null
          ? Center(child: Text(_errorMessage!,style: TextStyle(color: Colors.white),))
          : _scoreCardData != null
          ? ListView(
        padding: EdgeInsets.all(16),
        children: _scoreCardData!.entries.map((entry) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(entry.key),
                Text(entry.value.toString()),
              ],
            ),
          );
        }).toList(),
      )
          : Center(child: Text('Scorecard not available',style: TextStyle(color: Colors.white),)),
    );
  }
}
