
import 'package:flutter/material.dart';
import '../Model/player_model.dart';
import '../servises/api_services.dart';

class BattingRankingScreen extends StatefulWidget {
  @override
  _BattingRankingScreenState createState() => _BattingRankingScreenState();
}

class _BattingRankingScreenState extends State<BattingRankingScreen> {
  late Future<List<Player>> battingRank;

  @override
  void initState() {
    super.initState();
    battingRank = ApiService.battingRanking();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: FutureBuilder<List<Player>>(
        future: battingRank,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child:  CircularProgressIndicator(color: Colors.teal,));
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}',style: TextStyle(color: Colors.white),));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No data found',style: TextStyle(color: Colors.white),));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                Player player = snapshot.data![index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                  child: Card(

                    child:  Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        color: Colors.grey.shade900,
                        borderRadius: BorderRadius.circular(10)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                // Image.network('https://some-image-service.com/${player.faceImageId}'),
                                Text('${player.rank} ..',style: TextStyle(color: Colors.white),),
                                SizedBox(width: 20,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(player.name,style: TextStyle(color: Colors.white),),
                                    Text('Country: ${player.country}',style: TextStyle(color: Colors.white),),
                                  ],
                                ),
                                Spacer(),
                                Text(player.points,style: TextStyle(color: Colors.white),),
                      
                              ],
                            ),
                      
                      
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}