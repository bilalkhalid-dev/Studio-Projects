import 'package:flutter/material.dart';

import '../../../Res/Widgets/app_text.dart';

class PayPayment extends StatefulWidget {
  const PayPayment({super.key});

  @override
  State<PayPayment> createState() => _PayPaymentState();
}

class _PayPaymentState extends State<PayPayment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: AppText(text:'pay Payment',textColor: Colors.white,),
      ),
    );
  }
}
