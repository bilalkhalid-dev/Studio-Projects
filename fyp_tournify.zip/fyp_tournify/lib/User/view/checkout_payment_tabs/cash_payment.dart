import 'package:flutter/material.dart';

import '../../../Res/Widgets/app_text.dart';

class CashPayment extends StatefulWidget {
  const CashPayment({super.key});

  @override
  State<CashPayment> createState() => _CashPaymentState();
}

class _CashPaymentState extends State<CashPayment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: AppText(text:'Cash Payment',textColor: Colors.white,),
      ),
    );
  }
}