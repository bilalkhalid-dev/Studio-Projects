import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fyp_tournify/User/view/register_screen.dart';
import 'package:get/get.dart';
import '../../Res/Widgets/CustomTextformField.dart';
import '../../Res/Widgets/app_text.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../../welcome_screen.dart';
import '../controller/login_controller.dart';
import 'forget_password.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController controller = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.to(() => WelcomeScreen());
            },
            icon: Icon(Icons.arrow_back_ios,color: Colors.white,),
          ),
          backgroundColor: Colors.black,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: SingleChildScrollView(
              child: Form(
                key: controller.loginFormKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: AppText(
                        text: 'Login your account',
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        textColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 20),
                    AppText(text: 'Email', fontSize: 16,textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      hintText: 'Enter your Email',
                      controller: controller.emailController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your email';
                        }
                        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                          return 'Please enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    AppText(text: 'Password', fontSize: 16,textColor: Colors.white,),
                    SizedBox(height: 10),
                    CustomTextFormField(
                      obscureText: true,
                      hintText: 'Enter your Password',
                      controller: controller.passwordController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your password';
                        }
                        if (value.length < 6) {
                          return 'Password must be at least 6 characters long';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10,),
                    Align(
                        alignment: Alignment.bottomRight,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                      const ForgetPassword()));
                            },
                            child: const Text(
                              "Forget Password",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.teal),
                            ),
                          ),
                        )),
                    SizedBox(height: 40),
                    Obx(() {
                      return CustomBotton(
                        onTap: controller.isLoading.value ? null : controller.login,
                        label: controller.isLoading.value ? 'Loading...' : 'Login',
                        backgroundColor: controller.isLoading.value ? Colors.grey : Colors.teal,
                        textColor: Colors.white,
                      );
                    }),
                    SizedBox(height: 10),
                    Center(
                      child: RichText(
                        text: TextSpan(
                          style: TextStyle(fontSize: 15.0, color: Colors.white),
                          children: [
                            TextSpan(
                              text: "Didn't have an account?",
                            ),
                            TextSpan(
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  Get.to(() => RegisterScreen());
                                },
                              text: ' Register',
                              style: TextStyle(color: Colors.teal),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
