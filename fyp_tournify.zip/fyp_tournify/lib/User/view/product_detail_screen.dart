import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:page_view_dot_indicator/page_view_dot_indicator.dart';
import '../../Res/Widgets/custom_botton.dart';
import '../controller/productdetail_controller.dart';
import '../../Res/Widgets/app_text.dart';
import '../Auth/firestore.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final String? image;
  final String? name;
  final double? price;
  final String? description;

  const ProductDetailScreen({
    Key? key,
    this.image,
    this.name,
    this.price,
    this.description,
  }) : super(key: key);

  @override
  _ProductDetailScreenState createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  final ProductDetailScreenController controller =
  Get.put(ProductDetailScreenController());
  final FirestoreService _firestoreService = FirestoreService();
  late List<DocumentReference> cartItems = [];
  int quantity = 1; // Initial quantity

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        title: Text(
          'Product Details',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Obx(() => Container(
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            SizedBox(
              height: 320,
              child: PageView(
                controller: controller.pageController,
                onPageChanged: (index) {
                  setState(() {
                    controller.currentPage.value = index;
                  });
                },
                children: [
                  Image.network(
                    widget.image!,
                    fit: BoxFit.fill,
                  ),
                  Image.network(widget.image!, fit: BoxFit.fill),
                  Image.network(widget.image!, fit: BoxFit.fill),
                ],
              ),
            ),
            Positioned(
              top: 250,
              child: PageViewDotIndicator(
                currentItem: controller.currentPage.value,
                count: 3,
                unselectedColor: Colors.white,
                selectedColor: Colors.teal,
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: SingleChildScrollView(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 400,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: const BorderRadius.only(
                      topRight: Radius.circular(50),
                      topLeft: Radius.circular(50),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: 230,
                              child: AppText(
                                text: widget.name!,
                                fontWeight: FontWeight.w600,
                                fontSize: 20,
                                overflow: TextOverflow.ellipsis,
                                textColor: Colors.white,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.all(5),
                              width: 80,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceAround,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      if (quantity > 1) {
                                        setState(() {
                                          quantity--;
                                        });
                                      }
                                    },
                                    child: AppText(
                                      text: '-',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ),
                                  ),
                                  AppText(
                                    text: quantity.toString(),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 22,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        quantity++;
                                      });
                                    },
                                    child: AppText(
                                      text: '+',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 22,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                        const AppText(
                          text: '(270 Reviews)',
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          textColor: Colors.white,
                        ),
                        const SizedBox(height: 20),
                        const AppText(
                          text: 'Size',
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                          textColor: Colors.white,
                        ),
                        const SizedBox(height: 5),
                        SizedBox(
                          height: 50,
                          child: ListView.builder(
                            itemCount: controller.sizeList.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(right: 10),
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      controller.selectedIndex.value = index;
                                    });
                                  },
                                  child: Container(
                                    height: 70,
                                    width: 70,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: controller.selectedIndex.value ==
                                            index
                                            ? Colors.transparent
                                            : Colors.teal,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                      color: controller.selectedIndex.value ==
                                          index
                                          ? Colors.teal
                                          : Colors.transparent,
                                    ),
                                    child: Center(
                                      child: AppText(
                                        text: controller.sizeList[index],
                                        fontWeight: FontWeight.bold,
                                        textColor: controller.selectedIndex.value ==
                                            index
                                            ? Colors.white
                                            : Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(height: 5),
                        const AppText(
                          text: 'Description',
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          textColor: Colors.white,
                        ),
                        const SizedBox(height: 10),
                        AppText(
                          text: widget.description!,
                          textColor: Colors.white,
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.fromLTRB(20, 10, 10, 10),
                          width: double.infinity,
                          height: 70,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.teal,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              AppText(
                                text:
                                '\$${(widget.price! * quantity).toStringAsFixed(2)}',
                                textColor: Colors.white,
                                fontSize: 18,
                              ),
                              CustomBotton(
                                backgroundColor: Colors.grey.shade900,
                                borderRadius: 10,
                                width: 140,
                                height: 70,
                                label: 'Add to cart',
                                fontSize: 18,
                                fontWeight: FontWeight.w500,
                                onTap: () async {
                                  try {
                                    DocumentReference docRef =
                                    await _firestoreService.addToCart(
                                      productName: widget.name!,
                                      productImage: widget.image!,
                                      productPrice: widget.price!,
                                      productDescription: widget.description!,
                                      quantity: quantity,
                                    );
                                    setState(() {
                                      cartItems.add(docRef);
                                    });
                                    Get.to(() => CartScreen());
                                  } catch (e) {
                                    print('Error adding to cart: $e');
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      )),
    );
  }
}
