import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Res/Widgets/app_text.dart';
import '../controller/rank_controller.dart';
import 'allrounder_ranking_screen.dart';
import 'batting_ranking_screen.dart';
import 'bowling_ranking_screen.dart';

class RankScreen extends StatefulWidget {
  const RankScreen({super.key});

  @override
  State<RankScreen> createState() => _RankScreenState();
}

class _RankScreenState extends State<RankScreen> {
  List<String> productsType = ["Batting", "Bowling", "All_Rounder"];
  RankController controller = Get.put(RankController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        title:AppText(text:'ICC Mens Rankings',textColor: Colors.white,fontSize: 20,),
      ),
      body: DefaultTabController(
        length: 3,
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(20.0),
            child: Column(
              children: [
                Obx(() => Padding(
                  padding: EdgeInsets.symmetric(vertical: 5, ),
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 40,
                    child: TabBar(
                      // tabAlignment: TabAlignment.start,
                      // isScrollable: true,
                      dividerColor: Colors.transparent,
                      indicator: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.transparent,
                      ),
                      onTap: (index) {
                        controller.changeTabIndex(index);
                      },
                      tabs: productsType.map<Widget>((type) {
                        return Tab(
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () {
                                controller.changeTabIndex(
                                    productsType.indexOf(type));
                              },
                              child: Container(
                                padding: const EdgeInsets.all(2),
                                width: 110,
                                decoration: BoxDecoration(
                                  color: controller.selectedIndex ==
                                      productsType.indexOf(type)
                                      ? Colors.teal
                                      : Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: controller.selectedIndex ==
                                        productsType.indexOf(type)
                                        ? Colors.transparent
                                        : Colors.transparent,
                                    width: 2,
                                  ),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    type,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge!
                                        .merge(
                                      TextStyle(
                                        color:
                                        controller.selectedIndex ==
                                            productsType
                                                .indexOf(type)
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                )),
                SizedBox(height: 20,),
                Expanded(
                  child: Obx(() {
                    switch (controller.selectedIndex) {
                      case 0:
                        return BattingRankingScreen();
                      case 1:
                        return BowlingRankingScreen();
                      case 2:
                        return AllRounderRankingScreen();
                      default:
                        return const SizedBox.shrink();
                    }
                  }),
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }
}
