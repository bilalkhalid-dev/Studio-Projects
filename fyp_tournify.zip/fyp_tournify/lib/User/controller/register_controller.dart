import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../Auth/firestore.dart';
import '../View/login_screen.dart';

class RegisterController extends GetxController {
  final registerFormKey = GlobalKey<FormState>();

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();


  var isLoading = false.obs;
  var errorMessage = ''.obs;

  Future<void> register() async {
    if (registerFormKey.currentState!.validate()) {
      isLoading.value = true;
      try {
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text,
          password: passwordController.text,
        );

        User? user = userCredential.user;
        if (user != null) {
          await user.sendEmailVerification();

          await FirestoreService().addUserToFirestore(
            firstNameController.text,
            lastNameController.text,
            emailController.text,
            passwordController.text,
            phoneNumberController.text,

          );
          Get.snackbar(
            colorText: Colors.white,
            'Registration Successful',
            'A verification email has been sent to ${user.email}. Please verify your email before logging in.',
            snackPosition: SnackPosition.BOTTOM,
          );
          Get.to(() => LoginScreen());
          reset();
        }// Clear form fields and error message
      } on FirebaseAuthException catch (e) {
        if (e.code == 'email-already-in-use') {
          errorMessage.value = 'The email address is already in use by another account.';
        } else {
          errorMessage.value = 'An error occurred. Please try again later.';
        }
      } catch (e) {
        errorMessage.value = 'An error occurred. Please try again later.';
        print('Error: $e');
      } finally {
        isLoading.value = false;
      }
    }
  }

  void reset() {
    registerFormKey.currentState?.reset();
    usernameController.clear();
    firstNameController.clear();
    lastNameController.clear();
    emailController.clear();
    passwordController.clear();
    phoneNumberController.clear();
    errorMessage.value = '';
  }
}
