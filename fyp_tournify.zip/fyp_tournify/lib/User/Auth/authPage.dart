import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../welcome_screen.dart';
import '../view/bottom_navigation_bar.dart';



class AuthPage extends StatelessWidget {
  AuthPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: Text('Loading...'));
          }
          if (snapshot.hasData) {
            return BottomNevigationBar();  // User home screen
          } else {
            return WelcomeScreen();  // Show welcome if no user
          }
        },
      ),
    );
  }
}

