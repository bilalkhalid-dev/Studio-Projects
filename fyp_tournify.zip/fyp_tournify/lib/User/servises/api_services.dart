import 'dart:convert';
import 'package:http/http.dart' as http;

import '../Model/news_modle.dart';
import '../Model/news_detail.dart';
import '../Model/player_model.dart';

class ApiService {
  static const String _baseUrl = 'https://cricbuzz-cricket.p.rapidapi.com';
  static const String url = 'https://cricbuzz-cricket.p.rapidapi.com/stats/v1/rankings/batsmen?formatType=test';
  static const Map<String, String> _headers = {
    'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com',
    'x-rapidapi-key': 'e1d387bb66msh082c193bb84ce8ap14695bjsnde2383c36c3b',
    // 'x-rapidapi-key': '78b12346d5msha6e7a2a99d4312bp163adcjsnbf692ba5d5f2',
    // 'x-rapidapi-key': 'd4cca4f54cmsh8f99930fe671101p13fd9cjsn9422a9dc23be',

  };

  static Future<List<dynamic>> fetchRecentMatches() async {
    final response = await http.get(Uri.parse('$_baseUrl/matches/v1/recent'), headers: _headers);
    if (response.statusCode == 200) {
      Map<String, dynamic> data = json.decode(response.body);
      return data['typeMatches'] ?? [];
    } else {
      throw Exception('Failed to load matches');
    }
  }
  static Future<List<dynamic>> fetchUpcomingMatches() async {
    final response = await http.get(Uri.parse('$_baseUrl/matches/v1/upcoming'), headers: _headers);
    if (response.statusCode == 200) {
      Map<String, dynamic> data = json.decode(response.body);
      return data['typeMatches'] ?? [];
    } else {
      throw Exception('Failed to load matches');
    }
  }
  static Future<List<Player>> battingRanking() async {
    final response = await http.get(Uri.parse('$_baseUrl/stats/v1/rankings/batsmen?formatType=test'), headers: _headers);

    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = json.decode(response.body);
      List<dynamic> playersJson = jsonResponse['rank'];
      return playersJson.map((player) => Player.fromJson(player)).toList();
    } else {
      print('Request failed with status: ${response.statusCode}');
      print('Response body: ${response.body}');
      throw Exception('Failed to load player data');
    }
  }
  static Future<List<Player>> bowlersRanking() async {
    final response = await http.get(Uri.parse('$_baseUrl/stats/v1/rankings/bowlers?formatType=test'), headers: _headers);

    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = json.decode(response.body);
      List<dynamic> playersJson = jsonResponse['rank'];
      return playersJson.map((player) => Player.fromJson(player)).toList();
    } else {
      print('Request failed with status: ${response.statusCode}');
      print('Response body: ${response.body}');
      throw Exception('Failed to load player data');
    }
  }
  static Future<List<Player>> allroundersRanking() async {
    final response = await http.get(Uri.parse('$_baseUrl/stats/v1/rankings/allrounders?formatType=test'), headers: _headers);

    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = json.decode(response.body);
      List<dynamic> playersJson = jsonResponse['rank'];
      return playersJson.map((player) => Player.fromJson(player)).toList();
    } else {
      print('Request failed with status: ${response.statusCode}');
      print('Response body: ${response.body}');
      throw Exception('Failed to load player data');
    }
  }
  static Future<List<News>> fetchNews() async {
    final response = await http.get(Uri.parse('$_baseUrl/news/v1/index'), headers: _headers);

    if (response.statusCode == 200) {
      List<dynamic> jsonResponse = json.decode(response.body)['storyList'];
      List<News> newsList = jsonResponse.where((item) => item.containsKey('story')).map((news) => News.fromJson(news)).toList();
      return newsList;
    } else {
      throw Exception('Failed to load news');
    }
  }
  static Future<NewsDetail> fetchNewsDetail(int id) async {
    final response = await http.get(Uri.parse('$_baseUrl/news/v1/detail/$id'), headers: _headers);

    if (response.statusCode == 200) {
      return NewsDetail.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load news detail');
    }
  }
}
