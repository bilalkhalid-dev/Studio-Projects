class Player {
  final String id;
  final String rank;
  final String name;
  final String country;
  final String rating;
  final String points;
  final String lastUpdatedOn;
  final String trend;
  final String faceImageId;

  Player({
    required this.id,
    required this.rank,
    required this.name,
    required this.country,
    required this.rating,
    required this.points,
    required this.lastUpdatedOn,
    required this.trend,
    required this.faceImageId,
  });

  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
      id: json['id'] as String,
      rank: json['rank'] as String,
      name: json['name'] as String,
      country: json['country'] as String,
      rating: json['rating'] as String,
      points: json['points'] as String,
      lastUpdatedOn: json['lastUpdatedOn'] as String,
      trend: json['trend'] as String,
      faceImageId: json['faceImageId'] as String,
    );
  }
}
