class Content {
  final String contentType;
  final String contentValue;
  final bool hasFormat;

  Content({
    required this.contentType,
    required this.contentValue,
    required this.hasFormat,
  });

  factory Content.fromJson(Map<String, dynamic> json) {
    return Content(
      contentType: json['contentType'],
      contentValue: json['contentValue'],
      hasFormat: json['hasFormat'] ?? false, // Default value if 'hasFormat' is not provided
    );
  }
}
