class UserModel {
  final String uid;
  final String imageUrl;
  final String firstName;
  final String lastName;
  final String email;
  final String password;
  final String phoneNumber;



  UserModel( {
    required this.uid,
    required this.imageUrl,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.password,
    required this.phoneNumber,


  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      "imageUrl": imageUrl,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'password': password,
      'phoneNumber': phoneNumber,


    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      firstName: map['firstName'] ?? '',
      lastName: map['lastName'] ?? '',
      email: map['email'] ?? '',
      password: map['password'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '',

    );
  }
}
