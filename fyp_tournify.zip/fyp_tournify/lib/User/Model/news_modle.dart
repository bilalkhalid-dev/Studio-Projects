class News {
  final int id;
  final String headline;
  final String intro;
  final String pubTime;
  final String source;
  final String storyType;
  final String imageUrl;

  News({
    required this.id,
    required this.headline,
    required this.intro,
    required this.pubTime,
    required this.source,
    required this.storyType,
    required this.imageUrl,
  });

  factory News.fromJson(Map<String, dynamic> json) {
    final String imageUrl = json['story']['coverImage'] != null
        ? 'https://cricbuzz.com/images/${json['story']['coverImage']['id']}.jpg'
        : 'https://cricbuzz.com/images/default.jpg';  // Use a default image if `coverImage` is null

    return News(
      id: json['story']['id'],
      headline: json['story']['hline'],
      intro: json['story']['intro'],
      pubTime: json['story']['pubTime'].toString(),
      source: json['story']['source'],
      storyType: json['story']['storyType'],
      imageUrl: imageUrl,
    );
  }
}
