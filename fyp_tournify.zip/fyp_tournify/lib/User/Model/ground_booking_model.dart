class GroundBookingModel {
  String requestId;
  String uid;
  String firstName;
  String lastName;
  String email;
  String phoneNumber;
  String date;
  String reason;
  String status;
  String groundName;
  String groundTiming;

  GroundBookingModel({
    required this.requestId,
    required this.uid,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phoneNumber,
    required this.date,
    required this.reason,
    required this.status,
    required this.groundName,
    required this.groundTiming,
  });

  // Factory method to create a GroundBookingModel from JSON
  factory GroundBookingModel.fromJson(Map<String, dynamic> json) {
    return GroundBookingModel(
      requestId: json['requestId'],
      uid: json['uid'],
      firstName: json['firstName'],
      lastName: json['lastName'],
      email: json['email'],
      phoneNumber: json['phoneNumber'],
      date: json['date'],
      reason: json['reason'],
      status: json['status'],
      groundName: json['groundName'],
      groundTiming: json['groundTiming'],  // Assign status from JSON
    );
  }

  // Method to convert a GroundBookingModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'requestId': requestId,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'phoneNumber': phoneNumber,
      'date': date,
      'reason': reason,
      'status': status,
      'groundTiming': groundTiming,
      'groundName': groundName,
    };
  }

  // Method to validate the data
  bool validate() {
    if (firstName.isEmpty || lastName.isEmpty || email.isEmpty || phoneNumber.isEmpty || date.isEmpty || reason.isEmpty ||groundName.isEmpty||groundTiming.isEmpty) {
      return false;
    }
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      return false;
    }
    if (!RegExp(r'^\d{11}$').hasMatch(phoneNumber)) {
      return false;
    }
    return true;
  }
}
