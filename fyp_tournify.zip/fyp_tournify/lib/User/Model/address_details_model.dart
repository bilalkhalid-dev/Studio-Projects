class AddressDetails {
  final String uid;
  final String city;
  final String address;

  AddressDetails({
    required this.uid,
    required this.city,
    required this.address,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'city': city,
      'address': address,
    };
  }

  factory AddressDetails.fromMap(Map<String, dynamic> map, String id) {
    return AddressDetails(
      uid: map['uid'] ?? '',
      city: map['city'] ?? '',
      address: map['address'] ?? '',
    );
  }
}
