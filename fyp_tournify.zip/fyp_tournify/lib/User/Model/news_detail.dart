import 'content_model.dart';

class NewsDetail {
  final int id;
  final String context;
  final String headline;
  final String publishTime;
  final String imageUrl;
  final String intro;
  final List<Content> content;

  NewsDetail({
    required this.id,
    required this.context,
    required this.headline,
    required this.publishTime,
    required this.imageUrl,
    required this.intro,
    required this.content,
  });

  factory NewsDetail.fromJson(Map<String, dynamic> json) {
    final String imageUrl = json['coverImage'] != null
        ? 'https://cricbuzz.com/images/${json['coverImage']['id']}.jpg'
        : 'https://cricbuzz.com/images/default.jpg';  // Use a default image if `coverImage` is null

    List<Content> contentList = (json['content'] as List)
        .map((i) => Content.fromJson(i['content']))
        .toList();

    return NewsDetail(
      id: json['id'],
      context: json['context'],
      headline: json['headline'],
      publishTime: json['publishTime'].toString(),
      imageUrl: imageUrl,
      intro: json['intro'],
      content: contentList,
    );
  }
}
